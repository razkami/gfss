using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Каталог улучшений: цены по уровням, параметры результата и тексты предпросмотра.</summary>
    public static class UpgradeCatalog
    {
        public static readonly UpgradeType[] Types =
        {
            UpgradeType.Size, UpgradeType.Shelves, UpgradeType.Storage, UpgradeType.Register,
            UpgradeType.Display, UpgradeType.Decor, UpgradeType.Cameras, UpgradeType.Guard
        };

        static readonly float[][] Costs =
        {
            new[] { 900f, 2600f },          // Size
            new[] { 150f, 350f, 700f },     // Shelves
            new[] { 120f, 300f, 600f },     // Storage
            new[] { 200f, 500f, 1000f },    // Register
            new[] { 250f, 650f, 1400f },    // Display
            new[] { 100f, 260f, 520f },     // Decor
            new[] { 180f, 420f, 900f },     // Cameras
            new[] { 260f, 720f },           // Guard
        };

        public static readonly int[] ShelfSlots = { 4, 6, 8, 10 };
        public static readonly int[] StorageSlots = { 3, 6, 9, 12 };
        public static readonly float[] ScanTime = { 1.6f, 1.1f, 0.7f, 0.35f };
        public static readonly int[] QueueCap = { 4, 5, 7 };

        // ----- безопасность -----
        /// <summary>Во сколько раз реже появляются воры при данном уровне камер (камеры отпугивают).</summary>
        public static readonly float[] CameraDeterrence = { 0f, 0.2f, 0.4f, 0.6f };
        /// <summary>Доля стоимости украденного, которую возвращает страховка по записям камер.</summary>
        public static readonly float[] CameraRefund = { 0f, 0f, 0.4f, 0.65f };
        /// <summary>Шанс охраны задержать убегающего.</summary>
        public static readonly float[] GuardCatchChance = { 0f, 0.55f, 0.9f };
        /// <summary>Зарплата охранника, в день.</summary>
        public static readonly float[] GuardSalary = { 0f, 0f, 30f };
        /// <summary>Стоимость одного вызова охраны (уровень 1 — охрана по вызову).</summary>
        public const float GuardCallFee = 12f;

        public static int ShelfCapacity(int shelfLevel) => 10 + 4 * shelfLevel;
        public static int Max(UpgradeType t) => Costs[(int)t].Length;
        public static float Cost(UpgradeType t, int level) => Costs[(int)t][level];
        public static string Name(UpgradeType t) => Loc.Get("up." + t + ".name");
        public static string Describe(UpgradeType t, int level) => Loc.Get("up." + t + "." + level);

        /// <summary>Что изменится в игровом мире после покупки (показывается до покупки).</summary>
        public static string WorldChange(UpgradeType t) => Loc.Get("up." + t + ".world");

        /// <summary>Ежедневные расходы до и после покупки, если улучшение их меняет. Иначе — пустая строка.</summary>
        public static string Upkeep(UpgradeType t, int level)
        {
            var d = GameSession.Data;
            int size = d.Up(UpgradeType.Size), shelves = d.Up(UpgradeType.Shelves), guard = d.Up(UpgradeType.Guard);
            float now = EconomyManager.DailyCost(size, shelves, guard);
            switch (t)
            {
                case UpgradeType.Size: size = level + 1; break;
                case UpgradeType.Shelves: shelves = level + 1; break;
                case UpgradeType.Guard: guard = level + 1; break;
                default: return "";
            }
            float next = EconomyManager.DailyCost(size, shelves, guard);
            if (Mathf.Abs(next - now) < 0.01f) return "";
            return Loc.F("pc.upkeep", UIKit.Money(now), UIKit.Money(next));
        }
    }

    public static class UpgradeManager
    {
        public static bool Buy(UpgradeType t)
        {
            var d = GameSession.Data;
            int lv = d.Up(t);
            if (lv >= UpgradeCatalog.Max(t)) return false;
            if (CashRegister.I != null && CashRegister.I.Busy) return false;
            if (t == UpgradeType.Shelves && !KioskBuilder.CanFitShelves(UpgradeCatalog.ShelfSlots[lv + 1], d.Up(UpgradeType.Size)))
            {
                Toast.Warn(Loc.Get("t.noroom"));
                return false;
            }
            if (!EconomyManager.I.Spend(UpgradeCatalog.Cost(t, lv)))
            {
                Toast.Warn(Loc.Get("t.nomoney"));
                return false;
            }
            d.upgrades[(int)t] = lv + 1;
            AudioManager.Play(Sfx.Upgrade);
            KioskBuilder.I.Build();                 // изменения сразу видны в мире (внутри Build перестраиваются и камеры/охрана)
            StockManager.I.RelocateBoxes();
            Toast.Good(Loc.F("t.bought", UpgradeCatalog.Name(t)));
            StockManager.SaveNow();
            return true;
        }
    }
}
