using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Улица вокруг киоска: асфальт, два тротуара, зебра, фонари, скамейка, деревья, дома, силуэт города. Жизнь (машины, люди, животные, птицы) — CityLife.</summary>
    public static class StreetBuilder
    {
        public static void Build(Transform parent)
        {
            var asphalt = Mats.TexturedCached("asphalt", TexGen.Concrete(new Color(0.30f, 0.31f, 0.34f), 21), new Vector2(48f, 30f), 0.12f);
            Prim.Cube(parent, "Street", new Vector3(0f, -0.5f, -24f), new Vector3(160f, 1f, 100f), asphalt);

            // тротуар (верх чуть выше асфальта) и бордюр
            var paving = Mats.TexturedCached("paving", TexGen.Paving(new Color(0.74f, 0.72f, 0.68f), 4), new Vector2(40f, 6.2f), 0.2f);
            Prim.Cube(parent, "Pavement", new Vector3(0f, -0.002f, -4.2f), new Vector3(40f, 0.014f, 7.8f), paving, false);
            var curbMat = Mats.Solid(new Color(0.85f, 0.84f, 0.8f));
            Prim.Cube(parent, "Curb", new Vector3(0f, 0.04f, -8.2f), new Vector3(40f, 0.08f, 0.22f), curbMat, false);
            // противоположный тротуар
            var farPaving = Mats.TexturedCached("paving_far", TexGen.Paving(new Color(0.74f, 0.72f, 0.68f), 4), new Vector2(40f, 3.4f), 0.2f);
            Prim.Cube(parent, "Far pavement", new Vector3(0f, -0.002f, -23.5f), new Vector3(40f, 0.014f, 3.4f), farPaving, false);
            Prim.Cube(parent, "Far curb", new Vector3(0f, 0.04f, -21.7f), new Vector3(40f, 0.08f, 0.22f), curbMat, false);

            // разметка проезжей части
            var paint = Mats.Solid(new Color(0.95f, 0.95f, 0.9f), 0.2f);
            for (float x = -78f; x <= 78f; x += 4f)
                Prim.Cube(parent, "Road dash", new Vector3(x, 0.004f, -15f), new Vector3(2f, 0.006f, 0.16f), paint, false);
            Prim.Cube(parent, "Zebra base", new Vector3(5.5f, 0.003f, -15f), new Vector3(2.6f, 0.004f, 12.6f), Mats.Solid(new Color(0.3f, 0.31f, 0.34f)), false);
            for (float z = -9.3f; z >= -20.7f; z -= 0.9f)
                Prim.Cube(parent, "Zebra", new Vector3(5.5f, 0.006f, z), new Vector3(2.4f, 0.006f, 0.45f), paint, false);

            // фонари
            foreach (float x in new[] { -3.4f, 3.4f }) Lamp(parent, new Vector3(x, 0f, -3.4f));

            // скамейка, урна, газетный автомат
            var wood = Mats.Textured(TexGen.Wood(new Color(0.5f, 0.32f, 0.18f), 71), new Vector2(2f, 1f), 0.3f);
            var iron = Mats.Metal(new Color(0.15f, 0.16f, 0.18f), 0.5f);
            Prim.Cube(parent, "Bench seat", new Vector3(3.8f, 0.45f, -1.6f), new Vector3(1.3f, 0.06f, 0.42f), wood, false);
            Prim.Cube(parent, "Bench back", new Vector3(3.8f, 0.75f, -1.78f), new Vector3(1.3f, 0.4f, 0.05f), wood, false);
            foreach (float lx in new[] { 3.25f, 4.35f }) Prim.Cube(parent, "Bench leg", new Vector3(lx, 0.22f, -1.6f), new Vector3(0.06f, 0.44f, 0.4f), iron, false);
            Prim.Cyl(parent, "Trash bin", new Vector3(-2.3f, 0.4f, -1.0f), 0.42f, 0.8f, Mats.Solid(new Color(0.2f, 0.42f, 0.3f), 0.35f));
            Prim.Cyl(parent, "Bin lid", new Vector3(-2.3f, 0.82f, -1.0f), 0.46f, 0.05f, iron);
            Prim.Cube(parent, "News box", new Vector3(-3.0f, 0.5f, -0.9f), new Vector3(0.45f, 1.0f, 0.4f), Mats.Solid(new Color(0.85f, 0.2f, 0.18f), 0.5f), false);
            Prim.Cube(parent, "News box window", new Vector3(-3.0f, 0.72f, -1.11f), new Vector3(0.32f, 0.3f, 0.01f), Mats.Glass(new Color(0.8f, 0.95f, 1f, 0.5f)), false);

            // деревья
            Tree(parent, new Vector3(-4.6f, 0f, -2.2f), 1.1f);
            Tree(parent, new Vector3(5.2f, 0f, -4.4f), 1.3f);
            Tree(parent, new Vector3(-5.5f, 0f, -6.5f), 1.0f);

            // дома: соседние по бокам и напротив через дорогу
            Building(parent, new Vector3(-8.2f, 0f, 3.5f), new Vector3(7f, 6f, 10f), new Color(0.78f, 0.7f, 0.58f), 1);
            Building(parent, new Vector3(8.4f, 0f, 3.5f), new Vector3(7.4f, 5f, 10f), new Color(0.62f, 0.7f, 0.76f), 2);
            Building(parent, new Vector3(-9f, 0f, -28.2f), new Vector3(10f, 11f, 6f), new Color(0.82f, 0.62f, 0.5f), 3);
            Building(parent, new Vector3(2f, 0f, -29.2f), new Vector3(9f, 14f, 6f), new Color(0.6f, 0.66f, 0.74f), 4);
            Building(parent, new Vector3(13f, 0f, -28.2f), new Vector3(9f, 9f, 6f), new Color(0.74f, 0.78f, 0.6f), 5);
            Building(parent, new Vector3(-20f, 0f, -28.2f), new Vector3(10f, 13f, 6f), new Color(0.7f, 0.64f, 0.7f), 6);
            Building(parent, new Vector3(23f, 0f, -28.2f), new Vector3(11f, 12f, 6f), new Color(0.8f, 0.72f, 0.58f), 7);
            Building(parent, new Vector3(-31f, 0f, -28.2f), new Vector3(10f, 10f, 6f), new Color(0.62f, 0.7f, 0.66f), 8);
            Building(parent, new Vector3(34f, 0f, -28.2f), new Vector3(10f, 15f, 6f), new Color(0.66f, 0.66f, 0.78f), 9);
            // соседние дома вдоль ближней улицы
            Building(parent, new Vector3(-17.5f, 0f, 3.5f), new Vector3(8f, 8f, 10f), new Color(0.84f, 0.76f, 0.66f), 10);   // дом игрока
            HomeDoor.Build(parent);
            Building(parent, new Vector3(17.8f, 0f, 3.5f), new Vector3(8.4f, 7f, 10f), new Color(0.7f, 0.76f, 0.7f), 11);
            Building(parent, new Vector3(-27f, 0f, 3.5f), new Vector3(9f, 10f, 10f), new Color(0.72f, 0.68f, 0.62f), 12);
            Building(parent, new Vector3(27.5f, 0f, 3.5f), new Vector3(9f, 9f, 10f), new Color(0.78f, 0.7f, 0.7f), 13);
            // силуэт города вдали
            float[] sx = { -48f, -34f, -20f, -6f, 8f, 22f, 36f, 50f };
            float[] sh = { 24f, 34f, 20f, 40f, 28f, 36f, 22f, 30f };
            for (int i = 0; i < sx.Length; i++)
                Building(parent, new Vector3(sx[i], 0f, -55f - (i % 3) * 6f), new Vector3(11f, sh[i], 9f), Color.Lerp(new Color(0.58f, 0.62f, 0.7f), new Color(0.8f, 0.78f, 0.76f), (i % 4) / 3f), 14 + i % 3);

            // припаркованные у бордюра (движущийся транспорт создаёт CityLife)
            Parked(parent, Vehicle.Kind.Sedan, new Vector3(-10.5f, 0f, -9.5f), new Color(0.82f, 0.2f, 0.2f), 0f);
            Parked(parent, Vehicle.Kind.Hatch, new Vector3(12.5f, 0f, -9.5f), new Color(0.2f, 0.45f, 0.82f), 180f);

            // дальний тротуар: фонари и деревья
            foreach (float x in new[] { -14f, 0f, 14f, 28f, -28f }) Lamp(parent, new Vector3(x, 0f, -24.6f));
            foreach (float x in new[] { -7f, 8f, 21f, -21f }) Tree(parent, new Vector3(x, 0f, -24.5f), 1.1f);
            BusStop(parent, new Vector3(-10f, 0f, -24.2f));

            CityLife.Spawn(parent);
        }

        static void Parked(Transform parent, Vehicle.Kind kind, Vector3 p, Color c, float yaw)
        {
            var go = new GameObject("Parked car");
            go.transform.SetParent(parent, false);
            go.transform.position = p;
            go.transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            Vehicle.BuildBody(go.transform, kind, c, null, out _);
        }

        static void BusStop(Transform parent, Vector3 p)
        {
            var iron = Mats.Metal(new Color(0.18f, 0.2f, 0.24f), 0.5f);
            foreach (float dx in new[] { -1.1f, 1.1f })
                Prim.Cube(parent, "Stop post", p + new Vector3(dx, 1.1f, 0f), new Vector3(0.07f, 2.2f, 0.07f), iron, false);
            Prim.Cube(parent, "Stop roof", p + new Vector3(0f, 2.25f, 0.1f), new Vector3(2.5f, 0.08f, 1.0f), Mats.Solid(new Color(0.85f, 0.25f, 0.22f), 0.4f), false);
            Prim.Cube(parent, "Stop glass", p + new Vector3(0f, 1.2f, -0.4f), new Vector3(2.1f, 1.8f, 0.03f), Mats.Glass(new Color(0.8f, 0.95f, 1f, 0.35f)), false);
            Prim.Cube(parent, "Stop bench", p + new Vector3(0f, 0.45f, -0.25f), new Vector3(1.7f, 0.06f, 0.4f), Mats.Solid(new Color(0.5f, 0.32f, 0.18f), 0.3f), false);
            Prim.Cube(parent, "Stop sign", p + new Vector3(1.4f, 1.6f, 0.3f), new Vector3(0.4f, 0.4f, 0.04f), Mats.Emissive(new Color(0.2f, 0.5f, 0.95f), 0.9f), false);
            Prim.Cyl(parent, "Stop sign pole", p + new Vector3(1.4f, 0.8f, 0.3f), 0.05f, 1.6f, iron);
        }

        static void Lamp(Transform parent, Vector3 p)
        {
            var iron = Mats.Metal(new Color(0.16f, 0.17f, 0.2f), 0.5f);
            Prim.Cyl(parent, "Lamp pole", p + new Vector3(0f, 1.9f, 0f), 0.1f, 3.8f, iron);
            Prim.Cube(parent, "Lamp arm", p + new Vector3(0f, 3.75f, 0.2f), new Vector3(0.08f, 0.08f, 0.5f), iron, false);
            Prim.Cube(parent, "Lamp head", p + new Vector3(0f, 3.7f, 0.42f), new Vector3(0.3f, 0.08f, 0.2f), Mats.Emissive(new Color(1f, 0.92f, 0.7f), 2f), false);
            var l = new GameObject("Street light").AddComponent<Light>();
            l.transform.SetParent(parent, false);
            l.transform.position = p + new Vector3(0f, 3.5f, 0.42f);
            l.type = LightType.Point;
            l.range = 8f;
            l.intensity = 0.55f;
            l.color = new Color(1f, 0.9f, 0.7f);
            l.shadows = LightShadows.None;
        }

        static void Tree(Transform parent, Vector3 p, float scale)
        {
            Prim.Cyl(parent, "Trunk", p + new Vector3(0f, 0.9f * scale, 0f), 0.22f * scale, 1.8f * scale, Mats.Solid(new Color(0.4f, 0.27f, 0.16f), 0.1f));
            var leaf = Mats.Solid(new Color(0.24f, 0.58f, 0.28f), 0.2f);
            Prim.Sphere(parent, "Crown", p + new Vector3(0f, 2.5f * scale, 0f), 1.9f * scale, leaf);
            Prim.Sphere(parent, "Crown 2", p + new Vector3(0.5f * scale, 2.2f * scale, 0.2f * scale), 1.3f * scale, Mats.Solid(new Color(0.3f, 0.65f, 0.3f), 0.2f));
        }

        static void Building(Transform parent, Vector3 p, Vector3 size, Color wall, int seed)
        {
            var mat = Mats.TexturedCached("win" + seed, TexGen.Windows(wall, seed), new Vector2(size.x / 4f, size.y / 8f), 0.15f);
            Prim.Cube(parent, "Building", p + new Vector3(0f, size.y / 2f, 0f), size, mat);
            Prim.Cube(parent, "Roof cap", p + new Vector3(0f, size.y + 0.15f, 0f), new Vector3(size.x + 0.3f, 0.3f, size.z + 0.3f),
                Mats.Solid(wall * 0.7f, 0.1f), false);
        }
    }
}
