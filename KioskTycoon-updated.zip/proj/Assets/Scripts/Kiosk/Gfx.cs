using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Материалы без внешних ассетов (кэшируются по цвету).</summary>
    public static class Mats
    {
        static readonly Dictionary<string, Material> cache = new Dictionary<string, Material>();
        static Shader sh;

        static Shader Sh()
        {
            if (sh == null) sh = Shader.Find("Standard");
            if (sh == null) sh = Shader.Find("Universal Render Pipeline/Lit");
            if (sh == null) sh = Shader.Find("Sprites/Default");
            return sh;
        }

        static Material New(Color c, float smooth, float metal)
        {
            var m = new Material(Sh());
            m.color = c;
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metal);
            return m;
        }

        public static Material Solid(Color c, float smooth = 0.3f, float metal = 0f)
        {
            string k = "s" + ColorUtility.ToHtmlStringRGBA(c) + smooth + metal;
            if (cache.TryGetValue(k, out var m) && m != null) return m;
            m = New(c, smooth, metal);
            cache[k] = m;
            return m;
        }

        public static Material Emissive(Color c, float intensity = 1.5f)
        {
            string k = "e" + ColorUtility.ToHtmlStringRGBA(c) + intensity;
            if (cache.TryGetValue(k, out var m) && m != null) return m;
            m = New(c, 0.4f, 0f);
            m.EnableKeyword("_EMISSION");
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            m.SetColor("_EmissionColor", c * intensity);
            cache[k] = m;
            return m;
        }

        public static Material Glass(Color c)
        {
            string k = "g" + ColorUtility.ToHtmlStringRGBA(c);
            if (cache.TryGetValue(k, out var m) && m != null) return m;
            m = New(c, 0.9f, 0f);
            if (m.HasProperty("_Mode"))
            {
                m.SetFloat("_Mode", 3);
                m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                m.SetInt("_ZWrite", 0);
                m.EnableKeyword("_ALPHABLEND_ON");
                m.renderQueue = 3000;
            }
            cache[k] = m;
            return m;
        }

        /// <summary>Материал с текстурой и тайлингом (создаётся каждый раз, т.к. тайлинг зависит от размера).</summary>
        public static Material Textured(Texture2D tex, Vector2 tiling, float smooth = 0.4f)
        {
            var m = New(Color.white, smooth, 0f);
            m.mainTexture = tex;
            m.mainTextureScale = tiling;
            return m;
        }

        /// <summary>Ткань с узором (1 — полоска, 2 — клетка, 3 — горошек): одежда покупателей.</summary>
        public static Material Fabric(Color c, Color accent, int pattern)
        {
            string k = "f" + ColorUtility.ToHtmlStringRGB(c) + ColorUtility.ToHtmlStringRGB(accent) + pattern;
            if (cache.TryGetValue(k, out var m) && m != null) return m;
            m = New(Color.white, 0.12f, 0f);
            m.mainTexture = TexGen.Fabric(c, accent, pattern);
            cache[k] = m;
            return m;
        }

        public static Material Metal(Color c, float smooth = 0.72f) => Solid(c, smooth, 0.85f);

        /// <summary>Текстура с тайлингом, кэшируется по параметрам (для крупных поверхностей: асфальт, бетон, маркиза).</summary>
        public static Material TexturedCached(string key, Texture2D tex, Vector2 tiling, float smooth = 0.3f)
        {
            string k = "t" + key + tiling.x + "x" + tiling.y;
            if (cache.TryGetValue(k, out var m) && m != null) return m;
            m = New(Color.white, smooth, 0f);
            m.mainTexture = tex;
            m.mainTextureScale = tiling;
            cache[k] = m;
            return m;
        }

        /// <summary>Экран с живой картинкой (RenderTexture): монитор камер наблюдения.</summary>
        public static Material LiveScreen(Texture tex)
        {
            var m = New(Color.white, 0.5f, 0f);
            m.mainTexture = tex;
            m.EnableKeyword("_EMISSION");
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            if (m.HasProperty("_EmissionMap")) m.SetTexture("_EmissionMap", tex);
            m.SetColor("_EmissionColor", new Color(0.9f, 0.95f, 1f));
            return m;
        }

        public static Material ProductPack(ProductData product)
        {
            string key = "pack:" + product.id + ColorUtility.ToHtmlStringRGB(product.packColor) + ColorUtility.ToHtmlStringRGB(product.accentColor);
            if (cache.TryGetValue(key, out var m) && m != null) return m;
            // Laminated print catches the kiosk lights and gives packs a coated finish.
            m = New(Color.white, 0.62f, product.category == ProductCategory.Devices ? 0.18f : 0.06f);
            m.mainTexture = TexGen.ProductPack(product);
            var normal = TexGen.PackNormal(product);
            if (m.HasProperty("_BumpMap"))
            {
                m.SetTexture("_BumpMap", normal);
                m.EnableKeyword("_NORMALMAP");
            }
            cache[key] = m;
            return m;
        }
    }

    /// <summary>Процедурные текстуры.</summary>
    public static class TexGen
    {
        static readonly Dictionary<string, Texture2D> cache = new Dictionary<string, Texture2D>();

        public static Texture2D VapeFinish()
        {
            const string key = "vape:midnight-cyan";
            if (cache.TryGetValue(key, out var tex) && tex != null) return tex;
            tex = new Texture2D(64, 128, TextureFormat.RGBA32, true)
            { name = "ProceduralVapeFinish", wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            Color body = new Color(0.11f, 0.15f, 0.23f);
            Fill(tex, 0, 0, 64, 128, body);
            Fill(tex, 0, 2, 64, 8, new Color(0.03f, 0.05f, 0.09f));
            Fill(tex, 0, 118, 64, 8, new Color(0.03f, 0.05f, 0.09f));
            Fill(tex, 8, 18, 48, 2, new Color(0.3f, 0.42f, 0.58f));
            Fill(tex, 8, 108, 48, 2, new Color(0.3f, 0.42f, 0.58f));
            Fill(tex, 28, 34, 8, 60, new Color(0.17f, 0.73f, 0.82f));
            Fill(tex, 17, 48, 30, 30, new Color(0.15f, 0.2f, 0.3f));
            Circle(tex, 32, 63, 8, new Color(0.3f, 0.9f, 0.94f));
            Circle(tex, 32, 63, 4, new Color(0.92f, 0.98f, 1f));
            for (int y = 22; y <= 102; y += 8) Fill(tex, 5, y, 4, 2, new Color(0.35f, 0.43f, 0.55f));
            tex.Apply(true, true);
            cache[key] = tex;
            return tex;
        }

        public static Texture2D Checker(Color a, Color b, int cells = 2, int res = 64)
        {
            string k = "c" + ColorUtility.ToHtmlStringRGB(a) + ColorUtility.ToHtmlStringRGB(b) + cells + res;
            if (cache.TryGetValue(k, out var t) && t != null) return t;
            t = new Texture2D(res, res, TextureFormat.RGBA32, true) { wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            int cs = res / cells;
            for (int y = 0; y < res; y++)
                for (int x = 0; x < res; x++)
                {
                    bool even = ((x / cs) + (y / cs)) % 2 == 0;
                    var c = even ? a : b;
                    // тонкая шовная линия
                    if (x % cs == 0 || y % cs == 0) c = Color.Lerp(c, Color.black, 0.18f);
                    t.SetPixel(x, y, c);
                }
            t.Apply();
            cache[k] = t;
            return t;
        }

        public static Texture2D Wood(Color tint, int seed = 3, int res = 128)
        {
            string key = "wood:" + ColorUtility.ToHtmlStringRGB(tint) + ":" + seed + ":" + res;
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            t = new Texture2D(res, res, TextureFormat.RGBA32, true)
            { name = "ProceduralWarmWood", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            var rng = new System.Random(seed);
            float[] bands = new float[8];
            for (int i = 0; i < bands.Length; i++) bands[i] = (float)rng.NextDouble() * 0.07f;
            for (int y = 0; y < res; y++)
                for (int x = 0; x < res; x++)
                {
                    float wave = Mathf.Sin(y * 0.20f + Mathf.Sin(x * 0.045f) * 2.5f) * 0.045f;
                    float knot = 0f;
                    for (int i = 0; i < bands.Length; i++)
                    {
                        float center = i * (res / (float)bands.Length) + bands[i] * 30f;
                        knot += Mathf.Exp(-Mathf.Abs(x - center) * 0.08f) * Mathf.Sin(y * 0.22f + i) * 0.018f;
                    }
                    float grain = wave + knot + ((float)rng.NextDouble() - 0.5f) * 0.018f;
                    Color c = tint * (1f + grain);
                    c.r = Mathf.Clamp01(c.r); c.g = Mathf.Clamp01(c.g); c.b = Mathf.Clamp01(c.b);
                    t.SetPixel(x, y, c);
                }
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        public static Texture2D Windows(Color wall, int seed)
        {
            string k = "w" + ColorUtility.ToHtmlStringRGB(wall) + seed;
            if (cache.TryGetValue(k, out var t) && t != null) return t;
            const int W = 64, H = 128;
            t = new Texture2D(W, H, TextureFormat.RGBA32, true) { wrapMode = TextureWrapMode.Repeat };
            var r = new System.Random(seed);
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    bool win = (x % 16) > 3 && (x % 16) < 12 && (y % 16) > 4 && (y % 16) < 13;
                    Color c = wall;
                    if (win) c = ((x / 16 * 31 + y / 16 * 17 + seed) % 5 == 0) ? new Color(1f, 0.9f, 0.5f) : new Color(0.25f, 0.35f, 0.5f);
                    t.SetPixel(x, y, c);
                }
            t.Apply();
            cache[k] = t;
            return t;
        }

        public static Texture2D ProductPack(ProductData product)
        {
            string key = "pack:" + product.id + ColorUtility.ToHtmlStringRGB(product.packColor) + ColorUtility.ToHtmlStringRGB(product.accentColor);
            if (cache.TryGetValue(key, out var texture) && texture != null) return texture;
            const int size = 128;
            texture = new Texture2D(size, size, TextureFormat.RGBA32, true)
            { name = "ProceduralPack_" + product.id, wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            Color baseColor = product.packColor;
            Color accent = product.accentColor;
            Color light = Color.Lerp(baseColor, Color.white, 0.72f);
            Color dark = Color.Lerp(baseColor, Color.black, 0.4f);
            // Fine print grain and a soft vertical foil sheen make the package read as a real wrapper,
            // while deterministic noise keeps generated products stable across launches.
            var rng = new System.Random(product.id != null ? product.id.GetHashCode() : 7);
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float sheen = 0.94f + 0.09f * Mathf.Sin((x / (float)size) * Mathf.PI * 2f);
                    float grain = (float)rng.NextDouble() * 0.035f - 0.0175f;
                    Color c = baseColor * sheen;
                    c.r = Mathf.Clamp01(c.r + grain); c.g = Mathf.Clamp01(c.g + grain); c.b = Mathf.Clamp01(c.b + grain);
                    texture.SetPixel(x, y, c);
                }

            // Crisp wrapper bands make each fictional pack readable at shelf scale.
            Fill(texture, 0, 0, size, 8, dark);
            Fill(texture, 0, 120, size, 8, dark);
            Fill(texture, 0, 100, size, 5, accent);
            Fill(texture, 0, 22, size, 5, accent);
            Fill(texture, 10, 30, 108, 62, light);
            // Framed front label with fine decorative rules and tiny print-like bars.
            Fill(texture, 13, 27, 102, 2, dark);
            Fill(texture, 13, 93, 102, 2, dark);
            Fill(texture, 20, 36, 88, 2, Color.Lerp(accent, Color.white, 0.32f));
            Fill(texture, 20, 84, 88, 2, Color.Lerp(accent, Color.white, 0.32f));
            for (int i = 0; i < 5; i++)
                Fill(texture, 25, 42 + i * 7, 42 + (i % 3) * 11, 1, Color.Lerp(dark, light, 0.35f));

            switch (product.category)
            {
                case ProductCategory.Cigarettes:
                    Fill(texture, 0, 48, 14, 32, accent);
                    Fill(texture, 114, 48, 14, 32, accent);
                    Fill(texture, 20, 32, 88, 4, dark);
                    Fill(texture, 20, 86, 88, 4, dark);
                    // A small gold seal and three fine pinstripes.
                    Fill(texture, 52, 44, 24, 3, new Color(0.88f, 0.7f, 0.28f));
                    Fill(texture, 52, 81, 24, 3, new Color(0.88f, 0.7f, 0.28f));
                    break;
                case ProductCategory.Devices:
                    for (int y = 32; y < 92; y += 12) Fill(texture, 16, y, 96, 3, accent);
                    Fill(texture, 40, 42, 48, 36, dark);
                    Fill(texture, 46, 48, 36, 24, accent);
                    break;
                case ProductCategory.Snacks:
                    for (int x = 20; x < 112; x += 18)
                        for (int y = 34; y < 90; y += 18) Circle(texture, x, y, 4, (x + y) % 2 == 0 ? accent : dark);
                    Fill(texture, 28, 50, 72, 22, light);
                    break;
                case ProductCategory.Drinks:
                    Fill(texture, 22, 32, 84, 58, dark);
                    Fill(texture, 28, 38, 72, 46, light);
                    for (int x = 34; x < 96; x += 15) Circle(texture, x, 44 + x % 3 * 8, 4, accent);
                    break;
                case ProductCategory.Press:
                    Fill(texture, 14, 30, 100, 5, accent);
                    Fill(texture, 18, 42, 92, 3, dark);
                    Fill(texture, 18, 50, 72, 3, dark);
                    Fill(texture, 18, 58, 86, 3, dark);
                    Fill(texture, 18, 68, 50, 18, accent);
                    break;
                default:
                    Fill(texture, 18, 34, 92, 54, dark);
                    Fill(texture, 24, 40, 80, 42, accent);
                    break;
            }
            Circle(texture, 64, 64, 12, accent);
            Circle(texture, 64, 64, 7, light);
            texture.Apply(true, true);
            cache[key] = texture;
            return texture;
        }

        public static Texture2D PackNormal(ProductData product)
        {
            string key = "normal:" + product.id;
            if (cache.TryGetValue(key, out var n) && n != null) return n;
            const int size = 64;
            n = new Texture2D(size, size, TextureFormat.RGBA32, true)
            { name = "ProceduralPackNormal_" + product.id, wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            var rng = new System.Random(product.id != null ? product.id.GetHashCode() : 11);
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float ripple = Mathf.Sin(x * 0.72f + y * 0.21f) * 0.018f + ((float)rng.NextDouble() - 0.5f) * 0.025f;
                    n.SetPixel(x, y, new Color(0.5f + ripple, 0.5f - ripple, 1f, 1f));
                }
            n.Apply(true, true);
            cache[key] = n;
            return n;
        }

        /// <summary>Ткань: 1 — полоска, 2 — клетка, 3 — горошек.</summary>
        public static Texture2D Fabric(Color baseColor, Color accent, int pattern)
        {
            string key = "fab" + ColorUtility.ToHtmlStringRGB(baseColor) + ColorUtility.ToHtmlStringRGB(accent) + pattern;
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            const int n = 32;
            t = new Texture2D(n, n, TextureFormat.RGBA32, true) { name = "ProceduralFabric", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            Color alt = Color.Lerp(baseColor, accent, 0.65f);
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    bool on;
                    switch (pattern)
                    {
                        case 1: on = (y / 4) % 2 == 0; break;
                        case 2: on = ((x / 8) + (y / 8)) % 2 == 0; break;
                        default:
                        {
                            float dx = (x % 16) - 8f, dy = (y % 16) - 8f;
                            on = dx * dx + dy * dy < 9f;
                            break;
                        }
                    }
                    float weave = ((x + y) % 2 == 0) ? 0.97f : 1.0f;
                    t.SetPixel(x, y, (on ? alt : baseColor) * weave);
                }
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        /// <summary>Бетон/асфальт: зернистый шум с трещинками.</summary>
        public static Texture2D Concrete(Color tint, int seed = 5, int res = 128)
        {
            string key = "conc" + ColorUtility.ToHtmlStringRGB(tint) + seed + res;
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            t = new Texture2D(res, res, TextureFormat.RGBA32, true) { name = "ProceduralConcrete", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            var rng = new System.Random(seed);
            for (int y = 0; y < res; y++)
                for (int x = 0; x < res; x++)
                {
                    float blot = Mathf.PerlinNoise(x * 0.05f + seed, y * 0.05f) * 0.14f - 0.07f;
                    float grain = ((float)rng.NextDouble() - 0.5f) * 0.09f;
                    float crack = (Mathf.Abs(Mathf.Sin(x * 0.11f + y * 0.07f + seed)) < 0.012f) ? -0.12f : 0f;
                    Color c = tint * (1f + blot + grain + crack);
                    c.a = 1f;
                    t.SetPixel(x, y, c);
                }
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        /// <summary>Плитка тротуара: квадратные плиты со швами.</summary>
        public static Texture2D Paving(Color tint, int seed = 9, int res = 128)
        {
            string key = "pave" + ColorUtility.ToHtmlStringRGB(tint) + seed + res;
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            t = new Texture2D(res, res, TextureFormat.RGBA32, true) { name = "ProceduralPaving", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            var rng = new System.Random(seed);
            int cell = res / 4;
            float[] shade = new float[16];
            for (int i = 0; i < shade.Length; i++) shade[i] = (float)rng.NextDouble() * 0.12f - 0.06f;
            for (int y = 0; y < res; y++)
                for (int x = 0; x < res; x++)
                {
                    int ci = (x / cell) + (y / cell) * 4;
                    Color c = tint * (1f + shade[ci % 16] + ((float)rng.NextDouble() - 0.5f) * 0.04f);
                    if (x % cell < 2 || y % cell < 2) c = Color.Lerp(c, Color.black, 0.28f);
                    c.a = 1f;
                    t.SetPixel(x, y, c);
                }
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        /// <summary>Полосатая маркиза (чередующиеся вертикальные полосы).</summary>
        public static Texture2D Awning(Color a, Color b)
        {
            string key = "awn" + ColorUtility.ToHtmlStringRGB(a) + ColorUtility.ToHtmlStringRGB(b);
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            const int w = 64, h = 16;
            t = new Texture2D(w, h, TextureFormat.RGBA32, true) { name = "ProceduralAwning", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    Color c = ((x / 8) % 2 == 0) ? a : b;
                    c *= 0.94f + 0.06f * Mathf.Sin(x * 0.4f);
                    c.a = 1f;
                    t.SetPixel(x, y, c);
                }
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        /// <summary>Кирпичная кладка для фасадов домов на заднем плане улицы.</summary>
        public static Texture2D Brick(Color tint, int seed = 2, int res = 128)
        {
            string key = "brick" + ColorUtility.ToHtmlStringRGB(tint) + seed + res;
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            t = new Texture2D(res, res, TextureFormat.RGBA32, true) { name = "ProceduralBrick", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            var rng = new System.Random(seed);
            int bh = res / 8, bw = res / 4;
            for (int y = 0; y < res; y++)
                for (int x = 0; x < res; x++)
                {
                    int row = y / bh;
                    int xx = (x + (row % 2) * (bw / 2)) % res;
                    bool mortar = (y % bh) < 2 || (xx % bw) < 2;
                    float v = 1f + ((float)rng.NextDouble() - 0.5f) * 0.14f;
                    Color c = mortar ? new Color(0.78f, 0.76f, 0.7f) : tint * v;
                    c.a = 1f;
                    t.SetPixel(x, y, c);
                }
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        static void Fill(Texture2D tex, int x, int y, int width, int height, Color c)
        {
            for (int py = Mathf.Max(0, y); py < Mathf.Min(tex.height, y + height); py++)
                for (int px = Mathf.Max(0, x); px < Mathf.Min(tex.width, x + width); px++) tex.SetPixel(px, py, c);
        }

        static void Circle(Texture2D tex, int cx, int cy, int radius, Color c)
        {
            for (int y = -radius; y <= radius; y++)
                for (int x = -radius; x <= radius; x++)
                    if (x * x + y * y <= radius * radius) tex.SetPixel(cx + x, cy + y, c);
        }
    }

    /// <summary>Быстрые примитивы на общих мешах (без лишних коллайдеров).</summary>
    public static class Prim
    {
        static readonly Dictionary<PrimitiveType, Mesh> meshes = new Dictionary<PrimitiveType, Mesh>();

        static Mesh MeshOf(PrimitiveType t)
        {
            if (meshes.TryGetValue(t, out var m) && m != null) return m;
            var g = GameObject.CreatePrimitive(t);
            m = g.GetComponent<MeshFilter>().sharedMesh;
            Object.Destroy(g);
            meshes[t] = m;
            return m;
        }

        public static GameObject Shape(PrimitiveType t, Transform parent, string name, Vector3 pos, Vector3 scale, Material mat)
        {
            var g = new GameObject(name);
            g.transform.SetParent(parent, false);
            g.transform.localPosition = pos;
            g.transform.localScale = scale;
            g.AddComponent<MeshFilter>().sharedMesh = MeshOf(t);
            g.AddComponent<MeshRenderer>().sharedMaterial = mat;
            return g;
        }

        public static GameObject Cube(Transform parent, string name, Vector3 pos, Vector3 size, Material mat, bool collider = true)
        {
            var g = Shape(PrimitiveType.Cube, parent, name, pos, size, mat);
            if (collider) g.AddComponent<BoxCollider>();
            return g;
        }

        /// <summary>Цилиндр: height — полная высота, diameter — диаметр.</summary>
        public static GameObject Cyl(Transform parent, string name, Vector3 pos, float diameter, float height, Material mat)
            => Shape(PrimitiveType.Cylinder, parent, name, pos, new Vector3(diameter, height / 2f, diameter), mat);

        public static GameObject Sphere(Transform parent, string name, Vector3 pos, float diameter, Material mat)
            => Shape(PrimitiveType.Sphere, parent, name, pos, Vector3.one * diameter, mat);

        public static GameObject Capsule(Transform parent, string name, Vector3 pos, float diameter, float height, Material mat)
            => Shape(PrimitiveType.Capsule, parent, name, pos, new Vector3(diameter, height / 2f, diameter), mat);
    }
}
