using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    public struct ShelfSpot { public Vector3 pos; public float yaw; }

    /// <summary>
    /// Строит помещение, полки, склад и декор по текущим улучшениям.
    /// Прилавок, касса и компьютер постоянны и создаются один раз (Fixtures).
    /// </summary>
    public class KioskBuilder : MonoBehaviour
    {
        public static KioskBuilder I;
        public static readonly float[] RoomW = { 3.0f, 4.4f, 5.8f };
        public static readonly float[] RoomD = { 3.0f, 3.8f, 4.6f };
        /// <summary>Место, где стоят покупатели у окна (снаружи киоска).</summary>
        public static readonly Vector3 CustomerSpot = new Vector3(0f, 0f, -1.0f);
        public static readonly Vector3 PlayerSpawn = new Vector3(0f, 0f, 0.9f);
        /// <summary>Высота поддона на складе: коробки стоят на нём, а не висят в воздухе.</summary>
        public const float PalletH = 0.12f;
        const float Eps = 1e-3f;

        public readonly List<ShelfSlot> Slots = new List<ShelfSlot>();
        public readonly List<Vector3> StoragePoints = new List<Vector3>();
        public Transform Root, Fixtures;
        public CashRegister Register;

        int Lvl => GameSession.Data.Up(UpgradeType.Size);

        /// <summary>Точка внутри помещения киоска (за стенами)? Нужно, чтобы запирать дверь только снаружи.</summary>
        public bool IsInside(Vector3 p)
        {
            float w = RoomW[Lvl], d = RoomD[Lvl];
            return p.z > 0.05f && p.z < d && Mathf.Abs(p.x) < w / 2f;
        }

        /// <summary>Возможные места для полок. Стеллажи не пересекают склад и друг друга.</summary>
        public static List<ShelfSpot> ShelfCandidates(float w, float d)
        {
            var list = new List<ShelfSpot>();
            var left = new List<float>();
            var right = new List<float>();
            for (float z = 0.4f; z <= d - 0.5f + Eps; z += 0.7f) left.Add(z);
            // Leave the side-door opening (z 0.6–1.6) clear.
            for (float z = 1.9f; z <= d - 0.45f + Eps; z += 0.7f) right.Add(z);
            for (int i = 0; i < Mathf.Max(left.Count, right.Count); i++)
            {
                if (i < left.Count) list.Add(new ShelfSpot { pos = new Vector3(-w / 2f + 0.03f, 0f, left[i]), yaw = 90f });
                if (i < right.Count) list.Add(new ShelfSpot { pos = new Vector3(w / 2f - 0.03f, 0f, right[i]), yaw = -90f });
            }
            for (float x = -w / 2f + 1.0f; x <= w / 2f - 2.4f + Eps; x += 0.7f)
                list.Add(new ShelfSpot { pos = new Vector3(x, 0f, d - 0.03f), yaw = 180f });
            return list;
        }

        public static bool CanFitShelves(int slots, int roomLvl) =>
            ShelfCandidates(RoomW[roomLvl], RoomD[roomLvl]).Count >= slots;

        void Awake()
        {
            I = this;
            ThemeManager.Changed += OnTheme;
        }

        void OnDestroy() { ThemeManager.Changed -= OnTheme; }

        void OnTheme() { if (Root != null) Build(); }

        public void Build()
        {
            if (Fixtures == null) BuildFixtures();
            if (Root != null) Destroy(Root.gameObject);
            Root = new GameObject("Room").transform;
            Root.SetParent(transform, false);
            Slots.Clear();
            StoragePoints.Clear();

            var data = GameSession.Data;
            float w = RoomW[Lvl], d = RoomD[Lvl];
            int dec = data.Up(UpgradeType.Decor);
            var theme = ThemeManager.Current;
            Color[] wallCols =
            {
                new Color(0.93f, 0.87f, 0.76f), new Color(0.70f, 0.90f, 0.82f),
                new Color(0.97f, 0.72f, 0.52f), new Color(0.16f, 0.14f, 0.24f)
            };
            var wall = Mats.Solid(wallCols[dec], 0.2f);
            var trim = Mats.Solid(new Color(0.96f, 0.96f, 0.94f), 0.3f);
            Material floor = dec == 0
                ? Mats.Textured(TexGen.Wood(new Color(0.56f, 0.39f, 0.25f), 14), new Vector2(w * 1.6f, d * 1.6f), 0.35f)
                : Mats.Textured(TexGen.Checker(new Color(0.92f, 0.9f, 0.85f), new Color(0.35f, 0.3f, 0.28f), 2),
                    new Vector2(w, d), 0.3f);

            // пол, потолок, стены
            Prim.Cube(Root, "Floor", new Vector3(0, -0.05f, d / 2f), new Vector3(w, 0.1f, d), floor);
            Prim.Cube(Root, "Ceiling", new Vector3(0, 3f, d / 2f), new Vector3(w, 0.1f, d), trim, false);
            Prim.Cube(Root, "Back", new Vector3(0, 1.5f, d + 0.05f), new Vector3(w + 0.2f, 3f, 0.1f), wall);
            Prim.Cube(Root, "WallL", new Vector3(-w / 2f - 0.05f, 1.5f, d / 2f), new Vector3(0.1f, 3f, d), wall);
            // правая стена с проёмом двери (z 0.6–1.6)
            Prim.Cube(Root, "WallRFront", new Vector3(w / 2f + 0.05f, 1.5f, 0.3f), new Vector3(0.1f, 3f, 0.6f), wall);
            Prim.Cube(Root, "WallRBack", new Vector3(w / 2f + 0.05f, 1.5f, (1.6f + d) / 2f), new Vector3(0.1f, 3f, d - 1.6f), wall);
            Prim.Cube(Root, "WallRLintel", new Vector3(w / 2f + 0.05f, 2.6f, 1.1f), new Vector3(0.1f, 0.8f, 1.0f), wall);

            // передняя стена с окном выдачи (x −0.6…0.6, y 0.9…2.2)
            float wl = w / 2f - 0.6f;
            Prim.Cube(Root, "FrontL", new Vector3(-0.6f - wl / 2f, 1.5f, -0.05f), new Vector3(wl, 3f, 0.1f), wall);
            Prim.Cube(Root, "FrontR", new Vector3(0.6f + wl / 2f, 1.5f, -0.05f), new Vector3(wl, 3f, 0.1f), wall);
            Prim.Cube(Root, "FrontTop", new Vector3(0f, 2.6f, -0.05f), new Vector3(1.2f, 0.8f, 0.1f), wall);
            Prim.Cube(Root, "FrontBottom", new Vector3(0f, 0.45f, -0.05f), new Vector3(1.2f, 0.9f, 0.1f), wall);
            Prim.Cube(Root, "WindowTrim", new Vector3(0f, 2.22f, -0.1f), new Vector3(1.3f, 0.05f, 0.05f), trim, false);

            // вывеска над окном
            Prim.Cube(Root, "ShopSign", new Vector3(0f, 2.8f, -0.12f), new Vector3(1.4f, 0.28f, 0.05f),
                Mats.Emissive(theme.neon, 1.1f), false);

            KioskDoor.Create(Root, new Vector3(w / 2f, 0f, 0.6f), Mats.Solid(new Color(0.42f, 0.28f, 0.18f), 0.25f));
            BuildExterior(w, d, dec, theme);
            BuildShowcase(data.Up(UpgradeType.Display));
            BuildRegisterUpgrade(data.Up(UpgradeType.Register));

            // декор по уровню оформления
            if (dec >= 1)
            {
                var pot = Mats.Solid(new Color(0.6f, 0.35f, 0.2f));
                Prim.Cyl(Root, "Pot", new Vector3(w / 2f - 0.3f, 0.2f, 0.3f), 0.3f, 0.4f, pot);
                Prim.Sphere(Root, "Plant", new Vector3(w / 2f - 0.3f, 0.6f, 0.3f), 0.4f, Mats.Solid(new Color(0.25f, 0.6f, 0.3f)));
            }
            if (dec == 3)
                Prim.Cube(Root, "Neon", new Vector3(0f, 2.3f, d - 0.06f), new Vector3(1.6f, 0.25f, 0.03f),
                    Mats.Emissive(theme.neon, 2f), false);

            // склад: поддоны (4×3). Открытые уровнем «Склад» — деревянные, закрытые — под жёлто-чёрной лентой.
            int storageOpen = UpgradeCatalog.StorageSlots[data.Up(UpgradeType.Storage)];
            var palletMat = Mats.Textured(TexGen.Wood(new Color(0.62f, 0.45f, 0.28f), 51), new Vector2(1f, 1f), 0.25f);
            var lockedMat = Mats.Solid(new Color(0.22f, 0.22f, 0.25f), 0.2f);
            var hazard = Mats.Solid(new Color(0.98f, 0.8f, 0.2f), 0.3f);
            int idx = 0;
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 4; c++, idx++)
                {
                    float px = w / 2f - 1.0f - c * 0.4f, pz = d - 0.85f - r * 0.4f;
                    StoragePoints.Add(new Vector3(px, PalletH, pz));
                    if (idx < storageOpen)
                    {
                        Prim.Cube(Root, "Pallet", new Vector3(px, PalletH / 2f, pz), new Vector3(0.38f, PalletH, 0.34f), palletMat);
                        Prim.Cube(Root, "Pallet gap", new Vector3(px, PalletH * 0.35f, pz), new Vector3(0.381f, 0.025f, 0.341f), lockedMat, false);
                    }
                    else
                    {
                        Prim.Cube(Root, "Locked slot", new Vector3(px, 0.006f, pz), new Vector3(0.38f, 0.012f, 0.34f), lockedMat, false);
                        Prim.Cube(Root, "Locked tape A", new Vector3(px, 0.013f, pz), new Vector3(0.44f, 0.004f, 0.035f), hazard, false).transform.localRotation = Quaternion.Euler(0f, 40f, 0f);
                        Prim.Cube(Root, "Locked tape B", new Vector3(px, 0.013f, pz), new Vector3(0.44f, 0.004f, 0.035f), hazard, false).transform.localRotation = Quaternion.Euler(0f, -40f, 0f);
                    }
                }

            // полки
            var cands = ShelfCandidates(w, d);
            int n = Mathf.Min(UpgradeCatalog.ShelfSlots[data.Up(UpgradeType.Shelves)], cands.Count);
            var shelfMat = Mats.Textured(TexGen.Wood(new Color(0.45f, 0.28f, 0.16f), 27), new Vector2(2f, 2f), 0.34f);
            const float depth = 0.45f;
            for (int i = 0; i < n; i++)
            {
                var sp = cands[i];
                var holder = new GameObject("Shelf" + i).transform;
                holder.SetParent(Root, false);
                holder.localPosition = sp.pos;
                holder.localRotation = Quaternion.Euler(0f, sp.yaw, 0f);
                Prim.Cube(holder, "Back", new Vector3(0, 1.05f, 0.015f), new Vector3(0.7f, 2.1f, 0.03f), shelfMat);
                Prim.Cube(holder, "SideL", new Vector3(-0.335f, 1.05f, depth / 2f), new Vector3(0.03f, 2.1f, depth), shelfMat);
                Prim.Cube(holder, "SideR", new Vector3(0.335f, 1.05f, depth / 2f), new Vector3(0.03f, 2.1f, depth), shelfMat);
                foreach (float by in new[] { 0.45f, 1.0f, 1.55f, 2.1f })
                    Prim.Cube(holder, "Board", new Vector3(0, by, depth / 2f), new Vector3(0.7f, 0.035f, depth), shelfMat);
                var slot = holder.gameObject.AddComponent<ShelfSlot>();
                slot.Init(i);
                Slots.Add(slot);
            }

            // освещение комнаты
            var lgo = new GameObject("Lamp");
            lgo.transform.SetParent(Root, false);
            lgo.transform.localPosition = new Vector3(0f, 2.6f, d * 0.5f);
            var lt = lgo.AddComponent<Light>();
            lt.type = LightType.Point;
            lt.range = Mathf.Max(w, d) * 1.6f;
            lt.intensity = dec == 3 ? 1.6f : 1.1f;
            lt.color = theme.lamp;
            lt.shadows = LightShadows.None;
            // тёплая лампа над кассой с мягкими тенями
            var spot = new GameObject("Counter lamp");
            spot.transform.SetParent(Root, false);
            spot.transform.localPosition = new Vector3(0f, 2.75f, 0.55f);
            spot.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            var sl = spot.AddComponent<Light>();
            sl.type = LightType.Spot;
            sl.spotAngle = 95f;
            sl.range = 4.5f;
            sl.intensity = 1.1f;
            sl.color = Color.Lerp(theme.lamp, Color.white, 0.3f);
            sl.shadows = LightShadows.Soft;
            Prim.Cyl(Root, "Lamp shade", new Vector3(0f, 2.86f, 0.55f), 0.34f, 0.12f, Mats.Solid(new Color(0.16f, 0.17f, 0.2f), 0.5f));
            Prim.Cyl(Root, "Lamp bulb", new Vector3(0f, 2.78f, 0.55f), 0.16f, 0.03f, Mats.Emissive(theme.lamp, 2.5f));
            RenderSettings.ambientLight = Color.Lerp(theme.sky, Color.white, 0.4f) * 0.6f;

            if (StockManager.I != null) StockManager.I.RelocateBoxes();
            if (SecurityManager.I != null) SecurityManager.I.Rebuild(Root);   // камеры/охрана перестраиваются вместе с комнатой
        }

        // ================= фасад, витрина, касса по уровням =================
        void BuildExterior(float w, float d, int dec, Theme theme)
        {
            var trim = Mats.Solid(new Color(0.96f, 0.96f, 0.94f), 0.3f);
            var frame = Mats.Solid(new Color(0.18f, 0.19f, 0.22f), 0.45f);
            Color[] awnA = { new Color(0.86f, 0.2f, 0.2f), new Color(0.15f, 0.65f, 0.6f), new Color(0.95f, 0.5f, 0.15f), new Color(0.55f, 0.2f, 0.85f) };
            var awning = Mats.TexturedCached("awn" + dec, TexGen.Awning(awnA[dec], new Color(0.97f, 0.95f, 0.9f)), new Vector2(4f, 1f), 0.25f);

            // кирпичная облицовка по обе стороны окна
            float wl = w / 2f - 0.6f;
            var brick = Mats.TexturedCached("brick", TexGen.Brick(new Color(0.72f, 0.38f, 0.28f)), new Vector2(wl * 1.4f, 2.4f), 0.15f);
            Prim.Cube(Root, "Facade L", new Vector3(-0.6f - wl / 2f, 1.5f, -0.115f), new Vector3(wl, 3f, 0.03f), brick, false);
            Prim.Cube(Root, "Facade R", new Vector3(0.6f + wl / 2f, 1.5f, -0.115f), new Vector3(wl, 3f, 0.03f), brick, false);

            // рама окна выдачи и наружный подоконник-прилавок
            Prim.Cube(Root, "Window frame L", new Vector3(-0.6f, 1.55f, -0.08f), new Vector3(0.06f, 1.38f, 0.08f), frame, false);
            Prim.Cube(Root, "Window frame R", new Vector3(0.6f, 1.55f, -0.08f), new Vector3(0.06f, 1.38f, 0.08f), frame, false);
            Prim.Cube(Root, "Window frame top", new Vector3(0f, 2.22f, -0.08f), new Vector3(1.26f, 0.06f, 0.08f), frame, false);
            Prim.Cube(Root, "Window ledge", new Vector3(0f, 0.93f, -0.27f), new Vector3(1.5f, 0.05f, 0.42f),
                Mats.Textured(TexGen.Wood(new Color(0.55f, 0.36f, 0.22f), 61), new Vector2(2f, 1f), 0.4f));

            // полосатая маркиза над окном
            var aw = Prim.Cube(Root, "Awning", new Vector3(0f, 2.62f, -0.7f), new Vector3(2.1f, 0.04f, 1.25f), awning, false);
            aw.transform.localRotation = Quaternion.Euler(-13f, 0f, 0f);
            Prim.Cube(Root, "Awning valance", new Vector3(0f, 2.42f, -1.28f), new Vector3(2.1f, 0.14f, 0.03f), awning, false);
            Prim.Cube(Root, "Awning arm L", new Vector3(-1.0f, 2.45f, -0.62f), new Vector3(0.03f, 0.03f, 1.2f), frame, false);
            Prim.Cube(Root, "Awning arm R", new Vector3(1.0f, 2.45f, -0.62f), new Vector3(0.03f, 0.03f, 1.2f), frame, false);

            // крыша с парапетом
            var roofMat = Mats.TexturedCached("roof", TexGen.Concrete(new Color(0.42f, 0.43f, 0.46f), 8), new Vector2(w, d), 0.15f);
            Prim.Cube(Root, "Roof", new Vector3(0f, 3.13f, d / 2f - 0.05f), new Vector3(w + 0.5f, 0.16f, d + 0.5f), roofMat, false);
            Prim.Cube(Root, "Roof edge", new Vector3(0f, 3.0f, -0.32f), new Vector3(w + 0.5f, 0.1f, 0.06f), trim, false);

        }

        /// <summary>Витрина с товарами у окна: чем выше уровень «Витрина», тем больше полок и подсветка.</summary>
        void BuildShowcase(int level)
        {
            Vector3 c = new Vector3(-1.05f, 0f, -0.34f);
            var wood = Mats.Textured(TexGen.Wood(new Color(0.48f, 0.3f, 0.19f), 39), new Vector2(1f, 1f), 0.4f);
            var glass = Mats.Glass(new Color(0.75f, 0.9f, 1f, 0.18f));
            var metal = Mats.Metal(new Color(0.7f, 0.72f, 0.75f));
            Prim.Cube(Root, "Showcase base", c + new Vector3(0f, 0.25f, 0f), new Vector3(0.8f, 0.5f, 0.36f), wood);
            float h = 0.35f + 0.28f * (level + 1);
            Prim.Cube(Root, "Showcase glass", c + new Vector3(0f, 0.5f + h / 2f, 0f), new Vector3(0.78f, h, 0.34f), glass, false);
            foreach (float sx in new[] { -0.39f, 0.39f })
                foreach (float sz in new[] { -0.17f, 0.17f })
                    Prim.Cube(Root, "Showcase post", c + new Vector3(sx, 0.5f + h / 2f, sz), new Vector3(0.02f, h, 0.02f), metal, false);
            Prim.Cube(Root, "Showcase top", c + new Vector3(0f, 0.5f + h + 0.01f, 0f), new Vector3(0.8f, 0.02f, 0.36f), metal, false);
            Prim.Cube(Root, "Showcase light", c + new Vector3(0f, 0.5f + h - 0.02f, 0f), new Vector3(0.7f, 0.01f, 0.28f),
                Mats.Emissive(level >= 3 ? ThemeManager.Current.neon : new Color(1f, 0.95f, 0.8f), 1.2f + level * 0.4f), false);

            // товары на полках: только открытые на текущем уровне
            var shown = new List<ProductData>();
            foreach (var p in GameDatabase.Products) if (p.unlockLevel <= level) shown.Add(p);
            if (shown.Count == 0) return;
            int tiers = level + 1, n = 0;
            for (int t = 0; t < tiers; t++)
            {
                Prim.Cube(Root, "Showcase tier", c + new Vector3(0f, 0.52f + t * 0.28f, 0f), new Vector3(0.76f, 0.015f, 0.32f), glass, false);
                for (int i = 0; i < 5; i++, n++)
                {
                    var p = shown[n % shown.Count];
                    var s = p.packSize;
                    var pack = Prim.Cube(Root, "Display " + p.id, c + new Vector3(-0.3f + i * 0.15f, 0.53f + t * 0.28f + s.y / 2f, 0f), s,
                        Mats.ProductPack(p), false);
                    pack.transform.localRotation = Quaternion.Euler(0f, Mathf.Sin(n * 1.7f) * 14f, 0f);
                }
            }
        }

        /// <summary>Касса меняет вид по уровню: принтер чеков → сканер штрихкодов → платёжный терминал.</summary>
        void BuildRegisterUpgrade(int level)
        {
            if (level <= 0) return;
            Vector3 r = new Vector3(0.62f, 1.03f, 0.3f);
            var dark = Mats.Solid(new Color(0.1f, 0.11f, 0.14f), 0.5f);
            var light = Mats.Solid(new Color(0.88f, 0.9f, 0.92f), 0.5f);
            // принтер чеков с бумажной лентой
            Prim.Cube(Root, "Receipt printer", r + new Vector3(0.24f, 0.05f, 0.04f), new Vector3(0.11f, 0.1f, 0.14f), dark, false);
            Prim.Cube(Root, "Receipt paper", r + new Vector3(0.24f, 0.13f, 0.06f), new Vector3(0.05f, 0.1f, 0.004f), light, false);
            if (level >= 2)
            {
                // настольный сканер с красным окном
                Prim.Cube(Root, "Scanner base", r + new Vector3(-0.34f, 0.02f, 0.1f), new Vector3(0.16f, 0.04f, 0.12f), dark, false);
                Prim.Cube(Root, "Scanner glass", r + new Vector3(-0.34f, 0.042f, 0.1f), new Vector3(0.12f, 0.004f, 0.08f),
                    Mats.Emissive(new Color(1f, 0.1f, 0.1f), 1.6f), false);
                var arm = Prim.Cube(Root, "Scanner arm", r + new Vector3(-0.34f, 0.12f, 0.03f), new Vector3(0.03f, 0.16f, 0.03f), dark, false);
                arm.transform.localRotation = Quaternion.Euler(-12f, 0f, 0f);
            }
            if (level >= 3)
            {
                // платёжный терминал с зелёным экраном и второй дисплей покупателя
                Prim.Cube(Root, "Card terminal", r + new Vector3(0.03f, 0.04f, 0.22f), new Vector3(0.1f, 0.05f, 0.15f), dark, false)
                    .transform.localRotation = Quaternion.Euler(-18f, 0f, 0f);
                Prim.Cube(Root, "Terminal screen", r + new Vector3(0.03f, 0.065f, 0.215f), new Vector3(0.07f, 0.003f, 0.05f),
                    Mats.Emissive(new Color(0.3f, 1f, 0.5f), 1.6f), false).transform.localRotation = Quaternion.Euler(-18f, 0f, 0f);
                Prim.Cube(Root, "Customer display", r + new Vector3(0.08f, 0.36f, -0.12f), new Vector3(0.2f, 0.1f, 0.015f),
                    Mats.Emissive(new Color(0.4f, 0.9f, 0.95f), 1.2f), false);
            }
        }

        void BuildFixtures()
        {
            Fixtures = new GameObject("Fixtures").transform;
            Fixtures.SetParent(transform, false);
            var wood = Mats.Textured(TexGen.Wood(new Color(0.48f, 0.3f, 0.19f), 39), new Vector2(2f, 2f), 0.44f);
            Prim.Cube(Fixtures, "CounterBody", new Vector3(0, 0.5f, 0.28f), new Vector3(1.7f, 1.0f, 0.46f), wood);
            Prim.Cube(Fixtures, "CounterTop", new Vector3(0, 1.015f, 0.28f), new Vector3(1.76f, 0.03f, 0.52f),
                Mats.Solid(new Color(0.88f, 0.84f, 0.78f), 0.5f));
            Register = CashRegister.Create(Fixtures, new Vector3(0.62f, 1.03f, 0.3f));
            ComputerTerminal.Create(Fixtures, new Vector3(-0.62f, 1.03f, 0.3f));
            KioskSign.Create(Fixtures, new Vector3(-0.95f, 1.7f, -0.12f));
            KioskShutter.Create(Fixtures, new Vector3(0f, 1.55f, -0.05f));
        }
    }

    /// <summary>Дверь киоска: открывается наружу.</summary>
    public class KioskDoor : Interactable
    {
        public static KioskDoor I;
        public bool IsOpen;
        Transform pivot;
        GameObject padlock;

        // Замок хранится статически: пристройка/улучшение пересобирает комнату, но запертый киоск остаётся запертым.
        static bool locked;
        public static bool IsLocked => locked;
        public static void ResetLock() { locked = false; }
        public static void SetLocked(bool v)
        {
            if (locked == v) return;
            locked = v;
            if (v && I != null) I.IsOpen = false;
        }

        void Awake() { I = this; }
        void OnDestroy() { if (I == this) I = null; }

        public static KioskDoor Create(Transform parent, Vector3 hinge, Material mat)
        {
            var go = new GameObject("Door");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = hinge;
            var door = go.AddComponent<KioskDoor>();
            door.pivot = go.transform;
            Prim.Cube(go.transform, "Leaf", new Vector3(0f, 1.15f, 0.5f), new Vector3(0.05f, 2.3f, 1.0f), mat);
            // остеклённое окошко, рама и ручки с обеих сторон
            door.padlock = Prim.Cube(go.transform, "Padlock", new Vector3(0.07f, 1.0f, 0.88f), new Vector3(0.04f, 0.09f, 0.06f), Mats.Metal(new Color(0.95f, 0.78f, 0.2f)), false);
            Prim.Cube(go.transform, "Door glass", new Vector3(0f, 1.7f, 0.5f), new Vector3(0.06f, 0.6f, 0.5f), Mats.Glass(new Color(0.7f, 0.88f, 1f, 0.35f)), false);
            var frame = Mats.Solid(new Color(0.2f, 0.14f, 0.1f), 0.3f);
            Prim.Cube(go.transform, "Glass frame top", new Vector3(0f, 2.02f, 0.5f), new Vector3(0.07f, 0.04f, 0.56f), frame, false);
            Prim.Cube(go.transform, "Glass frame bottom", new Vector3(0f, 1.38f, 0.5f), new Vector3(0.07f, 0.04f, 0.56f), frame, false);
            var steel = Mats.Metal(new Color(0.8f, 0.82f, 0.85f));
            foreach (float hx in new[] { -0.06f, 0.06f })
                Prim.Cube(go.transform, "Handle", new Vector3(hx, 1.05f, 0.88f), new Vector3(0.03f, 0.03f, 0.16f), steel, false);
            return door;
        }

        bool? lastOpen;

        void Update()
        {
            if (pivot == null) return;
            if (locked) IsOpen = false;
            if (padlock != null && padlock.activeSelf != locked) padlock.SetActive(locked);
            if (lastOpen != IsOpen)
            {
                if (lastOpen != null) AudioManager.Play(IsOpen ? Sfx.DoorOpen : Sfx.DoorClose);
                lastOpen = IsOpen;
            }
            var target = Quaternion.Euler(0f, IsOpen ? 90f : 0f, 0f);
            pivot.localRotation = Quaternion.Lerp(pivot.localRotation, target, Time.deltaTime * 6f);
        }

        static bool Night => EconomyManager.I != null && EconomyManager.I.phase == Phase.Night;

        public override string Prompt(PlayerContext p)
        {
            if (locked) return Loc.Get("p.door.unlock");
            if (Night && !IsOpen) return Loc.Get("p.door.lock");
            return Loc.Get(IsOpen ? "p.door.close" : "p.door.open");
        }

        public override void Interact(PlayerContext p)
        {
            if (locked)
            {
                SetLocked(false);
                AudioManager.Play(Sfx.Click);
                Toast.Push(Loc.Get("t.unlocked"));
                return;
            }
            if (Night && !IsOpen)
            {
                // запирать нужно снаружи: ночь проводят дома, а не в киоске
                if (PlayerController.I != null && KioskBuilder.I != null && KioskBuilder.I.IsInside(PlayerController.I.transform.position))
                {
                    Toast.Warn(Loc.Get("t.lockOutside"));
                    return;
                }
                SetLocked(true);
                AudioManager.Play(Sfx.Click);
                Toast.Good(Loc.Get("t.locked"));
                return;
            }
            IsOpen = !IsOpen;
        }
    }

    /// <summary>Табличка «ОТКРЫТО / ЗАКРЫТО»: управляет днём.</summary>
    public class KioskSign : Interactable
    {
        Renderer rend;
        bool? lastOpen;

        public static KioskSign Create(Transform parent, Vector3 pos)
        {
            var go = new GameObject("OpenSign");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            var board = Prim.Cube(go.transform, "Board", Vector3.zero, new Vector3(0.5f, 0.22f, 0.04f),
                Mats.Solid(new Color(0.2f, 0.2f, 0.2f)), false);
            var s = go.AddComponent<KioskSign>();
            var bc = go.AddComponent<BoxCollider>();
            bc.size = new Vector3(0.5f, 0.22f, 0.12f);
            s.rend = board.GetComponent<Renderer>();
            return s;
        }

        void Update()
        {
            var e = EconomyManager.I;
            if (e == null || rend == null) return;
            bool open = e.phase == Phase.Open;
            if (lastOpen == open) return;
            lastOpen = open;
            rend.sharedMaterial = open
                ? Mats.Emissive(new Color(0.3f, 1f, 0.4f), 1.2f)
                : Mats.Emissive(new Color(1f, 0.25f, 0.2f), 0.8f);
        }

        public override string Prompt(PlayerContext p)
        {
            var e = EconomyManager.I;
            switch (e.phase)
            {
                case Phase.Closed: return Loc.Get("p.sign.open");
                case Phase.Open: return Loc.Get("p.sign.early");
                case Phase.Summary: return Loc.Get("p.sign.next");
                case Phase.Night: return Loc.Get("p.sign.night");
                default: return Loc.Get("p.sign.closing");
            }
        }

        public override void Interact(PlayerContext p)
        {
            var e = EconomyManager.I;
            switch (e.phase)
            {
                case Phase.Closed: e.StartDay(); break;
                case Phase.Open: e.CloseEarly(); break;
                case Phase.Summary: e.NextDay(); break;
                case Phase.Night: Toast.Push(Loc.Get("t.nightHint")); break;
            }
        }
    }

    /// <summary>Рольставня окна выдачи: опускается, когда киоск заперт на ночь (прячется в верхней части стены).</summary>
    public class KioskShutter : MonoBehaviour
    {
        const float Travel = 1.3f;
        Transform slab;
        BoxCollider col;
        float t;                       // 0 — поднята, 1 — опущена
        bool? lastLocked;

        public static KioskShutter Create(Transform parent, Vector3 pos)
        {
            var go = new GameObject("Window shutter");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            var s = go.AddComponent<KioskShutter>();
            s.slab = new GameObject("Slab").transform;
            s.slab.SetParent(go.transform, false);
            s.slab.localPosition = new Vector3(0f, Travel, 0f);
            var steel = Mats.Metal(new Color(0.55f, 0.57f, 0.6f), 0.5f);
            var groove = Mats.Solid(new Color(0.3f, 0.32f, 0.35f), 0.4f);
            Prim.Cube(s.slab, "Shutter plate", Vector3.zero, new Vector3(1.2f, 1.3f, 0.04f), steel, false);
            for (int i = 0; i < 9; i++)
                Prim.Cube(s.slab, "Slat groove", new Vector3(0f, -0.56f + i * 0.14f, -0.022f), new Vector3(1.2f, 0.012f, 0.012f), groove, false);
            s.col = s.slab.gameObject.AddComponent<BoxCollider>();
            s.col.size = new Vector3(1.2f, 1.3f, 0.06f);
            s.col.enabled = false;
            return s;
        }

        void Update()
        {
            bool lk = KioskDoor.IsLocked;
            if (lastLocked != lk)
            {
                if (lastLocked != null) AudioManager.Play(Sfx.DoorClose);
                lastLocked = lk;
            }
            t = Mathf.MoveTowards(t, lk ? 1f : 0f, Time.deltaTime * 0.9f);
            slab.localPosition = new Vector3(0f, Mathf.Lerp(Travel, 0f, t), 0f);
            col.enabled = t > 0.95f;
        }
    }
}
