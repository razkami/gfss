using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Дом игрока на ближней улице: после закрытия киоска нужно вернуться сюда и лечь спать.
    /// Если киоск не заперт, ночью его грабят (см. ThiefSpawner).
    /// </summary>
    public class HomeDoor : Interactable, IWorldLabel
    {
        public static readonly Vector3 DoorPos = new Vector3(-15.5f, 0f, -1.56f);
        public static readonly Vector3 FrontPos = new Vector3(-15.5f, 0f, -3.2f);
        float confirmUntil;

        /// <summary>Подъезд к дому: дверь, крыльцо, окна с тёплым светом, цветы, почтовый ящик и лампа над входом.</summary>
        public static void Build(Transform parent)
        {
            var frame = Mats.Solid(new Color(0.9f, 0.88f, 0.82f), 0.3f);
            var doorMat = Mats.Solid(new Color(0.16f, 0.45f, 0.5f), 0.35f);
            var brass = Mats.Metal(new Color(0.95f, 0.78f, 0.25f));
            var warm = Mats.Emissive(new Color(1f, 0.82f, 0.45f), 1.1f);
            Vector3 p = DoorPos;

            Prim.Cube(parent, "Home door frame", p + new Vector3(0f, 1.15f, -0.02f), new Vector3(1.3f, 2.3f, 0.1f), frame, false);
            Prim.Cube(parent, "Home door", p + new Vector3(0f, 1.05f, -0.08f), new Vector3(1.0f, 2.1f, 0.08f), doorMat, false);
            Prim.Cube(parent, "Home door glass", p + new Vector3(0f, 1.6f, -0.125f), new Vector3(0.5f, 0.5f, 0.02f), warm, false);
            Prim.Sphere(parent, "Home door knob", p + new Vector3(0.38f, 1.0f, -0.15f), 0.07f, brass);
            Prim.Cube(parent, "Home step", p + new Vector3(0f, 0.06f, -0.4f), new Vector3(1.7f, 0.12f, 0.7f), Mats.Solid(new Color(0.62f, 0.6f, 0.58f), 0.2f), false);
            Prim.Cube(parent, "Home number plate", p + new Vector3(-0.85f, 1.6f, -0.05f), new Vector3(0.22f, 0.14f, 0.03f), brass, false);

            // тёплые окна
            foreach (float wx in new[] { -19.2f, -17.3f })
            {
                Prim.Cube(parent, "Home window", new Vector3(wx, 1.7f, -1.52f), new Vector3(1.1f, 1.2f, 0.04f), warm, false);
                Prim.Cube(parent, "Home window sill", new Vector3(wx, 1.06f, -1.6f), new Vector3(1.3f, 0.06f, 0.2f), frame, false);
            }

            // цветы у входа, почтовый ящик
            var pot = Mats.Solid(new Color(0.6f, 0.35f, 0.2f));
            foreach (float px in new[] { -0.95f, 0.95f })
            {
                Prim.Cyl(parent, "Home pot", p + new Vector3(px, 0.2f, -0.45f), 0.34f, 0.4f, pot);
                Prim.Sphere(parent, "Home plant", p + new Vector3(px, 0.6f, -0.45f), 0.5f, Mats.Solid(new Color(0.25f, 0.6f, 0.3f)));
            }
            Prim.Cube(parent, "Mailbox post", new Vector3(-13.9f, 0.45f, -2.4f), new Vector3(0.06f, 0.9f, 0.06f), Mats.Metal(new Color(0.25f, 0.27f, 0.3f)), false);
            Prim.Cube(parent, "Mailbox", new Vector3(-13.9f, 0.95f, -2.4f), new Vector3(0.3f, 0.2f, 0.4f), Mats.Solid(new Color(0.2f, 0.4f, 0.8f), 0.4f), false);

            // лампа над входом (DayNight включает её вечером)
            Prim.Cube(parent, "Porch lamp", p + new Vector3(0f, 2.45f, -0.18f), new Vector3(0.24f, 0.14f, 0.14f), Mats.Emissive(new Color(1f, 0.9f, 0.65f), 2f), false);
            var l = new GameObject("Porch light").AddComponent<Light>();
            l.transform.SetParent(parent, false);
            l.transform.position = p + new Vector3(0f, 2.4f, -0.8f);
            l.type = LightType.Point;
            l.range = 7f;
            l.intensity = 0f;
            l.color = new Color(1f, 0.88f, 0.65f);
            l.shadows = LightShadows.None;

            var trigger = new GameObject("Home door trigger");
            trigger.transform.SetParent(parent, false);
            trigger.transform.position = p + new Vector3(0f, 1.1f, -0.1f);
            var bc = trigger.AddComponent<BoxCollider>();
            bc.size = new Vector3(1.3f, 2.2f, 0.5f);
            trigger.AddComponent<HomeDoor>();
        }

        // ---------- взаимодействие ----------
        public override float MaxDistance => 3.2f;

        void Awake() { WorldLabels.Add(this); }
        void OnDestroy() { WorldLabels.Remove(this); }

        public Vector3 LabelPos => DoorPos + new Vector3(0f, 3.0f, -0.3f);
        public float LabelMaxDist => 90f;

        public void DrawLabel(Vector2 sp)
        {
            var e = EconomyManager.I;
            if (e == null || e.phase != Phase.Night) return;
            var t = ThemeManager.Current;
            float pulse = 0.75f + 0.25f * Mathf.Sin(Time.time * 4f);
            UIKit.Box(new Rect(sp.x - 70, sp.y - 24, 140, 38), new Color(0f, 0f, 0f, 0.6f));
            UIKit.Label(new Rect(sp.x - 70, sp.y - 24, 140, 38), Loc.Get("hud.home"), 28, new Color(t.accent.r, t.accent.g, t.accent.b, pulse), TextAnchor.MiddleCenter, true, false);
        }

        public override string Prompt(PlayerContext p)
        {
            var e = EconomyManager.I;
            if (e == null) return null;
            switch (e.phase)
            {
                case Phase.Night:
                    if (KioskDoor.IsLocked) return Loc.Get("p.home.sleep");
                    return Loc.Get(Time.time < confirmUntil ? "p.home.sleepSure" : "p.home.sleepOpen");
                case Phase.Closing: return Loc.Get("p.home.wait");
                default: return Loc.Get("p.home.day");
            }
        }

        public override void Interact(PlayerContext p)
        {
            var e = EconomyManager.I;
            if (e == null) return;
            if (e.phase != Phase.Night) { Toast.Push(Loc.Get("t.homeEarly")); return; }
            if (!KioskDoor.IsLocked && Time.time >= confirmUntil)
            {
                // игрок забыл запереть киоск: предупреждаем, но не запрещаем
                confirmUntil = Time.time + 6f;
                Toast.Warn(Loc.Get("t.homeUnlocked"));
                AudioManager.Play(Sfx.Alarm, 0.5f);
                return;
            }
            if (DayNight.I != null) DayNight.I.BeginSleep(() => { if (EconomyManager.I != null) EconomyManager.I.Sleep(); });
            else e.Sleep();
        }
    }
}
