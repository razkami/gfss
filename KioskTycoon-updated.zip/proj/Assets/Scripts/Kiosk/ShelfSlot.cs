using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Полка: остатки хранятся в SaveData, упаковки показываются на досках.</summary>
    public class ShelfSlot : Interactable
    {
        public int index;
        const int PerBoard = 16;
        const int MaxVisual = 40;
        static readonly float[] PackBoards = { 0.45f, 1.0f, 1.55f };
        readonly System.Collections.Generic.List<GameObject> visuals = new System.Collections.Generic.List<GameObject>();
        readonly System.Collections.Generic.List<PhysicalProduct> physicals = new System.Collections.Generic.List<PhysicalProduct>();

        public ShelfEntry Entry { get { var e = GameSession.Data.shelves[index]; e.EnsureGoods(); return e; } }
        public ProductData Product => Entry.goods.Count > 0 ? GameDatabase.Find(Entry.goods[0].id) : null;
        public int Count => Entry.TotalCount;
        public bool HasPhysicalStock => physicals.Count > 0;
        public int Capacity => UpgradeCatalog.ShelfCapacity(GameSession.Data.Up(UpgradeType.Shelves));

        public void Init(int i)
        {
            index = i;
            var bc = gameObject.AddComponent<BoxCollider>();
            bc.center = new Vector3(0f, 1.05f, 0.225f);
            bc.size = new Vector3(0.7f, 2.1f, 0.45f);
            bc.isTrigger = true;
            Refresh();
        }

        public void Refresh()
        {
            foreach (var g in visuals) if (g != null) Destroy(g);
            visuals.Clear();
            physicals.Clear();
            int visualIndex = 0;
            foreach (var stack in Entry.goods)
            {
                var product = GameDatabase.Find(stack.id);
                if (product == null) continue;
                var size = product.packSize;
                int n = Mathf.Min(stack.count, MaxVisual - visualIndex);
                for (int i = 0; i < n; i++, visualIndex++)
                {
                    int board = visualIndex / PerBoard;
                    if (board >= PackBoards.Length) break;
                    int k = visualIndex % PerBoard;
                    int col = k % 8, row = k / 8;
                    float x = -0.3f + col * 0.085f;
                    float z = 0.13f + row * 0.2f;
                    float y = PackBoards[board] + 0.02f + size.y / 2f;
                    var pack = PhysicalProduct.Create(product, Vector3.zero, size, false);
                    pack.transform.SetParent(transform, false);
                    pack.transform.localPosition = new Vector3(x, y, z);
                    pack.sourceShelf = this;
                    var stripeGo = Prim.Cube(transform, "Stripe",
                        new Vector3(x, y + size.y * 0.1f, z + size.z / 2f + 0.002f),
                        new Vector3(size.x * 0.9f, size.y * 0.14f, 0.003f), Mats.Solid(product.accentColor, 0.4f), false);
                    visuals.Add(pack.gameObject);
                    physicals.Add(pack);
                    visuals.Add(stripeGo);
                }
            }
        }

        public void RemovePhysicalItem(PhysicalProduct item)
        {
            if (item == null || !physicals.Remove(item)) return;
            visuals.Remove(item.gameObject);
            var stack = Entry.GetOrAdd(item.product.id);
            stack.count = Mathf.Max(0, stack.count - 1);
            if (stack.count == 0) Entry.goods.Remove(stack);
            Entry.SyncLegacy();
            item.sourceShelf = null;
            Refresh();
        }

        public bool PlacePhysicalItem(PhysicalProduct item)
        {
            if (item == null || Count >= Capacity) return false;
            StockManager.I?.RemoveLoose(item);
            Entry.GetOrAdd(item.product.id).count++;
            Entry.SyncLegacy();
            AudioManager.Play(Sfx.Place);
            Destroy(item.gameObject);
            Refresh();
            return true;
        }

        public bool CanAccept(ProductData product) => product != null && Count < Capacity;

        public PhysicalProduct TakeRandomPhysicalProduct()
        {
            if (physicals.Count == 0) return null;
            var item = physicals[Random.Range(0, physicals.Count)];
            item.Grab();
            return item;
        }

        /// <summary>Убирает с полки одну случайную единицу товара (кража без игрока рядом) и возвращает её тип.</summary>
        public ProductData TakeAnyUnit()
        {
            var goods = Entry.goods;
            if (goods.Count == 0) return null;
            var stack = goods[Random.Range(0, goods.Count)];
            var product = GameDatabase.Find(stack.id);
            stack.count = Mathf.Max(0, stack.count - 1);
            if (stack.count == 0) goods.Remove(stack);
            Entry.SyncLegacy();
            Refresh();
            return product;
        }

        public override bool AllowHold => true;

        public override string Prompt(PlayerContext p)
        {
            if (p.heldBox != null)
            {
                if (Count >= Capacity) return Loc.Get("p.shelf.full");
                return Loc.F("p.shelf.put", p.heldBox.product.displayName, Count, Capacity);
            }
            if (Count <= 0) return Loc.Get("p.shelf.empty");
            return Loc.F("p.shelf.mixed", Count, Capacity);
        }

        public override void Interact(PlayerContext p)
        {
            if (p.heldBox != null)
            {
                var box = p.heldBox;
                int room = Capacity - Count;
                if (room <= 0) { Toast.Warn(Loc.Get("p.shelf.full")); return; }
                int mv = Mathf.Min(room, box.qty);
                Entry.GetOrAdd(box.product.id).count += mv;
                Entry.SyncLegacy();
                box.qty -= mv;
                if (box.qty <= 0)
                {
                    p.heldBox = null;
                    StockManager.I.RemoveBox(box);
                }
                AudioManager.Play(Sfx.Place);
                Refresh();
                return;
            }
            // The products themselves are physical pickup targets inside this shelf.
        }
    }
}
