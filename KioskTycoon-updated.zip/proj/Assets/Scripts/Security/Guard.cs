using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Охранник. Уровень 1 — приходит по вызову и уходит после погони (временный).
    /// Уровень 2 — постоянно стоит у окна и сам бросается за вором.
    /// </summary>
    public class Guard : MonoBehaviour
    {
        enum Mode { Post, Chase, Return }
        const float RunSpeed = 4.6f, WalkSpeed = 1.6f, CatchDistance = 0.95f;

        Mode mode = Mode.Post;
        IFleeing target;
        Vector3 home;
        CustomerRig rig;
        float chaseTime;

        public bool IsTemporary { get; private set; }
        public bool Busy => mode == Mode.Chase;

        public static Guard Create(Transform parent, Vector3 pos, bool temporary)
        {
            var go = new GameObject(temporary ? "Guard (on call)" : "Guard (post)");
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            go.transform.rotation = Quaternion.Euler(0f, 180f, 0f);
            var g = go.AddComponent<Guard>();
            g.IsTemporary = temporary;
            g.home = pos;
            g.rig = CustomerFactory.BuildGuard(go.transform);
            var col = go.AddComponent<CapsuleCollider>();
            col.center = new Vector3(0f, 0.95f, 0f);
            col.radius = 0.3f;
            col.height = 1.9f;
            col.isTrigger = true;           // охранник не мешает ни игроку, ни покупателям
            return g;
        }

        public void Chase(IFleeing t)
        {
            target = t;
            mode = Mode.Chase;
            chaseTime = 0f;
            AudioManager.Play(Sfx.Whistle);
        }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f) return;
            Vector3 before = transform.position;
            var pose = CustomerPose.Idle;

            switch (mode)
            {
                case Mode.Chase:
                    chaseTime += dt;
                    if (target == null || (target as Object) == null || !target.IsFleeing || chaseTime > 14f) { mode = Mode.Return; break; }
                    pose = CustomerPose.Run;
                    MoveToward(target.Position, RunSpeed, dt);
                    if (Flat(transform.position, target.Position) < CatchDistance)
                    {
                        var t = target;
                        target = null;
                        mode = Mode.Return;
                        if (SecurityManager.I != null && SecurityManager.I.RollCatch()) t.Catch(true);
                        else Toast.Warn(Loc.Get("t.guardMissed"));
                    }
                    break;
                case Mode.Return:
                    if (Flat(transform.position, home) > 0.15f)
                    {
                        pose = CustomerPose.Walk;
                        MoveToward(home, WalkSpeed * 1.6f, dt);
                    }
                    else if (IsTemporary)
                    {
                        if (SecurityManager.I != null) SecurityManager.I.GuardFinished(this);
                        Destroy(gameObject);
                        return;
                    }
                    else
                    {
                        mode = Mode.Post;
                        target = null;
                    }
                    break;
                default:
                    transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0f, 180f, 0f), dt * 4f);
                    break;
            }

            float speed = (transform.position - before).magnitude / dt;
            if (rig != null) rig.Tick(dt, pose, speed);
        }

        void MoveToward(Vector3 p, float speed, float dt)
        {
            Vector3 flat = new Vector3(p.x, transform.position.y, p.z);
            Vector3 dir = flat - transform.position;
            if (dir.sqrMagnitude > 0.0004f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir.normalized), dt * 10f);
            transform.position = Vector3.MoveTowards(transform.position, flat, speed * dt);
        }

        static float Flat(Vector3 a, Vector3 b) { a.y = 0f; b.y = 0f; return Vector3.Distance(a, b); }
    }
}
