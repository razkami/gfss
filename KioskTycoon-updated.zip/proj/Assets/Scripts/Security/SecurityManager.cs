using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Тот, кто убегает с украденным: вор из очереди (Customer) или вор, проникший в киоск (Thief).</summary>
    public interface IFleeing
    {
        Vector3 Position { get; }
        bool IsFleeing { get; }
        /// <summary>Задержан охраной (byGuard) или остановлен игроком (битой). Украденное возвращается.</summary>
        void Catch(bool byGuard);
    }

    /// <summary>
    /// Камеры наблюдения, охрана и учёт краж. Все числа берутся из UpgradeCatalog и SaveData,
    /// итоги пишутся в EconomyManager (смена) и SaveData (всего).
    /// </summary>
    public class SecurityManager : MonoBehaviour
    {
        public static SecurityManager I;
        public static readonly Vector3 GuardPost = new Vector3(1.25f, 0f, -0.7f);
        public static readonly Vector3 GuardCallSpawn = new Vector3(4.5f, 0f, -3.2f);

        public readonly List<IFleeing> Fleeing = new List<IFleeing>();
        public string AlertText { get; private set; }
        public float AlertTime { get; private set; }

        Guard guard;
        Transform visuals;
        Camera feedCam;
        RenderTexture feed;
        float feedTimer;

        SaveData D => GameSession.Data;
        public int CamLevel => D != null ? D.Up(UpgradeType.Cameras) : 0;
        public int GuardLevel => D != null ? D.Up(UpgradeType.Guard) : 0;
        public bool GuardOnPost => guard != null && !guard.IsTemporary;

        void Awake() { I = this; }

        void OnDestroy()
        {
            if (I == this) I = null;
            if (feed != null) { feed.Release(); Destroy(feed); }
        }

        // ================= построение (вызывается из KioskBuilder.Build) =================
        public void Rebuild(Transform room)
        {
            if (visuals != null) Destroy(visuals.gameObject);
            feedCam = null;
            visuals = new GameObject("Security").transform;
            visuals.SetParent(room, false);

            int cam = CamLevel;
            if (cam >= 1)
            {
                float w = KioskBuilder.RoomW[D.Up(UpgradeType.Size)];
                float d = KioskBuilder.RoomD[D.Up(UpgradeType.Size)];
                // уличная камера над окном выдачи — её картинка идёт на монитор
                var street = BuildCameraModel(visuals, new Vector3(0.95f, 2.5f, -0.22f), 180f, 16f);
                MakeFeedCamera(street);
                BuildMonitor(visuals, new Vector3(-1.05f, 1.78f, 0.04f));
                if (cam >= 2) BuildCameraModel(visuals, new Vector3(-w / 2f + 0.25f, 2.75f, d - 0.25f), 215f, 28f);
                if (cam >= 3)
                {
                    BuildCameraModel(visuals, new Vector3(w / 2f + 0.12f, 2.6f, 0.45f), 90f, 18f);       // у входной двери
                    BuildDome(visuals, new Vector3(0f, 2.96f, d * 0.55f));                               // купол над залом
                }
            }
            else if (feed != null) { feed.Release(); Destroy(feed); feed = null; }

            EnsureGuard();
        }

        static GameObject BuildCameraModel(Transform parent, Vector3 pos, float yaw, float pitch)
        {
            var pivot = new GameObject("CCTV camera").transform;
            pivot.SetParent(parent, false);
            pivot.localPosition = pos;
            pivot.localRotation = Quaternion.Euler(pitch, yaw, 0f);
            var white = Mats.Solid(new Color(0.92f, 0.93f, 0.95f), 0.5f);
            var dark = Mats.Solid(new Color(0.05f, 0.06f, 0.08f), 0.8f);
            Prim.Cube(pivot, "Bracket", new Vector3(0f, 0.05f, -0.12f), new Vector3(0.05f, 0.1f, 0.05f), Mats.Metal(new Color(0.5f, 0.52f, 0.55f)), false);
            Prim.Cube(pivot, "Body", Vector3.zero, new Vector3(0.1f, 0.1f, 0.26f), white, false);
            Prim.Cube(pivot, "Sunshade", new Vector3(0f, 0.058f, 0.04f), new Vector3(0.12f, 0.012f, 0.3f), white, false);
            var lens = Prim.Cyl(pivot, "Lens", new Vector3(0f, 0f, 0.135f), 0.07f, 0.03f, dark);
            lens.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            Prim.Cube(pivot, "REC LED", new Vector3(0.03f, 0.03f, 0.131f), new Vector3(0.012f, 0.012f, 0.004f),
                Mats.Emissive(new Color(1f, 0.15f, 0.12f), 2.2f), false);
            return pivot.gameObject;
        }

        static void BuildDome(Transform parent, Vector3 pos)
        {
            Prim.Cyl(parent, "Dome base", pos + new Vector3(0f, 0.02f, 0f), 0.2f, 0.03f, Mats.Solid(new Color(0.9f, 0.9f, 0.92f), 0.5f));
            Prim.Sphere(parent, "Dome", pos, 0.17f, Mats.Glass(new Color(0.08f, 0.09f, 0.12f, 0.8f)));
        }

        void MakeFeedCamera(GameObject mount)
        {
            if (feed == null)
            {
                feed = new RenderTexture(320, 180, 16) { name = "CCTV feed", filterMode = FilterMode.Bilinear };
                feed.Create();
            }
            var go = new GameObject("CCTV feed camera");
            go.transform.SetParent(mount.transform, false);
            go.transform.localPosition = new Vector3(0f, 0f, 0.16f);
            go.transform.localRotation = Quaternion.identity;
            feedCam = go.AddComponent<Camera>();
            feedCam.fieldOfView = 78f;
            feedCam.nearClipPlane = 0.12f;
            feedCam.farClipPlane = 60f;
            feedCam.clearFlags = CameraClearFlags.SolidColor;
            feedCam.backgroundColor = DayNight.Sky;
            feedCam.targetTexture = feed;
            feedCam.enabled = false;      // кадры рисуем сами, 4 раза в секунду
            feedTimer = 0f;
        }

        void BuildMonitor(Transform parent, Vector3 pos)
        {
            var holder = new GameObject("CCTV monitor").transform;
            holder.SetParent(parent, false);
            holder.localPosition = pos;
            Prim.Cube(holder, "Frame", Vector3.zero, new Vector3(0.54f, 0.34f, 0.04f), Mats.Solid(new Color(0.07f, 0.07f, 0.09f), 0.5f), false);
            var screenMat = feed != null ? Mats.LiveScreen(feed) : Mats.Emissive(new Color(0.15f, 0.3f, 0.35f), 0.8f);
            // экран чуть выступает вперёд (в зал), чтобы смотреть игроку в лицо
            Prim.Cube(holder, "Screen", new Vector3(0f, 0f, 0.022f), new Vector3(0.48f, 0.28f, 0.006f), screenMat, false);
            Prim.Cube(holder, "REC", new Vector3(0.2f, 0.12f, 0.027f), new Vector3(0.018f, 0.018f, 0.004f),
                Mats.Emissive(new Color(1f, 0.15f, 0.12f), 2f), false);
            Prim.Cube(holder, "Mount", new Vector3(0f, 0f, -0.03f), new Vector3(0.1f, 0.06f, 0.03f), Mats.Metal(new Color(0.4f, 0.42f, 0.45f)), false);
        }

        // ================= охранник =================
        void EnsureGuard()
        {
            int g = GuardLevel;
            if (g >= 2)
            {
                if (guard == null || guard.IsTemporary)
                {
                    if (guard != null) Destroy(guard.gameObject);
                    guard = Guard.Create(transform, GuardPost, false);
                }
            }
            else if (guard != null && !guard.IsTemporary)
            {
                Destroy(guard.gameObject);
                guard = null;
            }
        }

        void DispatchGuard(IFleeing target)
        {
            if (target == null) return;
            if (guard == null) guard = Guard.Create(transform, GuardCallSpawn, true);
            guard.Chase(target);
        }

        public void GuardFinished(Guard g) { if (guard == g) guard = null; }

        // ================= вызов охраны (клавиша) =================
        public bool CallGuard()
        {
            if (GuardLevel <= 0) { Toast.Warn(Loc.Get("t.noguard")); return false; }
            var target = Nearest();
            if (target == null) { Toast.Push(Loc.Get("t.nothreat")); return false; }
            if (guard != null && guard.Busy) { Toast.Push(Loc.Get("t.guardBusy")); return false; }
            if (GuardLevel == 1)
            {
                if (!EconomyManager.I.Spend(UpgradeCatalog.GuardCallFee)) { Toast.Warn(Loc.Get("t.nomoney")); return false; }
                EconomyManager.I.RecordGuardCost(UpgradeCatalog.GuardCallFee);
                Toast.Good(Loc.F("t.guardCalled", UIKit.Money(UpgradeCatalog.GuardCallFee)));
            }
            else Toast.Good(Loc.Get("t.guardGo"));
            DispatchGuard(target);
            return true;
        }

        IFleeing Nearest()
        {
            IFleeing best = null;
            float bd = float.MaxValue;
            var from = PlayerController.I != null ? PlayerController.I.transform.position : Vector3.zero;
            for (int i = Fleeing.Count - 1; i >= 0; i--)
            {
                var f = Fleeing[i];
                if (f == null || (f as Object) == null || !f.IsFleeing) { Fleeing.RemoveAt(i); continue; }
                float d = (f.Position - from).sqrMagnitude;
                if (d < bd) { bd = d; best = f; }
            }
            return best;
        }

        public bool RollCatch() => Random.value < UpgradeCatalog.GuardCatchChance[Mathf.Clamp(GuardLevel, 0, 2)];

        // ================= появление подозрительных =================
        public float SuspectChance()
        {
            float p = Mathf.Min(0.24f, 0.09f + 0.012f * (D.day - 1));
            p *= 1f - UpgradeCatalog.CameraDeterrence[Mathf.Clamp(CamLevel, 0, 3)];
            if (GuardLevel >= 2) p *= 0.6f;
            return p;
        }

        public float NervousChance() => 0.12f;

        /// <summary>Подсветка подозрительного покупателя камерами: 1 — только у окна, 2+ — со всей очереди.</summary>
        public bool IsMarked(Customer c)
        {
            if (c == null || !c.Suspect) return false;
            int cl = CamLevel;
            if (cl <= 0) return false;
            return cl >= 2 || c.IsFront;
        }

        public void OnSuspectSpawned(Customer c)
        {
            if (CamLevel >= 3)
            {
                Toast.Push(Loc.Get("t.suspectCam"));
                AudioManager.Play(Sfx.Notify, 0.8f);
            }
        }

        /// <summary>Охранник на посту может отпугнуть вора до кражи.</summary>
        public bool GuardDeters()
        {
            return GuardOnPost && GuardLevel >= 2 && Random.value < 0.7f;
        }

        // ================= кража и её итоги =================
        public void RegisterFleeing(IFleeing f)
        {
            if (f == null) return;
            if (!Fleeing.Contains(f)) Fleeing.Add(f);
            EconomyManager.I?.RecordTheftAttempt();
            Alert(Loc.F("hud.thiefAlert", Binds.Name(GameAction.CallGuard), Binds.Name(GameAction.UseBat)), 7f);
            AudioManager.Play(Sfx.Alarm);
            if (GuardLevel >= 2) DispatchGuard(f);   // охранник на посту реагирует сам
        }

        public void Unregister(IFleeing f) { Fleeing.Remove(f); }

        public void Alert(string text, float seconds) { AlertText = text; AlertTime = seconds; }

        static float ValueOf(Dictionary<ProductData, int> loot, out int items)
        {
            float v = 0f; items = 0;
            foreach (var kv in loot) { v += StockManager.I.GetPrice(kv.Key) * kv.Value; items += kv.Value; }
            return v;
        }

        /// <summary>Вор скрылся: товары потеряны (запасы), деньги не получены. Камеры частично компенсируют потерю.</summary>
        public void OnEscaped(Dictionary<ProductData, int> loot)
        {
            var e = EconomyManager.I;
            float value = ValueOf(loot, out int items);
            if (items <= 0) return;
            e.RecordTheft(value, items);
            e.AddRep(-2f);
            Toast.Warn(Loc.F("t.stolen", items, UIKit.Money(value)));
            AudioManager.Play(Sfx.Angry, 0.8f);
            float refund = value * UpgradeCatalog.CameraRefund[Mathf.Clamp(CamLevel, 0, 3)];
            if (refund > 0.05f)
            {
                e.RecordRefund(refund);
                Toast.Good(Loc.F("t.refund", UIKit.Money(refund)));
            }
        }

        /// <summary>Вора поймали: товары возвращаются на полки (остальное — на пол у игрока).</summary>
        public void OnRecovered(Dictionary<ProductData, int> loot)
        {
            var e = EconomyManager.I;
            float value = ValueOf(loot, out int items);
            if (items <= 0) return;
            foreach (var kv in loot) StockManager.I.ReturnGoods(kv.Key, kv.Value);
            e.RecordRecovered(value);
            e.AddRep(1.5f);
            Toast.Good(Loc.Get("t.guardCaught"));
            AudioManager.Play(Sfx.Cash, 0.6f);
        }

        public void EndOfDay()
        {
            for (int i = Fleeing.Count - 1; i >= 0; i--)
            {
                var mb = Fleeing[i] as MonoBehaviour;
                if (mb != null) Destroy(mb.gameObject);
            }
            Fleeing.Clear();
            AlertTime = 0f;
            if (guard != null && guard.IsTemporary) { Destroy(guard.gameObject); guard = null; }
        }

        void Update()
        {
            if (AlertTime > 0f) AlertTime -= Time.deltaTime;
            if (feedCam != null && feed != null)
            {
                feedTimer -= Time.unscaledDeltaTime;
                if (feedTimer <= 0f && Time.timeScale > 0f)
                {
                    feedTimer = 0.25f;
                    feedCam.backgroundColor = DayNight.Sky;
                    feedCam.Render();
                }
            }
        }
    }
}
