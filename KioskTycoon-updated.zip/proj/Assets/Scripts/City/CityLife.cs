using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Живой город вокруг киоска: машины по дороге, прохожие (с собаками и без), кошки, собаки и птицы.
    /// Всё процедурное, без внешних ассетов. Создаётся из StreetBuilder.
    /// </summary>
    public class CityLife : MonoBehaviour
    {
        public static CityLife I;

        // ---- геометрия улицы (согласована со StreetBuilder) ----
        public const float CrossX = 5.5f, CrossHalf = 1.35f;                 // зебра
        public const float NearLaneA = -7.0f, NearLaneB = -7.6f;             // дорожки ближнего тротуара
        public const float NearEdge = -7.9f, FarEdge = -21.9f;               // края тротуаров у дороги
        public const float FarLane = -22.8f;                                 // дорожка дальнего тротуара
        public const float CarLanePlus = -11.7f, CarLaneMinus = -18.3f;      // полосы: едут к +x и к -x

        public static readonly List<Vehicle> Vehicles = new List<Vehicle>();
        public static readonly List<Pedestrian> Walkers = new List<Pedestrian>();
        public static readonly List<Quadruped> Dogs = new List<Quadruped>();
        public static readonly List<Vector3> PerchSpots = new List<Vector3>();
        public static bool CrossingBusy { get; private set; }

        static readonly Color[] CarColors =
        {
            new Color(0.82f, 0.2f, 0.2f), new Color(0.2f, 0.45f, 0.82f), new Color(0.93f, 0.78f, 0.2f),
            new Color(0.92f, 0.92f, 0.9f), new Color(0.15f, 0.16f, 0.2f), new Color(0.3f, 0.62f, 0.4f),
            new Color(0.55f, 0.58f, 0.62f), new Color(0.85f, 0.5f, 0.2f)
        };

        Transform root;
        float carTimer = 1f, walkTimer = 1f, flockTimer = 8f;

        public static void Spawn(Transform parent)
        {
            var go = new GameObject("City life");
            go.transform.SetParent(parent, false);
            go.AddComponent<CityLife>();
        }

        void Awake()
        {
            I = this;
            ClearStatics();
        }

        void OnDestroy()
        {
            if (I == this) I = null;
            ClearStatics();
        }

        static void ClearStatics()
        {
            Vehicles.Clear(); Walkers.Clear(); Dogs.Clear(); PerchSpots.Clear();
            CrossingBusy = false;
        }

        void Start()
        {
            root = new GameObject("City actors").transform;
            root.SetParent(transform, false);
            BuildPerchSpots();
            SpawnInitial();
        }

        // ---------------- начальное население ----------------
        void SpawnInitial()
        {
            for (int i = 0; i < 3; i++) SpawnCar(Random.Range(-18f, 18f));
            for (int i = 0; i < 5; i++) SpawnPedestrian(true);

            for (int i = 0; i < 7; i++) Bird.Create(root, false, RandomGroundSpot(), false);
            for (int i = 0; i < 4; i++) Bird.Create(root, true, PerchSpots[Random.Range(0, PerchSpots.Count)], true);

            // кошки: одна дремлет на скамейке, другая — на газетном автомате, третья гуляет
            Quadruped.Create(root, Quadruped.Kind.Cat, new Vector3(3.5f, 0.48f, -1.6f), true);
            Quadruped.Create(root, Quadruped.Kind.Cat, new Vector3(-3.0f, 1.0f, -0.9f), true);
            Quadruped.Create(root, Quadruped.Kind.Cat, new Vector3(-6.5f, 0f, -4.5f), false);
            // бездомная собака
            Quadruped.Create(root, Quadruped.Kind.Dog, new Vector3(7.5f, 0f, -3.8f), false);
        }

        void BuildPerchSpots()
        {
            PerchSpots.Clear();
            PerchSpots.Add(new Vector3(-3.4f, 3.83f, -2.98f));   // головы фонарей
            PerchSpots.Add(new Vector3(3.4f, 3.83f, -2.98f));
            PerchSpots.Add(new Vector3(3.8f, 0.99f, -1.78f));    // спинка скамейки
            PerchSpots.Add(new Vector3(-2.3f, 0.9f, -1.0f));     // урна
            PerchSpots.Add(new Vector3(-4.6f, 3.1f, -2.2f));     // кроны деревьев
            PerchSpots.Add(new Vector3(5.2f, 3.5f, -4.4f));
            PerchSpots.Add(new Vector3(-8.2f, 6.35f, -1.4f));    // крыши соседних домов
            PerchSpots.Add(new Vector3(8.4f, 5.35f, -1.4f));
        }

        public static Vector3 RandomGroundSpot()
        {
            return new Vector3(Random.Range(-7f, 7f), 0.01f, Random.Range(-7.2f, -2.3f));
        }

        // ---------------- общие проверки ----------------
        static float Flat(Vector3 a, Vector3 b) { a.y = 0f; b.y = 0f; return Vector3.Distance(a, b); }

        /// <summary>Кто-то (прохожий, покупатель, игрок) ближе, чем r, — птицы вспархивают.</summary>
        public static bool Disturbed(Vector3 p, float r)
        {
            for (int i = 0; i < Walkers.Count; i++)
                if (Walkers[i] != null && Flat(Walkers[i].transform.position, p) < r) return true;
            var sp = CustomerSpawner.I;
            if (sp != null)
                foreach (var c in sp.Queue)
                    if (c != null && Flat(c.transform.position, p) < r) return true;
            var pl = PlayerController.I;
            return pl != null && Flat(pl.transform.position, p) < r + 0.3f;
        }

        /// <summary>Угроза для кошки: человек, игрок или собака рядом.</summary>
        public static bool CatThreat(Vector3 p, float r)
        {
            if (Disturbed(p, r)) return true;
            for (int i = 0; i < Dogs.Count; i++)
                if (Dogs[i] != null && Flat(Dogs[i].transform.position, p) < r + 0.8f) return true;
            return false;
        }

        /// <summary>Можно ли начать переход у зебры: нет машин, которые подъезжают или ещё на зебре.</summary>
        public static bool SafeToCross()
        {
            for (int i = 0; i < Vehicles.Count; i++)
            {
                var v = Vehicles[i];
                if (v == null) continue;
                float dx = (v.transform.position.x - CrossX) * v.dir;       // <0 — ещё не доехала до зебры
                if (dx < 0f && -dx < 10f + v.halfLen) return false;
                if (dx >= 0f && dx < CrossHalf + v.halfLen + 0.5f) return false;
            }
            return true;
        }

        // ---------------- спавн ----------------
        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f || root == null) return;

            bool busy = false;
            for (int i = 0; i < Walkers.Count; i++)
                if (Walkers[i] != null && Walkers[i].OnCrossing) { busy = true; break; }
            CrossingBusy = busy;

            // ночью улица пустеет: реже машины и прохожие, птицы не летают стаями
            float act = Mathf.Lerp(1f, 0.25f, DayNight.Night);
            carTimer -= dt * act;
            if (carTimer <= 0f) { SpawnCar(float.NaN); carTimer = Random.Range(2.5f, 6f); }
            walkTimer -= dt * act;
            if (walkTimer <= 0f) { SpawnPedestrian(false); walkTimer = Random.Range(2.5f, 6f); }
            flockTimer -= dt;
            if (flockTimer <= 0f) { if (DayNight.Night < 0.5f) SpawnFlock(); flockTimer = Random.Range(10f, 22f); }
        }

        void SpawnCar(float atX)
        {
            if (Vehicles.Count >= Mathf.RoundToInt(Mathf.Lerp(8f, 3f, DayNight.Night))) return;
            int dir = Random.value < 0.5f ? 1 : -1;
            float x = float.IsNaN(atX) ? -dir * 28f : atX;
            foreach (var v in Vehicles)
                if (v != null && v.dir == dir && Mathf.Abs(v.transform.position.x - x) < 12f) return;
            float r = Random.value;
            var kind = r < 0.45f ? Vehicle.Kind.Sedan : r < 0.75f ? Vehicle.Kind.Hatch : r < 0.92f ? Vehicle.Kind.Van : Vehicle.Kind.Bus;
            Color c = kind == Vehicle.Kind.Bus
                ? (Random.value < 0.5f ? new Color(0.85f, 0.25f, 0.2f) : new Color(0.2f, 0.45f, 0.8f))
                : CarColors[Random.Range(0, CarColors.Length)];
            float z = dir > 0 ? CarLanePlus : CarLaneMinus;
            Vehicle.Create(root, kind, c, new Vector3(x, 0f, z), dir);
        }

        void SpawnPedestrian(bool initial)
        {
            if (Walkers.Count >= Mathf.RoundToInt(Mathf.Lerp(9f, 3f, DayNight.Night))) return;
            int dir = Random.value < 0.5f ? -1 : 1;                          // направление движения вдоль x
            float startX = initial ? Random.Range(-12f, 12f) : -dir * 14f;
            float exitX = dir * 15f;
            var path = new List<Vector3>();
            int waitIdx = -1;
            float speed = Random.Range(1.0f, 1.5f);
            bool dog = false;
            Vector3 start;

            float r = Random.value;
            if (r < 0.60f)            // ближний тротуар
            {
                float z = (Random.value < 0.5f ? NearLaneA : NearLaneB) + Random.Range(-0.2f, 0.2f);
                start = new Vector3(startX, 0f, z);
                path.Add(new Vector3(exitX, 0f, z));
                dog = Random.value < 0.28f;
            }
            else if (r < 0.80f)       // дальний тротуар
            {
                float z = FarLane + Random.Range(-0.25f, 0.25f);
                start = new Vector3(startX, 0f, z);
                path.Add(new Vector3(exitX, 0f, z));
                dog = Random.value < 0.2f;
            }
            else                      // переход по зебре (с одного тротуара на другой)
            {
                bool nearToFar = Random.value < 0.5f;
                float cx = CrossX + Random.Range(-0.8f, 0.8f);
                speed = Random.Range(1.3f, 1.6f);
                float zStart = nearToFar ? NearLaneB : FarLane;
                float zEnd = nearToFar ? FarLane : NearLaneB;
                start = new Vector3(startX, 0f, zStart);
                path.Add(new Vector3(cx, 0f, zStart));
                path.Add(new Vector3(cx, 0f, nearToFar ? NearEdge : FarEdge));
                path.Add(new Vector3(cx, 0f, nearToFar ? FarEdge : NearEdge));    // индекс 2: нужна проверка перед стартом
                path.Add(new Vector3(cx, 0f, zEnd));
                path.Add(new Vector3(exitX, 0f, zEnd));
                waitIdx = 2;
            }
            Pedestrian.Create(root, start, path, waitIdx, speed, dog);
        }

        void SpawnFlock()
        {
            int dir = Random.value < 0.5f ? 1 : -1;
            int n = Random.Range(3, 6);
            float y = Random.Range(5.5f, 9f), z = Random.Range(-16f, -5f);
            float speed = Random.Range(5.5f, 8f);
            for (int i = 0; i < n; i++)
            {
                var p = new Vector3(-dir * 24f - dir * i * Random.Range(0.8f, 1.8f), y + Random.Range(-0.8f, 0.8f), z + Random.Range(-1.2f, 1.2f));
                Bird.CreatePassing(root, p, new Vector3(dir * speed, 0f, 0f));
            }
        }
    }
}
