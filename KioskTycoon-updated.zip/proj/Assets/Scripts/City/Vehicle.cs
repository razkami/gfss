using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Машина на дороге: держит дистанцию, тормозит перед зеброй, если по ней идут люди.</summary>
    public class Vehicle : MonoBehaviour
    {
        public enum Kind { Sedan, Hatch, Van, Bus }

        public int dir = 1;               // +1 — едет к +x, -1 — к -x
        public float halfLen = 2.1f;
        float speed, maxSpeed;
        readonly List<Transform> wheels = new List<Transform>();
        const float WheelRadius = 0.32f;

        public static Vehicle Create(Transform parent, Kind kind, Color color, Vector3 pos, int dir)
        {
            var go = new GameObject(kind + " car");
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            go.transform.rotation = Quaternion.Euler(0f, dir > 0 ? 0f : 180f, 0f);   // модель смотрит вдоль +x
            var v = go.AddComponent<Vehicle>();
            v.dir = dir;
            BuildBody(go.transform, kind, color, v.wheels, out v.halfLen);
            v.maxSpeed = kind == Kind.Bus ? Random.Range(4.2f, 5.5f) : Random.Range(5f, 8f);
            v.speed = v.maxSpeed * 0.9f;
            CityLife.Vehicles.Add(v);
            return v;
        }

        void OnDestroy() { CityLife.Vehicles.Remove(this); }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f) return;
            float target = maxSpeed;
            float x = transform.position.x;

            // держим дистанцию до машины впереди
            float gap = float.MaxValue;
            Vehicle lead = null;
            foreach (var v in CityLife.Vehicles)
            {
                if (v == null || v == this || v.dir != dir) continue;
                float d = (v.transform.position.x - x) * dir;
                if (d > 0f && d < gap) { gap = d; lead = v; }
            }
            if (lead != null)
            {
                float free = gap - halfLen - lead.halfLen - 1.5f;
                target = Mathf.Min(target, Mathf.Sqrt(Mathf.Max(0f, 8f * free)));
            }

            // уступаем пешеходам на зебре
            if (CityLife.CrossingBusy)
            {
                float front = x + dir * halfLen;
                float edge = CityLife.CrossX - dir * CityLife.CrossHalf;
                float dist = (edge - front) * dir;
                if (dist > -0.3f && dist < 30f) target = Mathf.Min(target, Mathf.Sqrt(Mathf.Max(0f, 8f * (dist - 0.8f))));
            }

            speed = Mathf.MoveTowards(speed, target, (target > speed ? 3f : 7f) * dt);
            transform.position += Vector3.right * (dir * speed * dt);
            float spin = -speed * dt / WheelRadius * Mathf.Rad2Deg;
            for (int i = 0; i < wheels.Count; i++) if (wheels[i] != null) wheels[i].Rotate(0f, spin, 0f, Space.Self);
            if (Mathf.Abs(transform.position.x) > 30f) Destroy(gameObject);
        }

        /// <summary>Модель машины вдоль оси +x (перед — +x). wheels может быть null (припаркованные).</summary>
        public static void BuildBody(Transform parent, Kind kind, Color body, List<Transform> wheels, out float halfLen)
        {
            var paint = Mats.Solid(body, 0.7f, 0.3f);
            var glass = Mats.Glass(new Color(0.15f, 0.2f, 0.25f, 0.85f));
            var tire = Mats.Solid(new Color(0.06f, 0.06f, 0.07f), 0.2f);
            var head = Mats.Emissive(new Color(1f, 0.95f, 0.8f), 1.5f);
            var tail = Mats.Emissive(new Color(0.9f, 0.1f, 0.08f), 1.2f);
            float len, wheelX, width = 1.8f, lightY = 0.6f;

            switch (kind)
            {
                case Kind.Hatch:
                    len = 3.7f; wheelX = 1.15f;
                    Prim.Cube(parent, "Body", new Vector3(0f, 0.55f, 0f), new Vector3(len, 0.7f, width), paint, false);
                    Prim.Cube(parent, "Cabin", new Vector3(-0.3f, 1.1f, 0f), new Vector3(2.4f, 0.6f, 1.6f), glass, false);
                    break;
                case Kind.Van:
                    len = 4.8f; wheelX = 1.5f; width = 2.0f; lightY = 0.75f;
                    Prim.Cube(parent, "Body", new Vector3(0f, 1.0f, 0f), new Vector3(len, 1.5f, width), paint, false);
                    Prim.Cube(parent, "Windshield", new Vector3(len / 2f - 0.02f, 1.3f, 0f), new Vector3(0.06f, 0.55f, width * 0.85f), glass, false);
                    Prim.Cube(parent, "Side window", new Vector3(1.4f, 1.35f, 0f), new Vector3(1.0f, 0.45f, width + 0.02f), glass, false);
                    Prim.Cube(parent, "Stripe", new Vector3(0f, 0.7f, 0f), new Vector3(len + 0.02f, 0.14f, width + 0.02f), Mats.Solid(new Color(0.95f, 0.95f, 0.95f), 0.4f), false);
                    break;
                case Kind.Bus:
                    len = 9.5f; wheelX = 3.2f; width = 2.5f; lightY = 0.8f;
                    Prim.Cube(parent, "Body", new Vector3(0f, 1.6f, 0f), new Vector3(len, 2.4f, width), paint, false);
                    Prim.Cube(parent, "Windows", new Vector3(-0.2f, 2.0f, 0f), new Vector3(len - 1.2f, 0.8f, width + 0.02f), glass, false);
                    Prim.Cube(parent, "Windshield", new Vector3(len / 2f - 0.02f, 1.95f, 0f), new Vector3(0.06f, 1.0f, width * 0.88f), glass, false);
                    Prim.Cube(parent, "Roof", new Vector3(0f, 2.85f, 0f), new Vector3(len - 0.4f, 0.12f, width - 0.2f), Mats.Solid(new Color(0.85f, 0.86f, 0.88f), 0.4f), false);
                    Prim.Cube(parent, "Door", new Vector3(2.9f, 1.3f, width / 2f + 0.01f), new Vector3(0.9f, 1.7f, 0.04f), Mats.Solid(new Color(0.1f, 0.12f, 0.15f), 0.4f), false);
                    break;
                default:
                    len = 4.2f; wheelX = 1.3f;
                    Prim.Cube(parent, "Body", new Vector3(0f, 0.55f, 0f), new Vector3(len, 0.7f, width), paint, false);
                    Prim.Cube(parent, "Cabin", new Vector3(-0.2f, 1.1f, 0f), new Vector3(2.3f, 0.55f, 1.6f), glass, false);
                    break;
            }
            halfLen = len / 2f;

            foreach (float wx in new[] { -wheelX, wheelX })
                foreach (float wz in new[] { -width / 2f + 0.1f, width / 2f - 0.1f })
                {
                    var wheel = Prim.Cyl(parent, "Wheel", new Vector3(wx, WheelRadius, wz), WheelRadius * 2f, 0.22f, tire);
                    wheel.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                    if (wheels != null) wheels.Add(wheel.transform);
                }
            foreach (float lz in new[] { -width * 0.3f, width * 0.3f })
            {
                Prim.Cube(parent, "Headlight", new Vector3(halfLen + 0.01f, lightY, lz), new Vector3(0.05f, 0.14f, 0.3f), head, false);
                Prim.Cube(parent, "Tail light", new Vector3(-halfLen - 0.01f, lightY, lz), new Vector3(0.05f, 0.12f, 0.26f), tail, false);
            }
        }
    }
}
