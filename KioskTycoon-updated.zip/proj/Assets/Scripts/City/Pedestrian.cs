using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Прохожий: идёт по тротуару, иногда останавливается, переходит дорогу по зебре, может вести собаку.</summary>
    public class Pedestrian : MonoBehaviour
    {
        CustomerRig rig;
        List<Vector3> path;
        int idx, waitIdx = -1;
        bool started;
        float speed, walked, stopAt = -1f, stopFor;
        Quadruped dog;

        /// <summary>Сейчас идёт по проезжей части (машины должны остановиться).</summary>
        public bool OnCrossing => waitIdx >= 0 && started && idx == waitIdx;

        public static Pedestrian Create(Transform parent, Vector3 pos, List<Vector3> path, int waitIdx, float speed, bool withDog)
        {
            var go = new GameObject("Pedestrian");
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            var p = go.AddComponent<Pedestrian>();
            p.path = path;
            p.waitIdx = waitIdx;
            p.speed = speed;
            if (waitIdx < 0 && Random.value < 0.35f) p.stopAt = Random.Range(2f, 9f);   // остановится посмотреть по сторонам

            CustomerProfile prof = GameDatabase.Profiles.Count > 0 ? GameDatabase.Profiles[Random.Range(0, GameDatabase.Profiles.Count)] : null;
            bool young = Random.value < 0.1f;
            var look = CustomerFactory.Roll(prof, young, false);
            p.rig = CustomerFactory.Build(go.transform, look, young);

            Vector3 first = path[0] - pos;
            first.y = 0f;
            if (first.sqrMagnitude > 0.01f) go.transform.rotation = Quaternion.LookRotation(first);

            if (withDog)
            {
                p.dog = Quadruped.Create(parent, Quadruped.Kind.Dog, pos + go.transform.right * 0.8f, false);
                p.dog.Leash(go.transform, p.rig.hand);
            }
            CityLife.Walkers.Add(p);
            return p;
        }

        void OnDestroy()
        {
            CityLife.Walkers.Remove(this);
            if (dog != null) Destroy(dog.gameObject);
        }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f || path == null) return;
            if (idx >= path.Count) { Destroy(gameObject); return; }

            Vector3 before = transform.position;
            var pose = CustomerPose.Idle;

            if (stopFor > 0f)
            {
                stopFor -= dt;
            }
            else
            {
                if (idx == waitIdx && !started && CityLife.SafeToCross()) started = true;
                if (idx == waitIdx && !started)
                {
                    Face(path[idx] - transform.position, dt);             // ждём у края дороги, глядя на неё
                }
                else
                {
                    Vector3 target = path[idx];
                    Face(target - transform.position, dt);
                    transform.position = Vector3.MoveTowards(transform.position, target, speed * dt);
                    pose = CustomerPose.Walk;
                    if (Vector3.Distance(transform.position, target) < 0.05f) idx++;
                    walked += speed * dt;
                    if (stopAt > 0f && walked > stopAt) { stopAt = -1f; stopFor = Random.Range(2.5f, 6f); }
                }
            }

            float actual = (transform.position - before).magnitude / dt;
            if (rig != null) rig.Tick(dt, pose, actual);
        }

        void Face(Vector3 dir, float dt)
        {
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.0004f) return;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir.normalized), dt * 8f);
        }
    }
}
