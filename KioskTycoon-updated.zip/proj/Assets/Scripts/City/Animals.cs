using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Кошка или собака из примитивов: ходит, нюхает, дремлет; собака может идти на поводке рядом с хозяином.</summary>
    public class Quadruped : MonoBehaviour
    {
        public enum Kind { Cat, Dog }
        enum Mode { Rest, Wander, Follow, Flee }

        const float MinX = -15f, MaxX = 15f, MinZ = -7.4f, MaxZ = -2.6f;

        Kind kind;
        Mode mode = Mode.Rest;
        bool fixedSpot, sniff;
        float k = 1f, legLen, bodyRestY, baseY, seed, timer, curSpeed, phase, loaf;
        Vector3 dest;
        Transform body, head, tail;
        readonly Transform[] legs = new Transform[4];

        Transform leader, leashHand;
        LineRenderer leash;

        public static Quadruped Create(Transform parent, Kind kind, Vector3 pos, bool fixedSpot)
        {
            var go = new GameObject(kind == Kind.Cat ? "Cat" : "Dog");
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            go.transform.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
            var q = go.AddComponent<Quadruped>();
            q.kind = kind;
            q.fixedSpot = fixedSpot;
            q.baseY = pos.y;
            q.seed = Random.value * 20f;
            q.timer = Random.Range(1f, 6f);
            q.Build();
            if (kind == Kind.Dog) CityLife.Dogs.Add(q);
            return q;
        }

        void OnDestroy() { CityLife.Dogs.Remove(this); }

        /// <summary>Собака идёт рядом с хозяином (leader), поводок тянется к его руке.</summary>
        public void Leash(Transform leaderTf, Transform hand)
        {
            leader = leaderTf;
            leashHand = hand;
            mode = Mode.Follow;
            var shader = Shader.Find("Sprites/Default");
            leash = gameObject.AddComponent<LineRenderer>();
            leash.positionCount = 2;
            leash.startWidth = leash.endWidth = 0.014f;
            leash.sharedMaterial = shader != null ? new Material(shader) { color = new Color(0.75f, 0.12f, 0.12f) } : Mats.Solid(new Color(0.75f, 0.12f, 0.12f));
            leash.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        }

        // ---------------- модель ----------------
        void Build()
        {
            bool dog = kind == Kind.Dog;
            k = dog ? 1.55f : 1f;
            Color[] cats = { new Color(0.85f, 0.5f, 0.2f), new Color(0.5f, 0.5f, 0.54f), new Color(0.1f, 0.1f, 0.12f), new Color(0.92f, 0.9f, 0.86f), new Color(0.45f, 0.32f, 0.2f) };
            Color[] dogs = { new Color(0.78f, 0.58f, 0.34f), new Color(0.4f, 0.26f, 0.16f), new Color(0.12f, 0.12f, 0.13f), new Color(0.9f, 0.76f, 0.45f), new Color(0.88f, 0.86f, 0.82f) };
            Color fur = dog ? dogs[Random.Range(0, dogs.Length)] : cats[Random.Range(0, cats.Length)];
            var furM = Mats.Solid(fur, 0.25f);
            var darkM = Mats.Solid(new Color(0.06f, 0.06f, 0.07f), 0.5f);
            var pinkM = Mats.Solid(new Color(0.9f, 0.55f, 0.6f), 0.4f);

            legLen = 0.17f * k;
            bodyRestY = legLen + 0.075f * k;
            body = new GameObject("Body").transform;
            body.SetParent(transform, false);
            body.localPosition = new Vector3(0f, bodyRestY, 0f);
            Prim.Shape(PrimitiveType.Sphere, body, "Torso", Vector3.zero, new Vector3(0.15f, 0.16f, 0.38f) * k, furM);

            head = new GameObject("Head").transform;
            head.SetParent(body, false);
            head.localPosition = new Vector3(0f, 0.07f * k, 0.2f * k);
            Prim.Shape(PrimitiveType.Sphere, head, "Skull", Vector3.zero, Vector3.one * 0.14f * k, furM);
            Prim.Shape(PrimitiveType.Sphere, head, "Eye L", new Vector3(-0.035f, 0.02f, 0.06f) * k, Vector3.one * 0.022f * k, darkM);
            Prim.Shape(PrimitiveType.Sphere, head, "Eye R", new Vector3(0.035f, 0.02f, 0.06f) * k, Vector3.one * 0.022f * k, darkM);
            if (dog)
            {
                Prim.Cube(head, "Snout", new Vector3(0f, -0.025f, 0.085f) * k, new Vector3(0.07f, 0.06f, 0.1f) * k, furM, false);
                Prim.Cube(head, "Nose", new Vector3(0f, -0.01f, 0.137f) * k, new Vector3(0.03f, 0.025f, 0.02f) * k, darkM, false);
                foreach (float sx in new[] { -1f, 1f })
                {
                    var ear = Prim.Cube(head, "Ear", new Vector3(sx * 0.07f, 0.0f, -0.01f) * k, new Vector3(0.03f, 0.09f, 0.06f) * k, Mats.Solid(fur * 0.7f, 0.2f), false);
                    ear.transform.localRotation = Quaternion.Euler(0f, 0f, -sx * 12f);
                }
            }
            else
            {
                Prim.Cube(head, "Nose", new Vector3(0f, -0.015f, 0.068f), new Vector3(0.02f, 0.015f, 0.012f), pinkM, false);
                foreach (float sx in new[] { -1f, 1f })
                {
                    var ear = Prim.Cube(head, "Ear", new Vector3(sx * 0.04f, 0.07f, 0f), new Vector3(0.04f, 0.06f, 0.02f), furM, false);
                    ear.transform.localRotation = Quaternion.Euler(0f, 0f, -sx * 15f);
                }
            }

            // хвост
            tail = new GameObject("Tail").transform;
            tail.SetParent(body, false);
            tail.localPosition = new Vector3(0f, 0.04f * k, -0.19f * k);
            float tailLen = dog ? 0.22f * k : 0.32f;
            Prim.Cyl(tail, "Tail", new Vector3(0f, tailLen / 2f, 0f), dog ? 0.05f * k : 0.035f, tailLen, furM);

            // ноги: FL, FR, BL, BR
            float[] lx = { -1f, 1f, -1f, 1f };
            float[] lz = { 1f, 1f, -1f, -1f };
            for (int i = 0; i < 4; i++)
            {
                var pivot = new GameObject("Leg").transform;
                pivot.SetParent(body, false);
                pivot.localPosition = new Vector3(lx[i] * 0.055f * k, -0.075f * k, lz[i] * 0.13f * k);
                Prim.Cube(pivot, "Limb", new Vector3(0f, -legLen / 2f, 0f), new Vector3(0.05f * k, legLen, 0.05f * k), furM, false);
                Prim.Cube(pivot, "Paw", new Vector3(0f, -legLen + 0.01f * k, 0.008f * k), new Vector3(0.055f * k, 0.025f * k, 0.065f * k),
                    dog ? Mats.Solid(fur * 0.8f, 0.2f) : Mats.Solid(new Color(0.95f, 0.95f, 0.95f), 0.2f), false);
                legs[i] = pivot;
            }
        }

        // ---------------- поведение ----------------
        static float Flat(Vector3 a, Vector3 b) { a.y = 0f; b.y = 0f; return Vector3.Distance(a, b); }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f) return;
            Vector3 before = transform.position;

            switch (mode)
            {
                case Mode.Rest:
                    if (kind == Kind.Cat && !fixedSpot && CityLife.CatThreat(transform.position, 1.4f)) { StartFlee(); break; }
                    timer -= dt;
                    if (!fixedSpot && timer <= 0f) PickWander();
                    break;
                case Mode.Wander:
                    if (kind == Kind.Cat && CityLife.CatThreat(transform.position, 1.4f)) { StartFlee(); break; }
                    if (MoveTo(dest, kind == Kind.Cat ? 0.7f : 1.1f, dt)) { mode = Mode.Rest; timer = Random.Range(4f, 12f); sniff = Random.value < 0.5f; }
                    break;
                case Mode.Flee:
                    if (MoveTo(dest, 3.2f, dt)) { mode = Mode.Rest; timer = Random.Range(3f, 7f); }
                    break;
                case Mode.Follow:
                    Follow(dt);
                    break;
            }

            float actual = (transform.position - before).magnitude / dt;
            curSpeed = Mathf.Lerp(curSpeed, actual, Mathf.Clamp01(dt * 10f));
            Animate(dt);
        }

        void PickWander()
        {
            float r = kind == Kind.Cat ? 3f : 6f;
            Vector3 p = transform.position;
            dest = new Vector3(Mathf.Clamp(p.x + Random.Range(-r, r), MinX, MaxX), baseY, Mathf.Clamp(p.z + Random.Range(-r * 0.5f, r * 0.5f), MinZ, MaxZ));
            mode = Mode.Wander;
        }

        void StartFlee()
        {
            // убегаем в сторону от ближайшей угрозы; если не понять — просто в сторону
            Vector3 p = transform.position;
            Vector3 away = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f));
            for (int i = 0; i < CityLife.Walkers.Count; i++)
            {
                var w = CityLife.Walkers[i];
                if (w != null && Flat(w.transform.position, p) < 2.2f) { away = p - w.transform.position; away.y = 0f; break; }
            }
            if (away.sqrMagnitude < 0.01f) away = Vector3.right;
            away = away.normalized * Random.Range(3f, 4.5f);
            dest = new Vector3(Mathf.Clamp(p.x + away.x, MinX, MaxX), baseY, Mathf.Clamp(p.z + away.z, MinZ, MaxZ));
            mode = Mode.Flee;
        }

        bool MoveTo(Vector3 target, float sp, float dt)
        {
            Vector3 d = target - transform.position;
            d.y = 0f;
            if (d.magnitude < 0.08f) return true;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(d.normalized), dt * 8f);
            Vector3 flat = new Vector3(target.x, transform.position.y, target.z);
            transform.position = Vector3.MoveTowards(transform.position, flat, sp * dt);
            return false;
        }

        void Follow(float dt)
        {
            if (leader == null) { mode = Mode.Wander; PickWander(); return; }
            Vector3 goal = leader.position + leader.right * 0.8f + leader.forward * 0.5f;
            goal.y = transform.position.y;
            float dist = Flat(transform.position, goal);
            if (dist > 0.06f)
            {
                Vector3 d = goal - transform.position;
                d.y = 0f;
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(d.normalized), dt * 8f);
                transform.position = Vector3.MoveTowards(transform.position, goal, Mathf.Clamp(dist * 3f, 0f, 3.5f) * dt);
            }
            else transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(leader.forward), dt * 6f);
        }

        // ---------------- анимация ----------------
        void Animate(float dt)
        {
            float t = Time.time + seed;
            bool moving = curSpeed > 0.12f;
            float walk = Mathf.Clamp01(curSpeed / 0.9f);
            phase += dt * curSpeed * (kind == Kind.Dog ? 6.5f : 8f);
            float swing = Mathf.Sin(phase) * 38f * walk;

            // дремота: лапы прячутся, тело опускается
            float wantLoaf = (mode == Mode.Rest && !moving && (kind == Kind.Cat || !sniff)) ? 1f : 0f;
            loaf = Mathf.MoveTowards(loaf, wantLoaf, dt * 2.5f);
            float bob = Mathf.Abs(Mathf.Sin(phase)) * 0.012f * k * walk;
            body.localPosition = new Vector3(0f, Mathf.Lerp(bodyRestY, 0.085f * k, loaf) + bob, 0f);

            legs[0].localRotation = Quaternion.Euler(swing, 0f, 0f);
            legs[3].localRotation = Quaternion.Euler(swing, 0f, 0f);
            legs[1].localRotation = Quaternion.Euler(-swing, 0f, 0f);
            legs[2].localRotation = Quaternion.Euler(-swing, 0f, 0f);
            Vector3 legScale = new Vector3(1f, Mathf.Lerp(1f, 0.02f, loaf), 1f);
            for (int i = 0; i < 4; i++) legs[i].localScale = legScale;

            float pitch = 0f, yaw = 0f;
            if (mode == Mode.Rest && !moving)
            {
                yaw = Mathf.Sin(t * 0.45f) * 35f;
                pitch = sniff && kind == Kind.Dog ? 32f + Mathf.Sin(t * 5f) * 5f : Mathf.Sin(t * 0.7f) * 6f;
            }
            else pitch = Mathf.Sin(phase * 2f) * 4f;
            head.localRotation = Quaternion.Euler(pitch, yaw, 0f);

            if (kind == Kind.Dog)
            {
                float wag = mode == Mode.Follow || moving ? 12f : 4f;
                tail.localRotation = Quaternion.Euler(-50f, Mathf.Sin(t * wag) * 30f, 0f);
            }
            else tail.localRotation = Quaternion.Euler(-72f + Mathf.Sin(t * 1.4f) * 8f, Mathf.Sin(t * 1.1f) * 22f, 0f);
        }

        void LateUpdate()
        {
            if (leash == null) return;
            if (leader == null || leashHand == null) { leash.enabled = false; return; }
            leash.SetPosition(0, body.position + body.forward * 0.2f * k + Vector3.up * 0.04f * k);
            leash.SetPosition(1, leashHand.position);
        }
    }

    /// <summary>Птица (голубь или воробей): клюёт на тротуаре, сидит на фонарях и крышах, вспархивает от людей; стаи пролетают над улицей.</summary>
    public class Bird : MonoBehaviour
    {
        enum State { Ground, Perch, Fly }

        State state = State.Ground;
        bool passing, targetPerch;
        Vector3 vel, from, to;
        float timer, flyT, flyDur = 1f, arc = 1f, seed, size = 1f;
        Transform head, wingL, wingR;

        public static Bird Create(Transform parent, bool sparrow, Vector3 pos, bool onPerch)
        {
            var b = Make(parent, sparrow, pos);
            b.state = onPerch ? State.Perch : State.Ground;
            b.timer = Random.Range(1f, 8f);
            b.transform.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
            return b;
        }

        public static Bird CreatePassing(Transform parent, Vector3 pos, Vector3 velocity)
        {
            var b = Make(parent, Random.value < 0.3f, pos);
            b.passing = true;
            b.vel = velocity;
            b.transform.rotation = Quaternion.LookRotation(velocity);
            return b;
        }

        static Bird Make(Transform parent, bool sparrow, Vector3 pos)
        {
            var go = new GameObject(sparrow ? "Sparrow" : "Pigeon");
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            var b = go.AddComponent<Bird>();
            b.seed = Random.value * 20f;
            b.size = sparrow ? 0.7f : 1f;
            b.Build(sparrow);
            return b;
        }

        void Build(bool sparrow)
        {
            float s = size;
            Color col = sparrow ? new Color(0.5f, 0.36f, 0.22f) : new Color(0.55f, 0.57f, 0.62f);
            Color belly = sparrow ? new Color(0.78f, 0.7f, 0.58f) : new Color(0.66f, 0.68f, 0.72f);
            var bodyM = Mats.Solid(col, 0.25f);
            var wingM = Mats.Solid(col * 0.75f, 0.25f);
            float y = 0.11f * s;

            Prim.Shape(PrimitiveType.Sphere, transform, "Body", new Vector3(0f, y, 0f), new Vector3(0.11f, 0.1f, 0.2f) * s, bodyM);
            Prim.Shape(PrimitiveType.Sphere, transform, "Breast", new Vector3(0f, y - 0.01f * s, 0.045f * s), new Vector3(0.1f, 0.09f, 0.12f) * s, Mats.Solid(belly, 0.25f));
            head = new GameObject("Head").transform;
            head.SetParent(transform, false);
            head.localPosition = new Vector3(0f, y + 0.06f * s, 0.095f * s);
            Prim.Shape(PrimitiveType.Sphere, head, "Skull", Vector3.zero, Vector3.one * 0.075f * s, sparrow ? Mats.Solid(new Color(0.45f, 0.3f, 0.2f), 0.25f) : Mats.Solid(new Color(0.3f, 0.5f, 0.45f), 0.4f));
            Prim.Cube(head, "Beak", new Vector3(0f, -0.005f * s, 0.045f * s), new Vector3(0.015f, 0.012f, 0.035f) * s, Mats.Solid(new Color(0.9f, 0.7f, 0.3f), 0.3f), false);
            Prim.Shape(PrimitiveType.Sphere, head, "Eye L", new Vector3(-0.03f, 0.01f, 0.025f) * s, Vector3.one * 0.012f * s, Mats.Solid(new Color(0.05f, 0.05f, 0.05f), 0.6f));
            Prim.Shape(PrimitiveType.Sphere, head, "Eye R", new Vector3(0.03f, 0.01f, 0.025f) * s, Vector3.one * 0.012f * s, Mats.Solid(new Color(0.05f, 0.05f, 0.05f), 0.6f));
            var tailCube = Prim.Cube(transform, "Tail", new Vector3(0f, y + 0.005f * s, -0.13f * s), new Vector3(0.07f, 0.012f, 0.1f) * s, wingM, false);
            tailCube.transform.localRotation = Quaternion.Euler(-12f, 0f, 0f);

            wingL = new GameObject("Wing L").transform;
            wingL.SetParent(transform, false);
            wingL.localPosition = new Vector3(-0.05f * s, y + 0.02f * s, 0f);
            Prim.Cube(wingL, "Feathers", new Vector3(-0.05f * s, 0f, -0.01f * s), new Vector3(0.1f, 0.01f, 0.15f) * s, wingM, false);
            wingR = new GameObject("Wing R").transform;
            wingR.SetParent(transform, false);
            wingR.localPosition = new Vector3(0.05f * s, y + 0.02f * s, 0f);
            Prim.Cube(wingR, "Feathers", new Vector3(0.05f * s, 0f, -0.01f * s), new Vector3(0.1f, 0.01f, 0.15f) * s, wingM, false);
            Fold();
        }

        void Fold()
        {
            wingL.localRotation = Quaternion.Euler(0f, 0f, 78f);
            wingR.localRotation = Quaternion.Euler(0f, 0f, -78f);
        }

        void Flap(float t)
        {
            float a = Mathf.Sin(t * 30f) * 50f;
            wingL.localRotation = Quaternion.Euler(0f, 0f, a);
            wingR.localRotation = Quaternion.Euler(0f, 0f, -a);
        }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f) return;
            float t = Time.time + seed;

            if (passing)
            {
                var p = transform.position + vel * dt;
                p.y += Mathf.Sin(t * 2.2f) * 0.6f * dt;
                transform.position = p;
                Flap(t);
                if (Mathf.Abs(p.x) > 45f) Destroy(gameObject);
                return;
            }

            switch (state)
            {
                case State.Ground:
                    // клюёт: короткие серии наклонов головы
                    bool pecking = Mathf.Repeat(t * 0.7f, 1f) < 0.4f;
                    head.localRotation = Quaternion.Euler(pecking ? Mathf.Abs(Mathf.Sin(t * 9f)) * 55f : Mathf.Sin(t * 1.3f) * 8f, Mathf.Sin(t * 0.8f) * 25f, 0f);
                    if (CityLife.Disturbed(transform.position, 1.9f)) { TakeOff(true); break; }
                    timer -= dt;
                    if (timer <= 0f) TakeOff(false);
                    break;
                case State.Perch:
                    head.localRotation = Quaternion.Euler(0f, Mathf.Sin(t * 0.9f) * 50f, 0f);
                    timer -= dt;
                    if (timer <= 0f) TakeOff(false);
                    break;
                case State.Fly:
                    flyT += dt / flyDur;
                    float k = Mathf.Clamp01(flyT);
                    Vector3 pos = Vector3.Lerp(from, to, k);
                    pos.y += arc * Mathf.Sin(k * Mathf.PI);
                    Vector3 dir = pos - transform.position;
                    transform.position = pos;
                    dir.y = 0f;
                    if (dir.sqrMagnitude > 0.00001f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), dt * 12f);
                    Flap(t);
                    if (flyT >= 1f) Land();
                    break;
            }
        }

        void TakeOff(bool scared)
        {
            Vector3 cur = transform.position;
            bool perch = Random.value < (scared ? 0.65f : 0.35f) && CityLife.PerchSpots.Count > 0;
            Vector3 target = perch ? CityLife.PerchSpots[Random.Range(0, CityLife.PerchSpots.Count)] : CityLife.RandomGroundSpot();
            if (!perch && scared)
                for (int i = 0; i < 6 && Vector3.Distance(cur, target) < 3f; i++) target = CityLife.RandomGroundSpot();
            targetPerch = perch;
            from = cur;
            to = target;
            float dist = Vector3.Distance(from, to);
            flyDur = Mathf.Max(0.6f, dist / (scared ? 6.5f : 4.5f));
            arc = Mathf.Clamp(dist * 0.12f, 0.4f, 2.5f);
            flyT = 0f;
            state = State.Fly;
        }

        void Land()
        {
            transform.position = to;
            state = targetPerch ? State.Perch : State.Ground;
            timer = targetPerch ? Random.Range(6f, 16f) : Random.Range(3f, 9f);
            Fold();
        }
    }
}
