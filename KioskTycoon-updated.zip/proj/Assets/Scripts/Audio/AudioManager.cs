using System;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Порядок значений не менять: индексы клипов совпадают с enum. Новые звуки — только в конец.</summary>
    public enum Sfx
    {
        Bell, Step, Beep, Cash, Box, Click, Angry, Pickup, Place, Upgrade, Day, BatSwing, BatHit,
        DoorOpen, DoorClose, Scan, Drawer, BoxOpen, Notify, Alarm, VoiceHi, VoiceHappy, VoiceGrumble, Whistle
    }

    /// <summary>
    /// Процедурные звуки и музыка (без внешних файлов). Независимые громкости: общая, музыка, эффекты;
    /// музыку можно отключить совсем. Эффекты играют через пул источников со случайной высотой тона.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager I;
        const int SR = 22050;
        const int PoolSize = 10;
        AudioSource music, ambient;
        AudioSource[] pool;
        int poolIndex;
        AudioClip[] clips;
        static readonly System.Random rnd = new System.Random(7);

        public static void Play(Sfx s, float vol = 1f) { if (I != null) I.PlayInternal(s, vol); }

        /// <summary>Звук «в мире»: громкость падает с расстоянием до игрока.</summary>
        public static void PlayAt(Sfx s, Vector3 pos, float vol = 1f)
        {
            if (I == null) return;
            var pc = PlayerController.I;
            if (pc == null) { I.PlayInternal(s, vol); return; }
            float d = Vector3.Distance(pc.transform.position, pos);
            float k = Mathf.Clamp01(1.4f / (1f + d * d * 0.12f));
            if (k < 0.04f) return;
            I.PlayInternal(s, vol * k);
        }

        void Awake()
        {
            I = this;
            music = gameObject.AddComponent<AudioSource>(); music.loop = true; music.playOnAwake = false;
            ambient = gameObject.AddComponent<AudioSource>(); ambient.loop = true; ambient.playOnAwake = false;
            pool = new AudioSource[PoolSize];
            for (int i = 0; i < PoolSize; i++)
            {
                pool[i] = gameObject.AddComponent<AudioSource>();
                pool[i].playOnAwake = false;
            }
            BuildClips();
            music.clip = MakeMusic(); ambient.clip = MakeAmbient();
            music.Play(); ambient.Play();
            ApplyVolumes();
        }

        public void ApplyVolumes()
        {
            var d = SettingsManager.Data;
            if (music == null) return;
            music.volume = d.master * d.music * 0.5f;
            music.mute = !d.musicEnabled;
            ambient.volume = d.master * d.sfx * 0.3f;
        }

        void PlayInternal(Sfx s, float vol)
        {
            if (clips == null || pool == null) return;
            var d = SettingsManager.Data;
            var src = pool[poolIndex];
            poolIndex = (poolIndex + 1) % PoolSize;
            src.clip = clips[(int)s];
            src.volume = Mathf.Clamp01(vol) * d.master * d.sfx;
            bool pitched = s == Sfx.Step || s == Sfx.Click || s == Sfx.Pickup || s == Sfx.Place || s == Sfx.Box;
            src.pitch = pitched ? UnityEngine.Random.Range(0.92f, 1.08f) : 1f;
            src.Play();
        }

        // ---------- синтез ----------
        static float Noise() => (float)(rnd.NextDouble() * 2 - 1);
        static float Sin(float f, float t) => Mathf.Sin(2f * Mathf.PI * f * t);

        static AudioClip Make(string n, float dur, Func<float, float> f)
        {
            int len = (int)(dur * SR);
            var data = new float[len];
            for (int i = 0; i < len; i++) data[i] = Mathf.Clamp(f(i / (float)SR), -1f, 1f);
            var c = AudioClip.Create(n, len, 1, SR, false);
            c.SetData(data, 0);
            return c;
        }

        static float Arp(float t, float[] notes, float step, float decay)
        {
            int i = Mathf.Min(notes.Length - 1, (int)(t / step));
            float lt = t - i * step;
            return Sin(notes[i], t) * Mathf.Exp(-lt * decay) * 0.4f;
        }

        /// <summary>Мягкий «голос» без слов: основной тон + две форманты с огибающей.</summary>
        static float Voice(float t, float len, float f0a, float f0b, float fm1, float fm2, float breath)
        {
            float k = t / len;
            float f0 = Mathf.Lerp(f0a, f0b, k);
            float env = Mathf.Sin(Mathf.PI * Mathf.Clamp01(k)) * 0.9f;
            float vib = 1f + 0.02f * Sin(6f, t);
            float src = Sin(f0 * vib, t) + 0.5f * Sin(f0 * 2f, t) + 0.25f * Sin(f0 * 3f, t);
            float form = 0.55f * Sin(fm1, t) * 0.5f + 0.35f * Sin(fm2, t) * 0.4f;
            return (src * 0.18f + form * 0.35f * Mathf.Abs(Sin(f0, t)) + Noise() * breath) * env;
        }

        void BuildClips()
        {
            clips = new AudioClip[Enum.GetValues(typeof(Sfx)).Length];
            clips[(int)Sfx.Bell] = Make("bell", 1.2f, t =>
            {
                float a = (Sin(880, t) + 0.6f * Sin(1320, t) + 0.3f * Sin(1760, t)) * Mathf.Exp(-5f * t);
                float t2 = t - 0.22f;
                float b = t2 > 0 ? (Sin(1175, t2) + 0.5f * Sin(1760, t2)) * Mathf.Exp(-5f * t2) : 0f;
                return (a + b) * 0.3f;
            });
            float lp = 0f;
            clips[(int)Sfx.Step] = Make("step", 0.16f, t => { lp += (Noise() - lp) * 0.12f; return lp * Mathf.Exp(-t * 32f) * 2.2f; });
            clips[(int)Sfx.Beep] = Make("beep", 0.09f, t => Sin(1400, t) * (t < 0.01f ? t / 0.01f : 1f) * Mathf.Exp(-t * 18f) * 0.4f);
            clips[(int)Sfx.Cash] = Make("cash", 0.9f, t =>
            {
                float n = t < 0.12f ? Noise() * Mathf.Exp(-t * 35f) * 0.5f : 0f;
                float t2 = t - 0.12f;
                float tone = t2 > 0 ? (Sin(2093, t2) + 0.5f * Sin(3136, t2)) * Mathf.Exp(-t2 * 6f) * 0.3f : 0f;
                return n + tone;
            });
            clips[(int)Sfx.Box] = Make("box", 0.25f, t => Sin(70, t) * Mathf.Exp(-t * 16f) * 0.8f + Noise() * Mathf.Exp(-t * 30f) * 0.35f);
            clips[(int)Sfx.Click] = Make("click", 0.04f, t => Sin(700, t) * Mathf.Exp(-t * 90f) * 0.5f);
            clips[(int)Sfx.Angry] = Make("angry", 0.4f, t => Sin(400f - 250f * t, t) * Mathf.Exp(-t * 4f) * 0.35f);
            clips[(int)Sfx.Pickup] = Make("pickup", 0.1f, t => Sin(500f + 900f * t, t) * Mathf.Exp(-t * 20f) * 0.35f);
            clips[(int)Sfx.Place] = Make("place", 0.12f, t => Sin(300f - 600f * t, t) * Mathf.Exp(-t * 22f) * 0.4f + Noise() * Mathf.Exp(-t * 50f) * 0.15f);
            float[] up = { 523, 659, 784, 1047 };
            clips[(int)Sfx.Upgrade] = Make("upgrade", 0.7f, t => Arp(t, up, 0.12f, 6f));
            float[] day = { 392, 523, 659, 784, 1047 };
            clips[(int)Sfx.Day] = Make("day", 0.9f, t => Arp(t, day, 0.15f, 5f));
            clips[(int)Sfx.BatSwing] = Make("bat_swing", 0.28f, t => Noise() * Mathf.Exp(-t * 11f) * Mathf.Clamp01(t * 9f) * 0.5f + Sin(95f, t) * Mathf.Exp(-t * 16f) * 0.18f);
            clips[(int)Sfx.BatHit] = Make("bat_hit", 0.16f, t => Noise() * Mathf.Exp(-t * 30f) * 0.45f + Sin(130f, t) * Mathf.Exp(-t * 20f) * 0.35f);

            // ----- двери -----
            float lpd = 0f;
            clips[(int)Sfx.DoorOpen] = Make("door_open", 0.6f, t =>
            {
                lpd += (Noise() - lpd) * 0.08f;
                float creak = Sin(150f - 40f * t, t) * 0.12f * Mathf.Sin(Mathf.PI * Mathf.Clamp01(t / 0.45f));
                float latch = t < 0.03f ? Noise() * 0.5f * (1f - t / 0.03f) : 0f;
                return creak + lpd * 0.25f * Mathf.Exp(-t * 4f) + latch;
            });
            clips[(int)Sfx.DoorClose] = Make("door_close", 0.35f, t =>
                Sin(75f, t) * Mathf.Exp(-t * 14f) * 0.8f + Noise() * Mathf.Exp(-t * 40f) * 0.3f + (t > 0.09f && t < 0.11f ? Sin(1200f, t) * 0.3f : 0f));

            // ----- касса и сканер -----
            clips[(int)Sfx.Scan] = Make("scan", 0.17f, t =>
            {
                float f = t < 0.075f ? 1800f : 2400f;
                float lt = t < 0.075f ? t : t - 0.075f;
                return Sin(f, t) * Mathf.Clamp01(lt / 0.004f) * Mathf.Exp(-lt * 22f) * 0.38f;
            });
            float lpk = 0f;
            clips[(int)Sfx.Drawer] = Make("drawer", 0.55f, t =>
            {
                lpk += (Noise() - lpk) * 0.15f;
                float slide = t < 0.22f ? lpk * 0.35f * Mathf.Sin(Mathf.PI * t / 0.22f) : 0f;
                float t2 = t - 0.22f;
                float ding = t2 > 0f ? (Sin(3136f, t2) + 0.4f * Sin(4698f, t2)) * Mathf.Exp(-t2 * 9f) * 0.25f : 0f;
                return slide + ding;
            });

            // ----- коробки -----
            clips[(int)Sfx.BoxOpen] = Make("box_open", 0.5f, t =>
            {
                float rasp = Noise() * (0.55f + 0.45f * Sin(60f, t)) * Mathf.Clamp01(1f - t / 0.32f) * 0.45f;
                float thump = Sin(85f, t) * Mathf.Exp(-t * 18f) * 0.5f * (t > 0.3f ? 1f : 0.2f);
                return rasp + thump;
            });

            // ----- уведомления и тревога -----
            clips[(int)Sfx.Notify] = Make("notify", 0.45f, t =>
            {
                float a = Sin(988f, t) * Mathf.Exp(-t * 9f);
                float t2 = t - 0.12f;
                float b = t2 > 0f ? Sin(1319f, t2) * Mathf.Exp(-t2 * 8f) : 0f;
                return (a + b) * 0.3f;
            });
            clips[(int)Sfx.Alarm] = Make("alarm", 0.9f, t =>
            {
                float f = ((int)(t / 0.15f) % 2 == 0) ? 920f : 690f;
                float s = Sin(f, t) + 0.35f * Sin(f * 2f, t);
                return s * 0.22f * Mathf.Clamp01(t / 0.02f) * Mathf.Clamp01((0.9f - t) / 0.08f);
            });
            clips[(int)Sfx.Whistle] = Make("whistle", 0.55f, t =>
            {
                float trill = 1f + 0.03f * Sin(28f, t);
                float env = Mathf.Clamp01(t / 0.03f) * Mathf.Clamp01((0.55f - t) / 0.1f);
                return (Sin(2650f * trill, t) * 0.25f + Noise() * 0.04f) * env;
            });

            // ----- голоса покупателей -----
            clips[(int)Sfx.VoiceHi] = Make("voice_hi", 0.38f, t => Voice(t, 0.38f, 175f, 150f, 700f, 1200f, 0.02f));
            clips[(int)Sfx.VoiceHappy] = Make("voice_happy", 0.42f, t => Voice(t, 0.42f, 200f, 270f, 520f, 1800f, 0.01f));
            clips[(int)Sfx.VoiceGrumble] = Make("voice_grumble", 0.55f, t => Voice(t, 0.55f, 105f, 78f, 420f, 900f, 0.05f));
        }

        AudioClip MakeAmbient()
        {
            float lp = 0f;
            return Make("ambient", 6f, t =>
            {
                lp += (Noise() - lp) * 0.03f;
                float hum = (Sin(55, t) + 0.5f * Sin(110, t)) * 0.04f;
                float swell = 0.5f + 0.5f * Sin(1f / 6f, t);
                return hum + lp * (0.25f + 0.35f * swell);
            });
        }

        /// <summary>
        /// Уютный лоу-фай луп, ~23 с: бас, мягкий пэд, арпеджио, лёгкий хэт и редкая мелодия в миноре.
        /// Am – F – C – G – Am – Dm – F – E.
        /// </summary>
        AudioClip MakeMusic()
        {
            float[] roots = { 110f, 87.3f, 130.8f, 98f, 110f, 73.4f, 87.3f, 82.4f };
            float[][] tones =
            {
                new[] { 220f, 261.6f, 329.6f }, new[] { 174.6f, 220f, 261.6f }, new[] { 261.6f, 329.6f, 392f },
                new[] { 196f, 246.9f, 293.7f }, new[] { 220f, 261.6f, 329.6f }, new[] { 146.8f, 174.6f, 220f },
                new[] { 174.6f, 220f, 261.6f }, new[] { 164.8f, 207.7f, 246.9f }
            };
            float[] penta = { 440f, 523.3f, 587.3f, 659.3f, 784f, 880f };
            var mr = new System.Random(23);
            float[] melody = new float[8 * 8];
            for (int i = 0; i < melody.Length; i++) melody[i] = mr.NextDouble() < 0.55 ? 0f : penta[mr.Next(penta.Length)];

            const float beat = 60f / 84f;
            float chordLen = beat * 4f, eighth = beat / 2f;
            int[] pat = { 0, 1, 2, 1, 0, 1, 2, 1 };
            float hat = 0f;
            return Make("music", chordLen * 8f, t =>
            {
                int ci = Mathf.Min(7, (int)(t / chordLen));
                float lt = t - ci * chordLen;
                int ni = Mathf.Min(7, (int)(lt / eighth));
                float nt = lt - ni * eighth;

                float f = tones[ci][pat[ni]] * 2f;
                float pluck = (Sin(f, t) + 0.3f * Sin(f * 2f, t)) * Mathf.Exp(-nt * 7f) * 0.14f;
                float pad = (Sin(tones[ci][0], t) + Sin(tones[ci][1], t) * 0.8f + Sin(tones[ci][2], t) * 0.6f) * 0.03f
                            * Mathf.Sin(Mathf.PI * lt / chordLen);

                int bi = Mathf.Min(3, (int)(lt / beat));
                float bt = lt - bi * beat;
                float bf = roots[ci] * (bi == 2 ? 1.5f : 1f);
                float bass = (Sin(bf, t) + 0.25f * Sin(bf * 2f, t)) * Mathf.Exp(-bt * 2.5f) * 0.2f;

                float offBeat = (lt % beat) - beat * 0.5f;
                float h = 0f;
                if (offBeat > 0f && offBeat < 0.06f)
                {
                    hat += (Noise() - hat) * 0.7f;
                    h = hat * Mathf.Exp(-offBeat * 70f) * 0.07f;
                }
                float kick = bt < 0.12f && (bi == 0 || bi == 2) ? Sin(60f * (1f - bt * 3f), t) * Mathf.Exp(-bt * 28f) * 0.22f : 0f;

                float mf = melody[ci * 8 + ni];
                float lead = mf > 0f ? (Sin(mf, t) + 0.2f * Sin(mf * 2f, t)) * Mathf.Exp(-nt * 4.5f) * 0.07f * Mathf.Clamp01(nt / 0.01f) : 0f;
                return pluck + pad + bass + h + kick + lead;
            });
        }
    }
}
