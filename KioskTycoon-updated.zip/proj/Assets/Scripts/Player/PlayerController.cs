using UnityEngine;

namespace KioskTycoon
{
    /// <summary>First-person movement, physical item handling and the game's wellbeing effect.</summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public static PlayerController I;
        public Camera Cam;
        public Transform Hand;
        public readonly PlayerContext Ctx = new PlayerContext();
        public Interactable Target { get; private set; }
        public string Prompt { get; private set; }
        public float Wellbeing { get; private set; } = 100f;
        public bool CarryingPhysicalItem => grabber != null && grabber.IsCarrying;
        public ItemGrabber Grabber => grabber;

        const float WalkSpeed = 2.4f, RunSpeed = 4f, Gravity = -12f, EyeHeight = 1.6f, ReachDistance = 3.2f;
        CharacterController cc;
        float pitch, yaw, vy, holdTimer, fatigueTimer, actionTimer, nextPuffTime, footstepTimer, batTimer, nextBatTime;
        float basePitch;
        bool inhaleNext = true, deviceAnimating, inhaling;
        Transform device;
        Transform bat;
        bool batSwinging;
        ParticleSystem vapor;
        ItemGrabber grabber;

        void Awake()
        {
            I = this;
            cc = GetComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.28f;
            cc.center = new Vector3(0f, 0.9f, 0f);

            var eyes = new GameObject("Eyes");
            eyes.transform.SetParent(transform, false);
            eyes.transform.localPosition = new Vector3(0f, EyeHeight, 0f);
            Cam = eyes.AddComponent<Camera>();
            Cam.nearClipPlane = 0.05f;
            Cam.farClipPlane = 120f;
            Cam.clearFlags = CameraClearFlags.SolidColor;
            eyes.AddComponent<AudioListener>();

            Hand = new GameObject("Hand").transform;
            Hand.SetParent(Cam.transform, false);
            Hand.localPosition = new Vector3(0.18f, -0.32f, 0.5f);
            Hand.localRotation = Quaternion.Euler(0f, -15f, 0f);
            grabber = gameObject.AddComponent<ItemGrabber>();
            grabber.Init(Cam);
            BuildDevice();
            BuildBat();
            ThemeManager.Changed += OnTheme;
        }

        void OnDestroy() { ThemeManager.Changed -= OnTheme; if (I == this) I = null; }
        void OnTheme() { if (Cam != null) Cam.backgroundColor = DayNight.Sky; }

        void Start()
        {
            Cam.backgroundColor = DayNight.Sky;
            transform.position = KioskBuilder.PlayerSpawn;
            yaw = 180f;
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        void Update()
        {
            bool blocked = GameUI.Blocked;
            Cursor.lockState = blocked ? CursorLockMode.None : CursorLockMode.Locked;
            Cursor.visible = blocked;

            if (!blocked) Look();
            Move(blocked);
            UpdateWellbeing();
            UpdateDevice();
            UpdateBat();
            if (Input.GetKeyDown(KeyCode.Escape)) OnEscape();
            UpdateTarget();
            grabber.Tick(blocked);                  // ЛКМ: взять / перенести / поставить (колесо — расстояние)
            if (!blocked) HandleKeys();
            else if (Binds.Down(GameAction.Interact) && CashRegister.I != null && CashRegister.I.CanSell) CashRegister.I.SellScanned();
        }

        /// <summary>Мгновенный перенос игрока (например, утром к дому).</summary>
        public void TeleportTo(Vector3 pos, float newYaw)
        {
            cc.enabled = false;
            transform.position = pos;
            yaw = newYaw;
            pitch = 0f;
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            vy = 0f;
            cc.enabled = true;
        }

        void Look()
        {
            var d = SettingsManager.Data;
            yaw += Input.GetAxis("Mouse X") * d.sensitivity;
            pitch -= Input.GetAxis("Mouse Y") * d.sensitivity * (d.invertY ? -1f : 1f);
            pitch = Mathf.Clamp(pitch, -80f, 80f);
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            basePitch = pitch;
            Cam.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
        }

        void Move(bool blocked)
        {
            Vector3 input = Vector3.zero;
            if (!blocked)
            {
                if (Binds.Held(GameAction.Forward)) input += Vector3.forward;
                if (Binds.Held(GameAction.Back)) input -= Vector3.forward;
                if (Binds.Held(GameAction.Right)) input += Vector3.right;
                if (Binds.Held(GameAction.Left)) input -= Vector3.right;
            }
            input = Vector3.ClampMagnitude(input, 1f);
            float sp = Binds.Held(GameAction.Run) ? RunSpeed : WalkSpeed;
            Vector3 move = transform.TransformDirection(input) * sp;
            vy = cc.isGrounded ? -1f : vy + Gravity * Time.deltaTime;
            move.y = vy;
            if (cc.enabled) cc.Move(move * Time.deltaTime);
            if (cc.isGrounded && input.sqrMagnitude > 0.05f)
            {
                footstepTimer -= Time.deltaTime;
                if (footstepTimer <= 0f)
                {
                    AudioManager.Play(Sfx.Step, 0.45f);
                    footstepTimer = Binds.Held(GameAction.Run) ? 0.32f : 0.48f;
                }
            }
            else footstepTimer = 0.08f;
        }

        void UpdateWellbeing()
        {
            float interval = Mathf.Clamp(SettingsManager.Data.wellbeingInterval, 15f, 180f);
            fatigueTimer += Time.deltaTime;
            if (fatigueTimer >= interval)
            {
                fatigueTimer -= interval;
                Wellbeing = Mathf.Max(0f, Wellbeing - 7f);
            }

            float effect = (1f - Wellbeing / 100f) * Mathf.Clamp01(SettingsManager.Data.wellbeingEffect);
            float sway = effect * 0.65f * Mathf.Sin(Time.time * 1.7f);
            Cam.transform.localRotation = Quaternion.Euler(basePitch, 0f, sway);
        }

        void BuildDevice()
        {
            device = new GameObject("Handheld device").transform;
            device.SetParent(Hand, false);
            device.localPosition = new Vector3(0f, 0f, 0.12f);
            device.localRotation = Quaternion.identity;
            Prim.Cube(device, "Vape body", Vector3.zero, new Vector3(0.055f, 0.16f, 0.045f), Mats.Textured(TexGen.VapeFinish(), Vector2.one, 0.38f), false);
            Prim.Cube(device, "Vape mouthpiece", new Vector3(0f, 0.087f, 0f), new Vector3(0.025f, 0.018f, 0.024f), Mats.Solid(new Color(0.06f, 0.08f, 0.12f), 0.5f), false);
            Prim.Cube(device, "Vape top trim", new Vector3(0f, 0.074f, 0f), new Vector3(0.058f, 0.009f, 0.048f), Mats.Solid(new Color(0.28f, 0.37f, 0.48f), 0.55f, 0.3f), false);
            Prim.Cube(device, "Vape display", new Vector3(0f, 0.024f, 0.024f), new Vector3(0.032f, 0.026f, 0.003f), Mats.Solid(new Color(0.035f, 0.07f, 0.11f), 0.55f), false);
            Prim.Cube(device, "Vape indicator", new Vector3(0f, 0.024f, 0.026f), new Vector3(0.018f, 0.005f, 0.002f), Mats.Emissive(new Color(0.35f, 0.9f, 1f), 1.1f), false);
            Prim.Cube(device, "Vape button", new Vector3(0f, -0.019f, 0.024f), new Vector3(0.018f, 0.018f, 0.004f), Mats.Solid(new Color(0.4f, 0.48f, 0.58f), 0.6f, 0.2f), false);
            Prim.Cube(device, "Vape bottom cap", new Vector3(0f, -0.075f, 0f), new Vector3(0.058f, 0.012f, 0.048f), Mats.Solid(new Color(0.07f, 0.1f, 0.15f), 0.45f), false);

            var puff = new GameObject("Vapor").transform;
            puff.SetParent(Cam.transform, false);
            puff.localPosition = new Vector3(0.08f, -0.12f, 0.42f);
            vapor = puff.gameObject.AddComponent<ParticleSystem>();
            var main = vapor.main;
            main.loop = false;
            main.playOnAwake = false;
            main.startLifetime = 1.1f;
            main.startSpeed = 0.45f;
            main.startSize = 0.07f;
            main.startColor = new Color(0.86f, 0.9f, 0.95f, 0.42f);
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            var emission = vapor.emission;
            emission.enabled = false;
        }

        void BuildBat()
        {
            bat = new GameObject("Player bat").transform;
            bat.SetParent(Hand, false);
            bat.localPosition = new Vector3(0.25f, -0.34f, 0.48f);
            bat.localRotation = Quaternion.Euler(0f, 0f, -24f);
            var wood = Mats.Solid(new Color(0.48f, 0.27f, 0.14f), 0.32f);
            var grip = Mats.Solid(new Color(0.12f, 0.14f, 0.16f), 0.25f);
            Prim.Cyl(bat, "Ashwood barrel", new Vector3(0f, 0.27f, 0f), 0.075f, 0.52f, wood);
            Prim.Cyl(bat, "Rounded end", new Vector3(0f, 0.53f, 0f), 0.085f, 0.12f, Mats.Solid(new Color(0.58f, 0.35f, 0.19f), 0.3f));
            Prim.Cyl(bat, "Wrapped grip", new Vector3(0f, -0.105f, 0f), 0.04f, 0.24f, grip);
            Prim.Cyl(bat, "Grip knob", new Vector3(0f, -0.245f, 0f), 0.06f, 0.055f, wood);
            Prim.Cyl(bat, "Grip band", new Vector3(0f, -0.015f, 0f), 0.043f, 0.025f, Mats.Solid(new Color(0.82f, 0.64f, 0.34f), 0.4f));
            bat.gameObject.SetActive(false);
        }

        void UpdateBat()
        {
            if (!batSwinging || bat == null) return;
            batTimer += Time.deltaTime;
            float t = Mathf.Clamp01(batTimer / 0.42f);
            float swing = Mathf.Sin(t * Mathf.PI);
            bat.localRotation = Quaternion.Euler(-25f - 105f * swing, 0f, -24f + 78f * swing);
            bat.localPosition = new Vector3(0.25f, -0.34f + 0.08f * swing, 0.48f);
            if (t < 1f) return;
            batSwinging = false;
            bat.localRotation = Quaternion.Euler(0f, 0f, -24f);
            bat.localPosition = new Vector3(0.25f, -0.34f, 0.48f);
            bat.gameObject.SetActive(false);
        }

        public void SwingBat()
        {
            if (batSwinging || Time.time < nextBatTime) return;
            nextBatTime = Time.time + 0.65f;
            batSwinging = true;
            batTimer = 0f;
            bat.gameObject.SetActive(true);
            AudioManager.Play(Sfx.BatSwing);

            var ray = Cam.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
            var hits = Physics.SphereCastAll(ray, 0.14f, 2.1f, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore);
            System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
            foreach (var hit in hits)
            {
                var thief = hit.collider.GetComponentInParent<IFleeing>();
                if (thief != null)
                {
                    if (thief.IsFleeing || (thief is Thief intruder && intruder.CanBeScared)) thief.Catch(false);
                    break;
                }
                if (!hit.collider.isTrigger) break;
            }
        }

        void UpdateDevice()
        {
            if (!deviceAnimating) return;
            actionTimer -= Time.deltaTime;
            float duration = inhaling ? Mathf.Clamp(SettingsManager.Data.inhaleDuration, 0.5f, 5f)
                : Mathf.Clamp(SettingsManager.Data.exhaleDuration, 0.5f, 5f);
            float progress = 1f - Mathf.Clamp01(actionTimer / duration);
            device.localPosition = new Vector3(0f, Mathf.Lerp(0f, 0.11f, Mathf.Sin(progress * Mathf.PI)), 0.12f);
            if (actionTimer > 0f) return;
            device.localPosition = new Vector3(0f, 0f, 0.12f);
            deviceAnimating = false;
        }

        void UseDevice()
        {
            if (deviceAnimating) return;
            if (inhaleNext && Time.time < nextPuffTime)
            {
                Toast.Push(Loc.Get("hud.puffWait"));
                return;
            }
            inhaling = inhaleNext;
            inhaleNext = !inhaleNext;
            float duration = inhaling ? Mathf.Clamp(SettingsManager.Data.inhaleDuration, 0.5f, 5f)
                : Mathf.Clamp(SettingsManager.Data.exhaleDuration, 0.5f, 5f);
            actionTimer = duration;
            deviceAnimating = true;
            if (!inhaling)
            {
                Wellbeing = Mathf.Min(100f, Wellbeing + 28f);
                fatigueTimer = 0f;
                vapor.Emit(12);
            }
            else nextPuffTime = Time.time + Mathf.Clamp(SettingsManager.Data.puffInterval, 1f, 20f);
        }

        void UpdateTarget()
        {
            Target = null;
            Prompt = null;
            if (GameUI.Blocked) return;
            var held = grabber != null ? grabber.HeldProduct : null;
            if (held != null && !held.IsUsing)
            {
                Target = held;
                Prompt = held.Prompt(Ctx);
                return;
            }
            var ray = Cam.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
            var hits = Physics.RaycastAll(ray, ReachDistance);
            System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
            foreach (var hit in hits)
            {
                var it = hit.collider.GetComponentInParent<Interactable>();
                if (it is ShelfSlot && hit.collider.isTrigger) continue;
                if (it != null && hit.distance <= it.MaxDistance)
                {
                    Target = it;
                    Prompt = it.Prompt(Ctx);
                    return;
                }
                if (!hit.collider.isTrigger) return;
            }
        }

        void HandleKeys()
        {
            if (Target != null && Prompt != null)
            {
                if (Binds.Down(GameAction.Interact))
                {
                    Target.Interact(Ctx);
                    holdTimer = 0.3f;
                }
                else if (Binds.Held(GameAction.Interact) && Target.AllowHold)
                {
                    holdTimer -= Time.deltaTime;
                    if (holdTimer <= 0f) { Target.Interact(Ctx); holdTimer = 0.16f; }
                }
            }
            if (Binds.Down(GameAction.Drop))
            {
                if (Ctx.heldBox != null) StockManager.I.StoreBox(Ctx.heldBox, Ctx);
                else if (Ctx.TrayCount > 0) StockManager.I.ReturnTray(Ctx);
            }
            if (Binds.Down(GameAction.Decline) && CashRegister.I != null) CashRegister.I.Decline();
            if (Binds.Down(GameAction.Inventory) && HUD.I != null) HUD.I.ToggleInventory();
            if (Binds.Down(GameAction.UseDevice)) UseDevice();
            if (Binds.Down(GameAction.UseBat)) SwingBat();
            if (Binds.Down(GameAction.CallGuard) && SecurityManager.I != null) SecurityManager.I.CallGuard();
        }

        void OnEscape()
        {
            if (ComputerUI.I != null && ComputerUI.I.IsOpen) ComputerUI.I.Close();
            else if (PauseMenu.I != null) PauseMenu.I.Toggle();
        }
    }
}
