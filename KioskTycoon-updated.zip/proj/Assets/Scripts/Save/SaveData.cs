using System;
using System.Collections.Generic;

namespace KioskTycoon
{
    /// <summary>Порядок значений — часть формата сохранения: новые улучшения добавляются только в конец.</summary>
    public enum UpgradeType { Size, Shelves, Storage, Register, Display, Decor, Cameras, Guard }

    [Serializable] public class ShelfProductEntry { public string id; public int count; }
    [Serializable]
    public class ShelfEntry
    {
        // id/count remain as a backwards-compatible mirror for old save files.
        public string id;
        public int count;
        public List<ShelfProductEntry> goods = new List<ShelfProductEntry>();

        public void EnsureGoods()
        {
            if (goods == null) goods = new List<ShelfProductEntry>();
            goods.RemoveAll(g => g == null || string.IsNullOrEmpty(g.id) || g.count <= 0);
            if (goods.Count == 0 && !string.IsNullOrEmpty(id) && count > 0)
                goods.Add(new ShelfProductEntry { id = id, count = count });
            SyncLegacy();
        }

        public int TotalCount
        {
            get { EnsureGoods(); int total = 0; foreach (var g in goods) total += g.count; return total; }
        }

        public int CountOf(string productId)
        {
            EnsureGoods();
            foreach (var g in goods) if (g.id == productId) return g.count;
            return 0;
        }

        public ShelfProductEntry GetOrAdd(string productId)
        {
            EnsureGoods();
            foreach (var g in goods) if (g.id == productId) return g;
            var added = new ShelfProductEntry { id = productId, count = 0 };
            goods.Add(added);
            return added;
        }

        public void SyncLegacy()
        {
            if (goods == null || goods.Count == 0) { id = ""; count = 0; return; }
            id = goods[0].id;
            count = goods[0].count;
        }
    }
    [Serializable] public class PriceEntry { public string id; public float price; }
    [Serializable] public class BoxEntry { public string id; public int qty; public float eta; public bool opened; }
    [Serializable] public class LooseProductEntry { public string id; public UnityEngine.Vector3 position; public bool opened; }

    /// <summary>Весь игровой прогресс. Сериализуется в JSON.</summary>
    [Serializable]
    public class SaveData
    {
        public int version = 3;
        public const int UpgradeCount = 8;
        public float money = 250f;
        public float reputation = 40f;
        public int day = 1;
        public int[] upgrades = new int[UpgradeCount];
        public ShelfEntry[] shelves = MakeShelves();
        public List<PriceEntry> prices = new List<PriceEntry>();
        public List<BoxEntry> boxes = new List<BoxEntry>();
        public List<BoxEntry> pending = new List<BoxEntry>();
        public List<LooseProductEntry> looseGoods = new List<LooseProductEntry>();
        public float totalRevenue;
        public float totalExpenses;
        public int totalServed;
        public int totalLost;
        public int totalStolenItems;
        public float totalStolenValue;
        public float totalRecoveredValue;
        public bool tutorialDone;

        static ShelfEntry[] MakeShelves()
        {
            var a = new ShelfEntry[12];
            for (int i = 0; i < a.Length; i++) a[i] = new ShelfEntry();
            return a;
        }

        public int Up(UpgradeType t) => upgrades[(int)t];

        public static SaveData CreateNew()
        {
            var d = new SaveData();
            string[] starter = { "lumen", "kedr", "minty", "aqua" };
            for (int i = 0; i < starter.Length; i++) { d.shelves[i].id = starter[i]; d.shelves[i].count = 8; }
            return d;
        }

        public void Sanitize()
        {
            version = 3;
            if (upgrades == null || upgrades.Length < UpgradeCount) Array.Resize(ref upgrades, UpgradeCount);
            if (shelves == null || shelves.Length < 12)
            {
                var n = MakeShelves();
                if (shelves != null) for (int i = 0; i < shelves.Length; i++) n[i] = shelves[i] ?? new ShelfEntry();
                shelves = n;
            }
            else
                for (int i = 0; i < shelves.Length; i++) if (shelves[i] == null) shelves[i] = new ShelfEntry();
            foreach (var shelf in shelves) if (shelf != null) shelf.EnsureGoods();
            if (prices == null) prices = new List<PriceEntry>();
            if (boxes == null) boxes = new List<BoxEntry>();
            if (pending == null) pending = new List<BoxEntry>();
            if (looseGoods == null) looseGoods = new List<LooseProductEntry>();
        }
    }
}
