using System;
using System.IO;
using UnityEngine;

namespace KioskTycoon
{
    public static class SaveSystem
    {
        static string PathFile => Path.Combine(Application.persistentDataPath, "save.json");

        public static bool Exists() => File.Exists(PathFile);

        public static void Save(SaveData d)
        {
            try { File.WriteAllText(PathFile, JsonUtility.ToJson(d, true)); }
            catch (Exception e) { Debug.LogWarning("Save failed: " + e.Message); }
        }

        public static SaveData Load()
        {
            try
            {
                if (!File.Exists(PathFile)) return null;
                var d = JsonUtility.FromJson<SaveData>(File.ReadAllText(PathFile));
                d?.Sanitize();
                return d;
            }
            catch (Exception e) { Debug.LogWarning("Load failed: " + e.Message); return null; }
        }
    }
}
