using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Компьютер на кассе: вход в окно закупок, цен, улучшений и статистики.</summary>
    public class ComputerTerminal : Interactable
    {
        public override float MaxDistance => 2.6f;

        public static ComputerTerminal Create(Transform parent, Vector3 pos)
        {
            var go = new GameObject("Computer");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            var dark = Mats.Solid(new Color(0.12f, 0.12f, 0.14f), 0.4f);
            Prim.Cube(go.transform, "Monitor", new Vector3(0f, 0.17f, 0f), new Vector3(0.42f, 0.3f, 0.03f), dark, false);
            Prim.Cube(go.transform, "Screen", new Vector3(0f, 0.17f, 0.016f), new Vector3(0.36f, 0.24f, 0.005f),
                Mats.Emissive(new Color(0.35f, 0.85f, 1f), 1.2f), false);
            Prim.Cyl(go.transform, "Stand", new Vector3(0f, 0.03f, 0f), 0.08f, 0.06f, dark);
            Prim.Cube(go.transform, "Keyboard", new Vector3(0f, 0.012f, 0.12f), new Vector3(0.3f, 0.02f, 0.1f), dark, false);
            var bc = go.AddComponent<BoxCollider>();
            bc.center = new Vector3(0f, 0.2f, 0f);
            bc.size = new Vector3(0.45f, 0.4f, 0.25f);
            return go.AddComponent<ComputerTerminal>();
        }

        public override string Prompt(PlayerContext p) => Loc.Get("p.pc");

        public override void Interact(PlayerContext p)
        {
            if (ComputerUI.I != null) ComputerUI.I.Open();
        }
    }

    /// <summary>Окно компьютера (IMGUI). Открывается с кассы; пока открыто, игрок не двигается.</summary>
    public class ComputerUI : MonoBehaviour
    {
        public static ComputerUI I;
        public bool IsOpen { get; private set; }
        int tab;
        Vector2 scroll;
        SaveData D => GameSession.Data;

        void Awake() { I = this; }

        public void Open() { IsOpen = true; tab = 0; scroll = Vector2.zero; }
        public void Close() { IsOpen = false; }

        List<ProductData> Available()
        {
            var list = new List<ProductData>();
            int display = D.Up(UpgradeType.Display);
            foreach (var p in GameDatabase.Products) if (p.unlockLevel <= display) list.Add(p);
            return list;
        }

        void OnGUI()
        {
            if (!IsOpen) return;
            UIKit.Begin();
            float vw = UIKit.VW;
            var t = ThemeManager.Current;
            UIKit.Box(new Rect(0, 0, vw, 1080), new Color(0, 0, 0, 0.55f));
            var panel = new Rect(vw / 2f - 730, 70, 1460, 940);
            UIKit.Panel(panel, Loc.Get("pc.title"));
            UIKit.Label(new Rect(panel.xMax - 520, panel.y + 12, 480, 40),
                Loc.F("pc.money", UIKit.Money(D.money)), 30, t.accent, TextAnchor.MiddleRight, true, false);

            string[] names = { Loc.Get("pc.orders"), Loc.Get("pc.prices"), Loc.Get("pc.upgrades"), Loc.Get("pc.stats") };
            tab = UIKit.Tabs(new Rect(panel.x + 20, panel.y + 80, panel.width - 40, 62), names, tab);

            var body = new Rect(panel.x + 20, panel.y + 160, panel.width - 40, panel.height - 250);
            switch (tab)
            {
                case 0: DrawOrders(body); break;
                case 1: DrawPrices(body); break;
                case 2: DrawUpgrades(body); break;
                default: DrawStats(body); break;
            }

            if (UIKit.Button(new Rect(panel.xMax - 280, panel.yMax - 74, 250, 56), Loc.Get("pc.close"), true, 30, t.accent2))
                Close();
            UIKit.End();
        }

        void DrawOrders(Rect r)
        {
            var t = ThemeManager.Current;
            var list = Available();
            const float rowH = 70f;
            float pendingH = D.pending.Count > 0 ? 50f + 36f * Mathf.Min(4, PendingGroups().Count) : 0f;
            var view = new Rect(0, 0, r.width - 24, list.Count * rowH + pendingH);
            scroll = GUI.BeginScrollView(r, scroll, view);
            float y = 0f;
            foreach (var p in list)
            {
                var row = new Rect(0, y, view.width, rowH - 8);
                UIKit.Plate(row);
                UIKit.Label(new Rect(row.x + 18, row.y + 6, 340, row.height - 12), p.displayName, 28, t.text, TextAnchor.MiddleLeft, true, false);
                UIKit.Label(new Rect(row.x + 370, row.y + 6, 180, row.height - 12), Loc.F("pc.shelf", StockManager.I.OnShelves(p)), 24, t.textDim, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(row.x + 540, row.y + 6, 180, row.height - 12), Loc.F("pc.store", StockManager.I.InStorage(p)), 24, t.textDim, TextAnchor.MiddleLeft, false, false);
                float box = StockManager.I.BoxCost(p);
                UIKit.Label(new Rect(row.x + 720, row.y + 6, 320, row.height - 12),
                    Loc.F("pc.box", p.unitsPerBox) + "  ·  " + UIKit.Money(box), 24, t.textDim, TextAnchor.MiddleLeft, false, false);
                bool canOne = D.money >= box;
                bool canFive = D.money >= box * 5f;
                if (UIKit.Button(new Rect(row.xMax - 400, row.y + 9, 180, row.height - 26), Loc.Get("pc.buy1"), canOne, 24))
                    StockManager.I.Order(p, 1);
                if (UIKit.Button(new Rect(row.xMax - 210, row.y + 9, 190, row.height - 26), Loc.Get("pc.buy5"), canFive, 24))
                    StockManager.I.Order(p, 5);
                y += rowH;
            }

            if (D.pending.Count > 0)
            {
                UIKit.Label(new Rect(0, y + 10, view.width, 40), Loc.Get("pc.pending"), 28, t.accent, TextAnchor.MiddleLeft, true, false);
                y += 50;
                int shown = 0;
                foreach (var g in PendingGroups())
                {
                    if (shown++ >= 4) break;
                    var p = GameDatabase.Find(g.id);
                    if (p == null) continue;
                    UIKit.Label(new Rect(18, y, view.width - 36, 34),
                        Loc.F("pc.eta", p.displayName, g.qty, Mathf.CeilToInt(g.eta)), 24, t.textDim, TextAnchor.MiddleLeft, false, false);
                    y += 36;
                }
            }
            GUI.EndScrollView();
        }

        class PendingGroup { public string id; public int qty; public float eta = float.MaxValue; }

        List<PendingGroup> PendingGroups()
        {
            var map = new Dictionary<string, PendingGroup>();
            var order = new List<PendingGroup>();
            foreach (var o in D.pending)
            {
                if (!map.TryGetValue(o.id, out var g))
                {
                    g = new PendingGroup { id = o.id };
                    map[o.id] = g;
                    order.Add(g);
                }
                g.qty += o.qty;
                g.eta = Mathf.Min(g.eta, o.eta);
            }
            return order;
        }

        void DrawPrices(Rect r)
        {
            var t = ThemeManager.Current;
            var list = Available();
            const float rowH = 70f;
            var view = new Rect(0, 0, r.width - 24, list.Count * rowH + 50);
            scroll = GUI.BeginScrollView(r, scroll, view);
            float y = 0f;
            UIKit.Label(new Rect(18, y, view.width, 40), Loc.Get("pc.priceHint"), 22, t.textDim, TextAnchor.MiddleLeft, false, false);
            y += 44f;
            foreach (var p in list)
            {
                var row = new Rect(0, y, view.width, rowH - 8);
                UIKit.Plate(row);
                float price = StockManager.I.GetPrice(p);
                UIKit.Label(new Rect(row.x + 18, row.y + 6, 340, row.height - 12), p.displayName, 28, t.text, TextAnchor.MiddleLeft, true, false);
                UIKit.Label(new Rect(row.x + 370, row.y + 6, 200, row.height - 12), Loc.F("pc.market", UIKit.Money(p.marketPrice)), 24, t.textDim, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(row.x + 570, row.y + 6, 200, row.height - 12), Loc.F("pc.wholesale", UIKit.Money(p.wholesalePrice)), 24, t.textDim, TextAnchor.MiddleLeft, false, false);

                if (UIKit.Button(new Rect(row.xMax - 480, row.y + 9, 70, row.height - 26), "-", true, 30))
                    StockManager.I.SetPrice(p, price - 0.5f);
                UIKit.Label(new Rect(row.xMax - 400, row.y + 6, 150, row.height - 12), Loc.F("pc.cost", UIKit.Money(price)), 26, t.text, TextAnchor.MiddleCenter, true, false);
                if (UIKit.Button(new Rect(row.xMax - 240, row.y + 9, 70, row.height - 26), "+", true, 30))
                    StockManager.I.SetPrice(p, price + 0.5f);

                float ratio = price / Mathf.Max(0.1f, p.marketPrice);
                string hint = ratio > 1.25f ? Loc.Get("pc.expensive")
                    : ratio < 1.0f ? Loc.Get("pc.cheap") : Loc.Get("pc.ok");
                UIKit.Label(new Rect(row.xMax - 150, row.y + 6, 140, row.height - 12), hint, 20, t.textDim, TextAnchor.MiddleCenter, false, true);
                y += rowH;
            }
            GUI.EndScrollView();
        }

        void DrawUpgrades(Rect r)
        {
            var t = ThemeManager.Current;
            const float rowH = 176f;
            var view = new Rect(0, 0, r.width - 24, UpgradeCatalog.Types.Length * rowH + 10);
            scroll = GUI.BeginScrollView(r, scroll, view);
            float y = 0f;
            foreach (var type in UpgradeCatalog.Types)
            {
                var row = new Rect(0, y, view.width, rowH - 10);
                UIKit.Plate(row);
                int lv = D.Up(type);
                int max = UpgradeCatalog.Max(type);
                float tw = row.width - 260;
                UIKit.Label(new Rect(row.x + 18, row.y + 6, 420, 36), UpgradeCatalog.Name(type), 30, t.accent, TextAnchor.MiddleLeft, true, false);
                UIKit.Label(new Rect(row.x + 440, row.y + 6, 260, 36), Loc.F("pc.level", lv, max), 24, t.textDim, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(row.x + 18, row.y + 42, tw, 30),
                    Loc.Get("pc.now") + ": " + UpgradeCatalog.Describe(type, lv), 22, t.textDim, TextAnchor.MiddleLeft, false, false);
                if (lv < max)
                {
                    UIKit.Label(new Rect(row.x + 18, row.y + 72, tw, 30),
                        Loc.Get("pc.next") + ": " + UpgradeCatalog.Describe(type, lv + 1), 22, t.text, TextAnchor.MiddleLeft, true, false);
                    UIKit.Label(new Rect(row.x + 18, row.y + 102, tw, 28), UpgradeCatalog.WorldChange(type), 20, t.good, TextAnchor.MiddleLeft, false, false);
                    string up = UpgradeCatalog.Upkeep(type, lv);
                    if (up.Length > 0)
                        UIKit.Label(new Rect(row.x + 18, row.y + 130, tw, 28), up, 20, t.bad, TextAnchor.MiddleLeft, false, false);
                    float cost = UpgradeCatalog.Cost(type, lv);
                    if (UIKit.Button(new Rect(row.xMax - 230, row.y + 18, 210, row.height - 46),
                        Loc.Get("pc.buy") + " " + UIKit.Money(cost), D.money >= cost, 24))
                        UpgradeManager.Buy(type);
                }
                else
                    UIKit.Label(new Rect(row.xMax - 230, row.y + 18, 210, row.height - 46), Loc.Get("pc.max"), 26, t.accent2, TextAnchor.MiddleCenter, true, false);
                y += rowH;
            }
            GUI.EndScrollView();
        }

        void DrawStats(Rect r)
        {
            var t = ThemeManager.Current;
            var e = EconomyManager.I;
            float profit = e.todayRevenue - e.todayExpenses;
            string[][] rows =
            {
                new[] { Loc.Get("st.day"), D.day.ToString() },
                new[] { Loc.Get("st.revenue"), UIKit.Money(e.todayRevenue) },
                new[] { Loc.Get("st.expenses"), UIKit.Money(e.todayExpenses) },
                new[] { Loc.Get("st.profit"), UIKit.Money(profit) },
                new[] { Loc.Get("st.rep"), Mathf.RoundToInt(D.reputation) + " / 100" },
                new[] { Loc.Get("st.served"), D.totalServed.ToString() },
                new[] { Loc.Get("st.lost"), D.totalLost.ToString() },
                new[] { Loc.Get("st.total"), UIKit.Money(D.totalRevenue) },
                new[] { Loc.Get("sum.thefts"), e.todayThieves + "  ·  " + Loc.Get("sum.caught") + " " + e.todayCaught },
                new[] { Loc.Get("sum.stolen"), "-" + UIKit.Money(e.todayStolenValue) },
            };
            float y = r.y + 4;
            foreach (var row in rows)
            {
                UIKit.Plate(new Rect(r.x, y, r.width, 54));
                UIKit.Label(new Rect(r.x + 30, y + 5, r.width * 0.6f, 44), row[0], 28, t.textDim, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(r.x + r.width * 0.6f, y + 5, r.width * 0.4f - 30, 44), row[1], 30, t.text, TextAnchor.MiddleRight, true, false);
                y += 60;
            }
        }
    }
}
