using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Состояние одного игрока. Вся логика взаимодействия принимает PlayerContext,
    /// поэтому для кооператива достаточно создать несколько контекстов.
    /// </summary>
    public class PlayerContext
    {
        public const int TrayMax = 10;
        public int id;
        public readonly Dictionary<ProductData, int> Tray = new Dictionary<ProductData, int>();
        public DeliveryBox heldBox;
        public int PickCount;

        public int TrayCount { get { int n = 0; foreach (var kv in Tray) n += kv.Value; return n; } }
        public int Get(ProductData p) => Tray.TryGetValue(p, out var n) ? n : 0;

        public bool AddTray(ProductData p, int n = 1)
        {
            if (TrayCount + n > TrayMax) return false;
            Tray[p] = Get(p) + n;
            return true;
        }

        public void RemoveTray(ProductData p, int n)
        {
            int h = Get(p) - n;
            if (h <= 0) Tray.Remove(p); else Tray[p] = h;
        }
    }

    /// <summary>Объект, с которым можно взаимодействовать (наведение + клавиша действия).</summary>
    public abstract class Interactable : MonoBehaviour
    {
        public virtual float MaxDistance => 2.8f;
        public virtual bool AllowHold => false;
        /// <summary>Текст подсказки; null — подсказка не показывается.</summary>
        public abstract string Prompt(PlayerContext p);
        public abstract void Interact(PlayerContext p);
    }

    /// <summary>Подписи в мировом пространстве (рисуются через IMGUI, без проблем со шрифтами).</summary>
    public interface IWorldLabel
    {
        Vector3 LabelPos { get; }
        float LabelMaxDist { get; }
        void DrawLabel(Vector2 screenPos);
    }

    public static class WorldLabels
    {
        static readonly List<IWorldLabel> list = new List<IWorldLabel>();
        public static void Add(IWorldLabel l) { if (!list.Contains(l)) list.Add(l); }
        public static void Remove(IWorldLabel l) { list.Remove(l); }

        public static void DrawAll(Camera cam)
        {
            if (cam == null) return;
            float s = UIKit.S;
            for (int i = 0; i < list.Count; i++)
            {
                var l = list[i];
                if ((l as Object) == null) continue;
                var sp = cam.WorldToScreenPoint(l.LabelPos);
                if (sp.z < 0.2f || sp.z > l.LabelMaxDist) continue;
                l.DrawLabel(new Vector2(sp.x / s, (Screen.height - sp.y) / s));
            }
        }
    }

    public enum ToastKind { Info, Good, Warn }

    public static class Toast
    {
        public class Item { public string text; public ToastKind kind; public float t; }
        public static readonly List<Item> Items = new List<Item>();

        public static void Push(string s, ToastKind k = ToastKind.Info)
        {
            Items.Add(new Item { text = s, kind = k });
            if (Items.Count > 4) Items.RemoveAt(0);
        }
        public static void Good(string s) { Push(s, ToastKind.Good); }
        public static void Warn(string s) { Push(s, ToastKind.Warn); }
    }

    /// <summary>Какие окна сейчас перехватывают мышь.</summary>
    public static class GameUI
    {
        public static bool Blocked =>
            (ComputerUI.I != null && ComputerUI.I.IsOpen) ||
            (PauseMenu.I != null && PauseMenu.I.IsOpen) ||
            (CashRegister.I != null && CashRegister.I.CanSell) ||
            (EconomyManager.I != null && EconomyManager.I.phase == Phase.Summary);
    }
}
