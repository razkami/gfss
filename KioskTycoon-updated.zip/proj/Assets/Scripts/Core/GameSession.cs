using UnityEngine;
using UnityEngine.SceneManagement;

namespace KioskTycoon
{
    /// <summary>Текущая игровая сессия: данные прогресса и переходы между сценами.</summary>
    public static class GameSession
    {
        public const string MenuScene = "MainMenu";
        public const string GameScene = "Kiosk";
        public static SaveData Data;

        public static bool HasSave => SaveSystem.Exists();

        public static void NewGame()
        {
            Data = SaveData.CreateNew();
            SaveSystem.Save(Data);
        }

        public static bool Continue()
        {
            var d = SaveSystem.Load();
            if (d == null) return false;
            Data = d;
            return true;
        }

        public static void Save() { if (Data != null) SaveSystem.Save(Data); }

        public static void EnsureData()
        {
            if (Data == null && !Continue()) NewGame();
        }

        public static void LoadScene(string scene)
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(scene);
        }
    }
}
