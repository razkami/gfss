using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Собирает игровую сцену Kiosk из компонентов. Один объект в сцене — и всё создаётся процедурно.
    /// Порядок важен: экономика и склад, затем здание, затем покупатели, игрок и интерфейс.
    /// </summary>
    public class GameBootstrap : MonoBehaviour
    {
        const float AutosaveEvery = 60f;
        float autosaveTimer;

        void Awake()
        {
            GameSession.EnsureData();
            Time.timeScale = 1f;

            var world = new GameObject("World").transform;
            BuildStreet(world);

            var sun = new GameObject("Sun").AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.0f;
            sun.color = new Color(1f, 0.95f, 0.85f);
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.8f;
            sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

            var dayNight = new GameObject("DayNight").AddComponent<DayNight>();
            dayNight.Sun = sun;

            new GameObject("Economy").AddComponent<EconomyManager>();
            var stock = new GameObject("Stock").AddComponent<StockManager>();

            new GameObject("Security").AddComponent<SecurityManager>();   // до постройки киоска: камеры/охрана строятся вместе с комнатой
            var builder = new GameObject("Kiosk").AddComponent<KioskBuilder>();
            builder.Build();
            stock.Init();
            stock.InitLooseGoods();

            new GameObject("Customers").AddComponent<CustomerSpawner>();
            new GameObject("Shoplifters").AddComponent<ThiefSpawner>();
            new GameObject("Player").AddComponent<PlayerController>();

            var ui = new GameObject("UI");
            ui.AddComponent<HUD>();
            ui.AddComponent<ComputerUI>();
            ui.AddComponent<PauseMenu>();
        }

        void BuildStreet(Transform parent) { StreetBuilder.Build(parent); }

        void Update()
        {
            autosaveTimer += Time.deltaTime;
            if (autosaveTimer < AutosaveEvery) return;
            autosaveTimer = 0f;
            StockManager.SaveNow();
        }

        void OnApplicationQuit()
        {
            StockManager.SaveNow();
            SettingsManager.Save();
        }
    }
}
