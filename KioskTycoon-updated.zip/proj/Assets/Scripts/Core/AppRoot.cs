using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Создаётся автоматически до загрузки любой сцены: настройки, база данных, звук, яркость.</summary>
    public class AppRoot : MonoBehaviour
    {
        public static AppRoot I;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Boot()
        {
            if (I != null) return;
            var go = new GameObject("AppRoot");
            DontDestroyOnLoad(go);
            I = go.AddComponent<AppRoot>();
        }

        void Awake()
        {
            SettingsManager.Load();
            GameDatabase.Load();
            gameObject.AddComponent<AudioManager>();
            SettingsManager.ApplyAll();
        }

        void OnGUI()
        {
            GUI.depth = -100;
            float b = SettingsManager.Data.brightness;
            if (Mathf.Abs(b - 1f) < 0.01f || Event.current.type != EventType.Repaint) return;
            GUI.color = b < 1f ? new Color(0, 0, 0, (1f - b) * 1.2f) : new Color(1, 1, 1, (b - 1f) * 0.35f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }
    }
}
