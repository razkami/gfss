using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// День и ночь: закат после 18:00, ночное небо со звёздами и луной, включаются уличные фонари и лампа у дома,
    /// чёрный экран при сне. Состояние берётся из фазы смены (EconomyManager).
    /// </summary>
    public class DayNight : MonoBehaviour
    {
        public static DayNight I;
        public Light Sun;

        /// <summary>0 — день, 1 — глубокая ночь.</summary>
        public static float Night { get; private set; }
        static readonly Color NightSky = new Color(0.025f, 0.035f, 0.09f);
        static readonly Color DuskSky = new Color(0.55f, 0.28f, 0.3f);
        public static Color Sky
        {
            get
            {
                var day = ThemeManager.Current.sky;
                return Night < 0.5f ? Color.Lerp(day, DuskSky, Night * 2f) : Color.Lerp(DuskSky, NightSky, (Night - 0.5f) * 2f);
            }
        }

        readonly List<Light> lamps = new List<Light>();
        Transform sky;           // звёзды и луна (следуют за игроком)
        GameObject stars;
        float fade, hold;
        int fadePhase;           // 0 — нет, 1 — темнеет, 2 — чёрный экран, 3 — светлеет
        System.Action onBlack;

        void Awake() { I = this; }
        void OnDestroy() { if (I == this) I = null; Night = 0f; }

        void Start()
        {
            foreach (var l in FindObjectsOfType<Light>())
                if (l.name == "Street light" || l.name == "Porch light") lamps.Add(l);
            BuildSky();
            Night = Target();
            Apply();
        }

        void BuildSky()
        {
            sky = new GameObject("Night sky").transform;
            sky.SetParent(transform, false);
            stars = new GameObject("Stars");
            stars.transform.SetParent(sky, false);
            var starMat = Mats.Emissive(Color.white, 2.2f);
            var rnd = new System.Random(4242);
            for (int i = 0; i < 160; i++)
            {
                float az = (float)rnd.NextDouble() * Mathf.PI * 2f;
                float el = Mathf.Lerp(0.12f, 1.3f, (float)rnd.NextDouble());
                var dir = new Vector3(Mathf.Cos(az) * Mathf.Cos(el), Mathf.Sin(el), Mathf.Sin(az) * Mathf.Cos(el));
                float sz = Mathf.Lerp(0.3f, 0.8f, (float)rnd.NextDouble());
                var s = Prim.Cube(stars.transform, "Star", dir * 95f, new Vector3(sz, sz, sz), starMat, false);
                s.transform.localRotation = Quaternion.Euler((float)rnd.NextDouble() * 90f, (float)rnd.NextDouble() * 90f, 0f);
            }
            var moonDir = new Vector3(0.35f, 0.5f, -0.8f).normalized;
            Prim.Sphere(stars.transform, "Moon", moonDir * 90f, 7f, Mats.Emissive(new Color(0.95f, 0.96f, 1f), 1.6f));
            stars.SetActive(false);
        }

        float Target()
        {
            var e = EconomyManager.I;
            if (e == null) return 0f;
            if (e.phase == Phase.Night || e.phase == Phase.Summary) return 1f;
            return Mathf.Clamp01((e.Clock - 18f) / 2f);      // закат с 18:00 до 20:00
        }

        void Update()
        {
            Night = Mathf.MoveTowards(Night, Target(), Time.deltaTime * 0.12f);
            Apply();
            UpdateFade(Time.unscaledDeltaTime);
        }

        void LateUpdate()
        {
            if (sky != null && PlayerController.I != null) sky.position = PlayerController.I.transform.position;
        }

        void Apply()
        {
            float n = Night;
            if (Sun != null)
            {
                // закат: низкое оранжевое солнце, потом синий лунный свет
                float pitch = n < 0.5f ? Mathf.Lerp(50f, 12f, n * 2f) : Mathf.Lerp(12f, 40f, (n - 0.5f) * 2f);
                Sun.transform.rotation = Quaternion.Euler(pitch, n < 0.5f ? -30f : Mathf.Lerp(-30f, 150f, (n - 0.5f) * 2f), 0f);
                var warm = new Color(1f, 0.95f, 0.85f);
                var orange = new Color(1f, 0.55f, 0.28f);
                var moon = new Color(0.42f, 0.52f, 0.9f);
                Sun.color = n < 0.5f ? Color.Lerp(warm, orange, n * 2f) : Color.Lerp(orange, moon, (n - 0.5f) * 2f);
                Sun.intensity = n < 0.5f ? Mathf.Lerp(1f, 0.55f, n * 2f) : Mathf.Lerp(0.55f, 0.2f, (n - 0.5f) * 2f);
            }
            var theme = ThemeManager.Current;
            var dayAmb = Color.Lerp(theme.sky, Color.white, 0.4f) * 0.6f;
            RenderSettings.ambientLight = Color.Lerp(dayAmb, new Color(0.07f, 0.09f, 0.17f), n);

            if (PlayerController.I != null && PlayerController.I.Cam != null) PlayerController.I.Cam.backgroundColor = Sky;

            float lampPower = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((n - 0.25f) / 0.5f));
            foreach (var l in lamps)
            {
                if (l == null) continue;
                l.intensity = lampPower * (l.name == "Porch light" ? 1.3f : 1.4f);
                l.range = l.name == "Porch light" ? 7f : 9f;
                l.enabled = lampPower > 0.01f;
            }
            if (stars != null && stars.activeSelf != (n > 0.55f)) stars.SetActive(n > 0.55f);
        }

        // ---------- сон ----------
        public bool Sleeping => fadePhase != 0;

        public void BeginSleep(System.Action blackAction)
        {
            if (Sleeping) return;
            onBlack = blackAction;
            fadePhase = 1;
            AudioManager.Play(Sfx.DoorClose);
        }

        void UpdateFade(float dt)
        {
            switch (fadePhase)
            {
                case 1:
                    fade = Mathf.MoveTowards(fade, 1f, dt * 1.1f);
                    if (fade >= 1f) { fadePhase = 2; hold = 0f; var a = onBlack; onBlack = null; if (a != null) a(); }
                    break;
                case 2:
                    hold += dt;
                    if (hold > 1.4f) fadePhase = 3;
                    break;
                case 3:
                    fade = Mathf.MoveTowards(fade, 0f, dt * 0.9f);
                    if (fade <= 0f) fadePhase = 0;
                    break;
            }
        }

        void OnGUI()
        {
            if (fade <= 0.001f) return;
            GUI.depth = -1000;
            var old = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, fade);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
            GUI.color = old;
            UIKit.Begin();
            UIKit.Label(new Rect(0, 480, UIKit.VW, 90), Loc.Get("sleep.text"), 56, new Color(1f, 1f, 1f, fade), TextAnchor.MiddleCenter, true, false);
            UIKit.End();
        }
    }
}
