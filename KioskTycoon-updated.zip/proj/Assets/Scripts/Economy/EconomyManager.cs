using UnityEngine;

namespace KioskTycoon
{
    public enum Phase { Closed, Open, Closing, Night, Summary }

    public class DayEvent
    {
        public string key;
        public float spawn = 1f;
        public int cat = -1;
        public float boost = 1f;
        public float wholesale = 1f;
        public float weight = 1f;
    }

    /// <summary>Деньги, репутация, день, время, события, аренда.</summary>
    public class EconomyManager : MonoBehaviour
    {
        public static EconomyManager I;
        public const float DayLength = 300f; // реальных секунд на игровой день (08:00–20:00)
        public const float NightLength = 180f; // реальных секунд ночи (20:00–24:00): за это время нужно запереть киоск и лечь спать

        public Phase phase = Phase.Closed;
        public float dayTimer;
        public DayEvent TodayEvent;
        public float todayRevenue, todayExpenses, summaryRent, summarySalary, repDelta;
        public int todayServed, todayLost;
        // безопасность: итоги краж за смену
        public float todayStolenValue, todayRecoveredValue, todayRefund, todayGuardCost;
        public int todayStolenItems, todayThieves, todayCaught;
        public float nightTimer, todayStolenCash;
        public bool nightRobbed;
        float repAtStart, closeTimer;

        public static readonly DayEvent[] Events =
        {
            new DayEvent { key = "normal", weight = 3f },
            new DayEvent { key = "rain", spawn = 0.75f, weight = 1.2f },
            new DayEvent { key = "holiday", spawn = 1.25f, cat = (int)ProductCategory.Snacks, boost = 1.6f },
            new DayEvent { key = "payday", spawn = 1.35f, cat = (int)ProductCategory.Cigarettes, boost = 1.3f },
            new DayEvent { key = "heat", cat = (int)ProductCategory.Drinks, boost = 2f },
            new DayEvent { key = "prices", wholesale = 1.2f, weight = 0.8f },
            new DayEvent { key = "news", cat = (int)ProductCategory.Press, boost = 2.2f, weight = 0.8f },
        };

        SaveData D => GameSession.Data;
        public float Rep => D.reputation;

        void Awake()
        {
            I = this;
            KioskDoor.ResetLock();
            PickEvent();
            ResetDayStats();
        }

        void PickEvent()
        {
            var r = new System.Random(D.day * 7919 + 13);
            float total = 0f;
            foreach (var e in Events) total += e.weight;
            float x = (float)r.NextDouble() * total;
            TodayEvent = Events[0];
            foreach (var e in Events) { x -= e.weight; if (x <= 0f) { TodayEvent = e; break; } }
            if (D.day == 1) TodayEvent = Events[0];
        }

        void ResetDayStats()
        {
            todayRevenue = todayExpenses = 0f;
            todayServed = todayLost = 0;
            todayStolenValue = todayRecoveredValue = todayRefund = todayGuardCost = 0f;
            todayStolenItems = todayThieves = todayCaught = 0;
            todayStolenCash = 0f;
            nightRobbed = false;
            repAtStart = D.reputation;
        }

        float WeekdayMult { get { int w = (D.day - 1) % 7; return w >= 5 ? 1.3f : (w == 0 ? 0.9f : 1f); } }
        public int Weekday => (D.day - 1) % 7;

        public float SpawnMultiplier =>
            TodayEvent.spawn * WeekdayMult * (0.6f + Rep / 100f * 0.9f) *
            (1f + 0.04f * D.Up(UpgradeType.Decor) + 0.03f * D.Up(UpgradeType.Display));

        public float DemandMult(ProductData p) => TodayEvent.cat == (int)p.category ? TodayEvent.boost : 1f;
        public float WholesaleMult => TodayEvent.wholesale;

        public float Clock => phase == Phase.Night ? 20f + 4f * Mathf.Clamp01(nightTimer / NightLength)
            : phase == Phase.Summary ? 24f : 8f + 12f * Mathf.Clamp01(dayTimer / DayLength);

        public string ClockText()
        {
            float c = Clock; int hh = (int)c; int m = (int)((c - hh) * 60f);
            return (hh % 24).ToString("00") + ":" + m.ToString("00");
        }

        public int RentPerDay => RentFor(D.Up(UpgradeType.Size), D.Up(UpgradeType.Shelves));
        public static int RentFor(int sizeLevel, int shelfLevel) => new[] { 20, 60, 120 }[sizeLevel] + 3 * shelfLevel;
        /// <summary>Все ежедневные расходы (аренда + охрана) для заданных уровней улучшений.</summary>
        public static float DailyCost(int sizeLevel, int shelfLevel, int guardLevel) =>
            RentFor(sizeLevel, shelfLevel) + UpgradeCatalog.GuardSalary[guardLevel];

        // ---------- кражи ----------
        public void RecordTheftAttempt() { todayThieves++; }
        public void RecordTheft(float value, int items)
        {
            todayStolenValue += value; todayStolenItems += items;
            D.totalStolenValue += value; D.totalStolenItems += items;
        }
        public void RecordRecovered(float value)
        {
            todayRecoveredValue += value; D.totalRecoveredValue += value; todayCaught++;
        }
        /// <summary>Страховая выплата по записям камер: деньги возвращаются в кассу, но показываются отдельно.</summary>
        /// <summary>Ночной вор выгреб часть выручки из кассы (10% баланса, не больше 60).</summary>
        public void StealCash()
        {
            float amount = Mathf.Min(D.money * 0.1f, 60f);
            nightRobbed = true;
            if (amount < 1f) return;
            Spend(amount, true);
            todayStolenCash += amount;
            Toast.Warn(Loc.F("t.cashStolen", UIKit.Money(amount)));
        }

        public void RecordRefund(float value) { if (value <= 0f) return; todayRefund += value; Earn(value); }
        public void RecordGuardCost(float value) { todayGuardCost += value; }

        public void Earn(float a) { D.money += a; D.totalRevenue += a; todayRevenue += a; }

        public bool Spend(float a, bool force = false)
        {
            if (!force && D.money < a) return false;
            D.money -= a; D.totalExpenses += a; todayExpenses += a;
            return true;
        }

        public void AddRep(float d) { D.reputation = Mathf.Clamp(D.reputation + d, 0f, 100f); }
        public void RecordServed() { todayServed++; D.totalServed++; }
        public void RecordLost() { todayLost++; D.totalLost++; }

        public void StartDay()
        {
            if (phase != Phase.Closed) return;
            phase = Phase.Open; dayTimer = 0f;
            AudioManager.Play(Sfx.Bell);
            Toast.Good(Loc.F("t.dayopen", D.day));
            Toast.Push(Loc.F("hud.event", Loc.Get("ev." + TodayEvent.key)));
        }

        public void CloseEarly()
        {
            if (phase != Phase.Open) return;
            phase = Phase.Closing; closeTimer = 0f;
            dayTimer = DayLength;                       // закрытие = вечер: небо темнеет
            Toast.Push(Loc.Get("t.closing"));
        }

        void Update()
        {
            if (phase == Phase.Open)
            {
                dayTimer += Time.deltaTime;
                if (dayTimer >= DayLength) { dayTimer = DayLength; phase = Phase.Closing; closeTimer = 0f; Toast.Push(Loc.Get("t.closing")); }
            }
            else if (phase == Phase.Closing)
            {
                closeTimer += Time.deltaTime;
                if (CustomerSpawner.I.Queue.Count == 0 || closeTimer > 40f) EnterNight();
            }
            else if (phase == Phase.Night)
            {
                nightTimer += Time.deltaTime;
                if (nightTimer >= NightLength) { Toast.Warn(Loc.Get("t.passedOut")); Sleep(); }
            }
        }

        /// <summary>Покупатели ушли: наступает ночь. Игрок должен запереть киоск снаружи и вернуться домой.</summary>
        void EnterNight()
        {
            CustomerSpawner.I.ClearAll();
            if (SecurityManager.I != null) SecurityManager.I.EndOfDay();
            phase = Phase.Night;
            nightTimer = 0f;
            if (ThiefSpawner.I != null) ThiefSpawner.I.BeginNight();
            AudioManager.Play(Sfx.Day);
            Toast.Good(Loc.Get("t.nightFalls"));
        }

        /// <summary>Игрок лёг спать дома (или заснул сам): незапертый киоск грабят, затем итоги дня.</summary>
        public void Sleep()
        {
            if (phase != Phase.Night) return;
            if (ThiefSpawner.I != null) ThiefSpawner.I.ResolveOnSleep();
            EndDay();
        }

        void EndDay()
        {
            CustomerSpawner.I.ClearAll();
            if (SecurityManager.I != null) SecurityManager.I.EndOfDay();
            summaryRent = RentPerDay;
            summarySalary = UpgradeCatalog.GuardSalary[D.Up(UpgradeType.Guard)];
            Spend(summaryRent, true);
            if (summarySalary > 0f) { Spend(summarySalary, true); todayGuardCost += summarySalary; }
            repDelta = D.reputation - repAtStart;
            phase = Phase.Summary;
            AudioManager.Play(Sfx.Day);
            StockManager.SaveNow();
        }

        public void NextDay()
        {
            if (phase != Phase.Summary) return;
            D.day++;
            phase = Phase.Closed; dayTimer = 0f; nightTimer = 0f;
            KioskDoor.SetLocked(false);                                   // утром киоск отперт
            if (PlayerController.I != null) PlayerController.I.TeleportTo(HomeDoor.FrontPos, 78f);   // проснулись у дома
            Toast.Push(Loc.Get("t.morning"));
            PickEvent(); ResetDayStats();
            Toast.Push(Loc.F("hud.event", Loc.Get("ev." + TodayEvent.key)));
            StockManager.SaveNow();
        }
    }
}
