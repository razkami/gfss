using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Воры. Днём — редкие кражи у окна. Ночью, если киоск не заперт, приходит налёт из нескольких воров;
    /// если игрок лёг спать, не заперев киоск, оставшиеся воры обчищают его без него (ResolveOnSleep).
    /// </summary>
    public class ThiefSpawner : MonoBehaviour
    {
        public static ThiefSpawner I;
        const float ReachRadius = 2.3f;   // насколько далеко от окна вор готов тянуться
        Thief activeThief;
        float timer = 32f;
        int raidLeft;
        float raidTimer;

        void Awake() { I = this; }
        void OnDestroy() { if (I == this) I = null; }

        /// <summary>Полка с товаром у окна: из тех, до которых можно дотянуться; иначе ближайшая со стоком.</summary>
        public static ShelfSlot PickShelf()
        {
            if (KioskBuilder.I == null) return null;
            var window = new Vector3(0f, 1.1f, 0f);
            var near = new List<ShelfSlot>();
            ShelfSlot closest = null;
            float best = float.MaxValue;
            foreach (var slot in KioskBuilder.I.Slots)
            {
                if (slot.Count <= 0 || !slot.HasPhysicalStock) continue;
                float d = Vector3.Distance(slot.transform.position + Vector3.up * 1.1f, window);
                if (d <= ReachRadius) near.Add(slot);
                if (d < best) { best = d; closest = slot; }
            }
            if (closest == null) return null;
            return near.Count > 0 ? near[Random.Range(0, near.Count)] : closest;
        }

        // ---------------- ночной налёт ----------------
        public void BeginNight()
        {
            var sec = SecurityManager.I;
            float cancel = 0f;
            if (sec != null)
            {
                cancel = UpgradeCatalog.CameraDeterrence[Mathf.Clamp(sec.CamLevel, 0, 3)];
                if (sec.GuardLevel >= 2) cancel += 0.5f;
            }
            raidLeft = Random.value < Mathf.Min(0.85f, cancel) ? 0 : Random.Range(2, 4);
            raidTimer = Random.Range(10f, 16f);
        }

        /// <summary>Игрок лёг спать: активные воры убегают с добычей, оставшиеся (если киоск не заперт) грабят без него.</summary>
        public void ResolveOnSleep()
        {
            if (activeThief != null) { activeThief.ForceFinish(); activeThief = null; }
            if (!KioskDoor.IsLocked)
                while (raidLeft > 0) { SimulateBurglar(); raidLeft--; }
            raidLeft = 0;
        }

        void SimulateBurglar()
        {
            var e = EconomyManager.I;
            if (e == null) return;
            var loot = new Dictionary<ProductData, int>();
            int n = Random.Range(2, 5);
            for (int i = 0; i < n; i++)
            {
                var shelf = PickShelf();
                if (shelf == null) break;
                var product = shelf.TakeAnyUnit();
                if (product == null) continue;
                loot[product] = (loot.TryGetValue(product, out int c) ? c : 0) + 1;
            }
            e.RecordTheftAttempt();
            if (loot.Count > 0 && SecurityManager.I != null) SecurityManager.I.OnEscaped(loot);
            e.StealCash();
        }

        void Update()
        {
            var e = EconomyManager.I;
            if (e == null) return;
            if (e.phase == Phase.Open) DayThief();
            else if (e.phase == Phase.Night) NightRaid();
        }

        void NightRaid()
        {
            if (activeThief != null || raidLeft <= 0 || KioskDoor.IsLocked) return;
            raidTimer -= Time.deltaTime;
            if (raidTimer > 0f) return;
            var shelf = PickShelf();
            if (shelf == null) { raidLeft = 0; return; }
            raidLeft--;
            raidTimer = Random.Range(10f, 18f);
            activeThief = Thief.Create(transform, Random.value < 0.5f ? -1 : 1, shelf, true);
            AudioManager.Play(Sfx.Alarm, 0.6f);
        }

        void DayThief()
        {
            if (activeThief != null) return;
            timer -= Time.deltaTime;
            if (timer > 0f) return;
            var shelf = PickShelf();
            if (shelf == null) { timer = 20f; return; }
            activeThief = Thief.Create(transform, Random.value < 0.5f ? -1 : 1, shelf, false);

            // чем лучше охрана и камеры, тем реже воры лезут в киоск; с каждым днём — чуть чаще
            var sec = SecurityManager.I;
            float deter = sec != null ? UpgradeCatalog.CameraDeterrence[Mathf.Clamp(sec.CamLevel, 0, 3)] : 0f;
            if (sec != null && sec.GuardLevel >= 2) deter += 0.15f;
            float dayPressure = 1f + 0.04f * Mathf.Min(15, Mathf.Max(0, GameSession.Data.day - 1));
            timer = Random.Range(65f, 100f) / dayPressure / Mathf.Max(0.35f, 1f - deter);
        }
    }
}
