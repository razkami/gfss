using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Вор: подходит к окну выдачи снаружи, просовывает руку в киоск, хватает товар с полки и убегает по улице.
    /// Биту можно применить через окно: до кражи — отпугнуть, после — выбить товар.
    /// </summary>
    public class Thief : Interactable, IFleeing
    {
        enum Mode { Approach, Reach, Flee, Gone }
        const float RunSpeed = 2.7f, ReachOut = 0.85f, ReachBack = 0.35f, MaxArm = 2.6f;
        public static readonly Vector3 WindowSpot = new Vector3(0f, 0f, -0.8f);

        Mode mode;
        ShelfSlot targetShelf;
        PhysicalProduct inHand;                                   // товар, который сейчас тащит рука
        readonly System.Collections.Generic.Dictionary<ProductData, int> loot = new System.Collections.Generic.Dictionary<ProductData, int>();
        bool night, retracting, registered;
        int grabsLeft = 1;
        Transform armPivot, armMesh, handBall, hand;
        Vector3 aimPoint;
        readonly System.Collections.Generic.List<Vector3> path = new System.Collections.Generic.List<Vector3>();       // путь бегства
        readonly System.Collections.Generic.List<Vector3> approach = new System.Collections.Generic.List<Vector3>();   // путь к окну
        float reachTimer, speedMul = 1f;
        bool caught;

        public Vector3 Position => transform.position;
        public bool IsFleeing => !caught && mode == Mode.Flee && loot.Count > 0;
        /// <summary>Бита может остановить вора, пока он ещё у окна (даже если уже что-то схватил).</summary>
        public bool CanBeScared => !caught && (mode == Mode.Approach || mode == Mode.Reach);
        public void Catch(bool byGuard) { HitByBat(); }

        void OnDestroy() { if (SecurityManager.I != null) SecurityManager.I.Unregister(this); }

        public static Thief Create(Transform parent, int side, ShelfSlot shelf, bool night = false)
        {
            var go = new GameObject("Shoplifter");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(side * 9f, 0f, -6.6f);
            var thief = go.AddComponent<Thief>();
            thief.targetShelf = shelf;
            thief.night = night;
            thief.grabsLeft = night ? Random.Range(2, 4) : 1;        // ночной налётчик набивает рюкзак
            thief.aimPoint = AimFor(shelf);
            // приходит и убегает по тротуару (не через дорогу)
            thief.approach.Add(new Vector3(side * 1.8f, 0f, -3.5f));
            thief.path.Add(new Vector3(side * 1.4f, 0f, -2.2f));
            thief.path.Add(new Vector3(side * 3f, 0f, -6.6f));
            thief.path.Add(new Vector3(side * 18f, 0f, -6.6f));
            thief.mode = Mode.Approach;
            thief.BuildModel();
            var collider = go.AddComponent<CapsuleCollider>();
            collider.center = new Vector3(0f, 0.88f, 0f);
            collider.radius = 0.28f;
            collider.height = 1.76f;
            Toast.Warn(Loc.Get("t.thiefSeen"));
            if (SecurityManager.I != null && SecurityManager.I.CamLevel >= 1) Toast.Push(Loc.Get("t.camDoor"));
            return thief;
        }

        static Vector3 AimFor(ShelfSlot shelf) => shelf.transform.position + Vector3.up * 1.05f + shelf.transform.forward * 0.25f;

        void BuildModel()
        {
            var coat = Mats.Solid(new Color(0.13f, 0.16f, 0.23f), 0.22f);
            var mask = Mats.Solid(new Color(0.26f, 0.31f, 0.39f), 0.35f);
            Prim.Capsule(transform, "Dark hoodie", new Vector3(0f, 0.84f, 0f), 0.46f, 1.12f, coat);
            Prim.Sphere(transform, "Hood", new Vector3(0f, 1.55f, 0f), 0.38f, Mats.Solid(new Color(0.1f, 0.12f, 0.18f)));
            Prim.Cube(transform, "Face cover", new Vector3(0f, 1.48f, 0.155f), new Vector3(0.24f, 0.1f, 0.025f), mask, false);
            Prim.Cube(transform, "Jacket stripe", new Vector3(0f, 0.95f, 0.237f), new Vector3(0.32f, 0.055f, 0.012f), Mats.Solid(new Color(0.9f, 0.35f, 0.2f)), false);
            Prim.Cube(transform, "Backpack", new Vector3(0f, 1.02f, -0.25f), new Vector3(0.36f, 0.48f, 0.18f), Mats.Solid(new Color(0.12f, 0.32f, 0.24f)), false);

            // рука: плечо -> длинный рукав -> кисть; длина меняется при протягивании
            armPivot = new GameObject("Arm").transform;
            armPivot.SetParent(transform, false);
            armPivot.localPosition = new Vector3(0.27f, 1.28f, 0.12f);
            armMesh = Prim.Cube(armPivot, "Sleeve", Vector3.zero, new Vector3(0.1f, 0.1f, 0.1f), coat, false).transform;
            handBall = Prim.Sphere(armPivot, "Hand", Vector3.zero, 0.13f, Mats.Solid(new Color(0.85f, 0.68f, 0.56f), 0.3f)).transform;
            hand = new GameObject("Stolen goods hand").transform;
            hand.SetParent(armPivot, false);
            SetArm(0.55f, false);
        }

        /// <summary>Рука вперёд: len — длина; aim — смотреть на цель, иначе вниз-вперёд (спокойное положение).</summary>
        void SetArm(float len, bool aim)
        {
            if (aim)
            {
                Vector3 d = aimPoint - armPivot.position;
                if (d.sqrMagnitude > 0.0001f) armPivot.rotation = Quaternion.LookRotation(d.normalized);
            }
            else armPivot.localRotation = Quaternion.Euler(70f, 0f, 0f);
            armMesh.localPosition = new Vector3(0f, 0f, len * 0.5f);
            armMesh.localScale = new Vector3(0.1f, 0.1f, len);
            handBall.localPosition = new Vector3(0f, 0f, len);
            hand.localPosition = new Vector3(0f, 0f, len);
        }

        void Update()
        {
            if (mode == Mode.Gone) return;
            float dt = Time.deltaTime;
            if (mode == Mode.Approach) UpdateApproach(dt);
            else if (mode == Mode.Reach) UpdateReach(dt);
            else UpdateFlee(dt);
        }

        bool MoveTo(Vector3 target, float dt)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, RunSpeed * speedMul * dt);
            Vector3 look = target - transform.position;
            look.y = 0f;
            if (look.sqrMagnitude > 0.001f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(look), dt * 10f);
            return Vector3.Distance(transform.position, target) <= 0.08f;
        }

        void UpdateApproach(float dt)
        {
            if (approach.Count > 0) { if (MoveTo(approach[0], dt)) approach.RemoveAt(0); return; }
            if (!MoveTo(WindowSpot, dt)) return;
            if (SecurityManager.I != null && SecurityManager.I.GuardDeters())
            {
                Toast.Good(Loc.Get("t.guardDeter"));
                GiveUp();
                return;
            }
            transform.rotation = Quaternion.LookRotation(Vector3.forward);   // лицом к окну
            reachTimer = 0f;
            mode = Mode.Reach;
        }

        void UpdateReach(float dt)
        {
            reachTimer += dt;
            float dist = Mathf.Min(MaxArm, Vector3.Distance(armPivot.position, aimPoint));
            if (!retracting)
            {
                float t = Mathf.Clamp01(reachTimer / ReachOut);
                SetArm(Mathf.Lerp(0.55f, dist, t * t * (3f - 2f * t)), true);
                if (reachTimer < ReachOut) return;
                Grab();
                retracting = true;
                reachTimer = 0f;
                return;
            }
            float b = Mathf.Clamp01(reachTimer / ReachBack);
            SetArm(Mathf.Lerp(dist, 0.5f, b), b < 1f);
            if (b < 1f) return;

            Stash();
            // ночью вор тянется за следующим товаром, пока рюкзак не полон
            if (grabsLeft > 0)
            {
                var next = ThiefSpawner.PickShelf();
                if (next != null)
                {
                    targetShelf = next;
                    aimPoint = AimFor(next);
                    retracting = false;
                    reachTimer = 0f;
                    return;
                }
            }
            if (loot.Count > 0) mode = Mode.Flee; else GiveUp();
        }

        void Grab()
        {
            grabsLeft--;
            if (targetShelf != null) inHand = targetShelf.TakeRandomPhysicalProduct();
            if (inHand == null) { grabsLeft = 0; return; }
            inHand.transform.SetParent(hand, false);
            inHand.transform.localPosition = Vector3.zero;
            inHand.transform.localRotation = Quaternion.identity;
            inHand.Collider.enabled = false;
            inHand.Body.isKinematic = true;
            StockManager.I?.RemoveLoose(inHand);
            AudioManager.Play(Sfx.Pickup, 0.9f);
            Toast.Warn(Loc.F("t.thiefTook", inHand.product.displayName));
            if (!registered && SecurityManager.I != null) { registered = true; SecurityManager.I.RegisterFleeing(this); }
        }

        /// <summary>Товар из руки убирается в рюкзак.</summary>
        void Stash()
        {
            if (inHand == null) return;
            loot[inHand.product] = (loot.TryGetValue(inHand.product, out int c) ? c : 0) + 1;
            inHand.Consume();
            inHand = null;
        }

        void UpdateFlee(float dt)
        {
            if (loot.Count > 0) SetArm(0.5f, false);
            if (path.Count == 0) { Escape(); return; }
            if (MoveTo(path[0], dt)) path.RemoveAt(0);
        }

        void GiveUp()
        {
            caught = true;
            speedMul = 1.3f;
            SetArm(0.55f, false);
            mode = Mode.Flee;
        }

        public override float MaxDistance => 2.6f;
        public override string Prompt(PlayerContext p) => Loc.Get("p.thief.bat");
        public override void Interact(PlayerContext p) { PlayerController.I?.SwingBat(); }

        public void HitByBat()
        {
            if (mode == Mode.Gone || caught) return;
            caught = true;
            if (SecurityManager.I != null) SecurityManager.I.Unregister(this);
            bool had = loot.Count > 0 || inHand != null;
            float recovered = 0f;
            if (inHand != null)
            {
                // товар из руки выбит на пол у окна
                inHand.transform.SetParent(null, true);
                inHand.transform.position = transform.position + Vector3.up * 0.15f + transform.forward * 0.3f;
                inHand.Collider.enabled = true;
                inHand.Body.isKinematic = true;
                StockManager.I?.RegisterLoose(inHand);
                inHand.Drop();
                if (StockManager.I != null) recovered += StockManager.I.GetPrice(inHand.product);
                inHand = null;
            }
            if (loot.Count > 0 && StockManager.I != null)
            {
                // всё, что уже в рюкзаке, вываливается обратно на полки (остаток — на пол)
                foreach (var kv in loot)
                {
                    recovered += StockManager.I.GetPrice(kv.Key) * kv.Value;
                    StockManager.I.ReturnGoods(kv.Key, kv.Value);
                }
                loot.Clear();
            }
            if (had && EconomyManager.I != null) EconomyManager.I.RecordRecovered(recovered);
            Toast.Good(Loc.Get(had ? "t.thiefRecovered" : "t.thiefScared"));
            AudioManager.Play(Sfx.BatHit);
            EconomyManager.I?.AddRep(1f);
            SetArm(0.55f, false);
            speedMul = 1.3f;
            mode = Mode.Flee;
        }

        /// <summary>Игрок лёг спать: вор, ещё стоящий у окна, просто уходит с тем, что успел схватить.</summary>
        public void ForceFinish()
        {
            if (mode == Mode.Gone) return;
            Stash();
            Escape();
        }

        void Escape()
        {
            mode = Mode.Gone;
            if (SecurityManager.I != null)
            {
                SecurityManager.I.Unregister(this);
                if (loot.Count > 0 && !caught) SecurityManager.I.OnEscaped(new System.Collections.Generic.Dictionary<ProductData, int>(loot));
            }
            if (night && loot.Count > 0 && !caught && EconomyManager.I != null) EconomyManager.I.StealCash();
            loot.Clear();
            Destroy(gameObject);
        }
    }
}
