using UnityEngine;

namespace KioskTycoon
{
    public enum CustomerPose { Idle, Walk, Run, Choose, Impatient, Angry, Pay, Happy, Shifty, Wave }

    /// <summary>Случайный набор внешности: тело, одежда, причёска, головной убор, аксессуары.</summary>
    public class CustomerLook
    {
        public Color skin, hair, top, bottom, shoes, accent;
        public int hairStyle, outfit, hat, glasses, bag, neckwear, pattern;
        public bool beard, female, hoodUp;
        public float height = 1f;
    }

    /// <summary>
    /// Фабрика покупателей: бросает кубик на внешность (разные модели, комплекты одежды, причёски, цвета, аксессуары)
    /// и собирает гуманоида из примитивов. Палитры конечны, поэтому материалы кэшируются и не раздуваются.
    /// </summary>
    public static class CustomerFactory
    {
        public const int OutfitCount = 6, HairCount = 9, HatCount = 5;
        public const int OutfitGuard = 6;

        static readonly Color[] Skins =
        {
            new Color(0.99f, 0.86f, 0.73f), new Color(0.96f, 0.78f, 0.62f), new Color(0.88f, 0.67f, 0.50f),
            new Color(0.76f, 0.55f, 0.38f), new Color(0.62f, 0.42f, 0.28f), new Color(0.47f, 0.31f, 0.20f),
            new Color(0.36f, 0.23f, 0.15f), new Color(0.93f, 0.72f, 0.58f)
        };
        static readonly Color[] Hairs =
        {
            new Color(0.07f, 0.06f, 0.06f), new Color(0.22f, 0.14f, 0.09f), new Color(0.40f, 0.26f, 0.14f),
            new Color(0.55f, 0.22f, 0.12f), new Color(0.86f, 0.70f, 0.36f), new Color(0.93f, 0.90f, 0.80f),
            new Color(0.80f, 0.36f, 0.12f), new Color(0.62f, 0.62f, 0.64f),
            new Color(0.25f, 0.45f, 0.95f), new Color(0.95f, 0.35f, 0.65f), new Color(0.30f, 0.80f, 0.45f)
        };
        static readonly Color[] ClothColors =
        {
            new Color(0.90f, 0.25f, 0.22f), new Color(0.95f, 0.55f, 0.15f), new Color(0.97f, 0.80f, 0.20f),
            new Color(0.35f, 0.75f, 0.35f), new Color(0.15f, 0.65f, 0.60f), new Color(0.22f, 0.52f, 0.90f),
            new Color(0.40f, 0.32f, 0.85f), new Color(0.80f, 0.35f, 0.75f), new Color(0.95f, 0.50f, 0.60f),
            new Color(0.92f, 0.92f, 0.88f), new Color(0.30f, 0.32f, 0.38f), new Color(0.55f, 0.36f, 0.22f),
            new Color(0.12f, 0.12f, 0.16f), new Color(0.50f, 0.70f, 0.95f)
        };
        static readonly Color[] Pants =
        {
            new Color(0.18f, 0.28f, 0.50f), new Color(0.12f, 0.12f, 0.15f), new Color(0.42f, 0.38f, 0.30f),
            new Color(0.30f, 0.30f, 0.34f), new Color(0.25f, 0.40f, 0.28f), new Color(0.55f, 0.30f, 0.22f),
            new Color(0.70f, 0.66f, 0.55f), new Color(0.22f, 0.20f, 0.38f)
        };
        static readonly Color[] Shoes =
        {
            new Color(0.10f, 0.10f, 0.12f), new Color(0.92f, 0.92f, 0.90f), new Color(0.50f, 0.28f, 0.14f),
            new Color(0.85f, 0.20f, 0.18f), new Color(0.20f, 0.35f, 0.75f)
        };

        static T Pick<T>(T[] a) => a[Random.Range(0, a.Length)];

        /// <summary>Подбор внешности с учётом профиля (рабочий — жилет и каска, турист — яркая рубашка и т.п.).</summary>
        public static CustomerLook Roll(CustomerProfile prof, bool young, bool shoplifter)
        {
            var l = new CustomerLook();
            string id = prof != null ? prof.id : "";
            l.female = Random.value < 0.5f;
            l.skin = Pick(Skins);
            l.hair = Pick(Hairs);
            if (Random.value < 0.7f) l.hair = Hairs[Random.Range(0, 8)];            // «дикие» цвета реже
            l.accent = Pick(ClothColors);
            l.top = Random.value < 0.35f && prof != null ? prof.bodyColor : Pick(ClothColors);
            l.bottom = Pick(Pants);
            l.shoes = Pick(Shoes);
            l.height = young ? Random.Range(0.8f, 0.86f) : Random.Range(0.94f, 1.06f);
            l.pattern = Random.value < 0.3f ? Random.Range(1, 4) : 0;

            switch (id)
            {
                case "worker": l.outfit = Random.value < 0.6f ? 5 : 2; l.hat = Random.value < 0.5f ? 4 : 0; l.pattern = 0; break;
                case "student": l.outfit = Random.value < 0.6f ? 1 : 0; l.hat = Random.value < 0.3f ? Random.Range(1, 3) : 0; break;
                case "tourist": l.outfit = Random.value < 0.6f ? 0 : 3; l.hat = Random.value < 0.5f ? 3 : 0; l.pattern = Random.value < 0.6f ? 3 : l.pattern; break;
                case "regular": l.outfit = Random.value < 0.4f ? 4 : 2; l.hat = Random.value < 0.25f ? 1 : 0; break;
                default: l.outfit = Random.Range(0, OutfitCount); l.hat = Random.value < 0.3f ? Random.Range(1, HatCount) : 0; break;
            }
            if (l.female && Random.value < 0.35f && id != "worker") l.outfit = 3;
            if (l.outfit == 3) l.female = true;

            l.hairStyle = l.female ? Pick(new[] { 1, 3, 4, 4, 5, 5, 7, 8, 1 }) : Pick(new[] { 0, 1, 1, 2, 2, 6, 7, 1 });
            if (l.hat == 2 || l.hat == 4) l.hairStyle = l.hairStyle == 0 ? 1 : l.hairStyle;
            l.beard = !l.female && !young && Random.value < 0.22f;
            l.glasses = Random.value < 0.22f ? (Random.value < 0.5f ? 1 : 2) : 0;       // 1 — очки, 2 — солнцезащитные
            l.bag = Random.value < 0.42f ? Random.Range(1, 3) : 0;                        // 1 — рюкзак, 2 — сумка
            l.neckwear = Random.value < 0.3f ? Random.Range(1, 4) : 0;                    // 1 — шарф, 2 — наушники, 3 — галстук
            if (l.outfit == 4) l.neckwear = 3;
            l.hoodUp = l.outfit == 1 && Random.value < 0.4f;

            if (shoplifter && Random.value < 0.5f)
            {
                // у «воров» часто тёмная одежда, но не всегда: полагаться только на вид нельзя
                l.top = new Color(0.12f, 0.14f, 0.2f);
                l.outfit = 1; l.hoodUp = true;
                if (Random.value < 0.5f) l.glasses = 2;
            }
            return l;
        }

        // ---------- вспомогательные примитивы ----------
        static GameObject Sph(Transform p, string n, Vector3 pos, Vector3 size, Material m) =>
            Prim.Shape(PrimitiveType.Sphere, p, n, pos, size, m);
        static GameObject Cap(Transform p, string n, Vector3 pos, float w, float h, float d, Material m) =>
            Prim.Shape(PrimitiveType.Capsule, p, n, pos, new Vector3(w, h * 0.5f, d), m);
        static GameObject Cyl(Transform p, string n, Vector3 pos, float w, float h, float d, Material m) =>
            Prim.Shape(PrimitiveType.Cylinder, p, n, pos, new Vector3(w, h * 0.5f, d), m);
        static GameObject Box(Transform p, string n, Vector3 pos, Vector3 size, Material m) =>
            Prim.Cube(p, n, pos, size, m, false);
        static Transform Pivot(Transform parent, string name, Vector3 pos)
        {
            var t = new GameObject(name).transform;
            t.SetParent(parent, false);
            t.localPosition = pos;
            return t;
        }

        static Material Cloth(Color c, int pattern, Color accent) =>
            pattern == 0 ? Mats.Solid(c, 0.15f) : Mats.Fabric(c, accent, pattern);

        // ---------- сборка ----------
        public static CustomerRig Build(Transform root, CustomerLook look, bool young)
        {
            var model = Pivot(root, "Model", Vector3.zero);
            float h = look.height;
            float w = look.female ? 0.95f : 1f;
            model.localScale = new Vector3(h * w, h, h * w);

            var skin = Mats.Solid(look.skin, 0.28f);
            var hairM = Mats.Solid(look.hair, 0.35f);
            var topM = Cloth(look.top, look.pattern, look.accent);
            var plainTop = Mats.Solid(look.top, 0.15f);
            var bottomM = Mats.Solid(look.bottom, 0.12f);
            var shoeM = Mats.Solid(look.shoes, 0.3f);
            var accentM = Mats.Solid(look.accent, 0.2f);
            var dark = Mats.Solid(new Color(0.05f, 0.05f, 0.07f), 0.4f);

            bool longSleeves = look.outfit == 1 || look.outfit == 2 || look.outfit == 4 || look.outfit == 5 || look.outfit == OutfitGuard;
            bool skirt = look.outfit == 3;

            // ----- ноги -----
            var hipL = Pivot(model, "HipL", new Vector3(-0.1f, 0.92f, 0f));
            var hipR = Pivot(model, "HipR", new Vector3(0.1f, 0.92f, 0f));
            foreach (var hip in new[] { hipL, hipR })
            {
                Cap(hip, "Leg", new Vector3(0f, -0.44f, 0f), 0.17f, 0.88f, 0.17f, skirt ? skin : bottomM);
                Box(hip, "Shoe", new Vector3(0f, -0.9f, 0.045f), new Vector3(0.17f, 0.1f, 0.29f), shoeM);
                Box(hip, "Sole", new Vector3(0f, -0.955f, 0.045f), new Vector3(0.175f, 0.02f, 0.3f), Mats.Solid(new Color(0.9f, 0.9f, 0.88f), 0.2f));
            }

            // ----- торс -----
            var torso = Pivot(model, "Torso", new Vector3(0f, 0.92f, 0f));
            float tw = look.outfit == 1 ? 0.44f : 0.39f;
            Cap(torso, "Chest", new Vector3(0f, 0.3f, 0f), tw, 0.64f, tw * 0.72f, topM);
            Cap(torso, "Hips", new Vector3(0f, 0.02f, 0f), 0.36f, 0.26f, 0.27f, skirt ? topM : bottomM);

            switch (look.outfit)
            {
                case 1: // худи
                    Box(torso, "Pocket", new Vector3(0f, 0.12f, 0.155f), new Vector3(0.24f, 0.1f, 0.03f), Mats.Solid(look.top * 0.8f, 0.1f));
                    Sph(torso, "Hood bunch", new Vector3(0f, 0.58f, -0.1f), new Vector3(0.28f, 0.16f, 0.2f), plainTop);
                    break;
                case 2: // куртка
                    Box(torso, "Zipper", new Vector3(0f, 0.3f, 0.141f), new Vector3(0.03f, 0.6f, 0.012f), Mats.Solid(new Color(0.85f, 0.85f, 0.85f), 0.5f, 0.4f));
                    Box(torso, "Collar", new Vector3(0f, 0.56f, 0.08f), new Vector3(0.26f, 0.06f, 0.16f), Mats.Solid(look.top * 0.8f, 0.1f));
                    break;
                case 3: // платье
                    Cyl(torso, "Skirt", new Vector3(0f, -0.14f, 0f), 0.52f, 0.42f, 0.4f, topM);
                    break;
                case 4: // костюм
                    Box(torso, "Lapel L", new Vector3(-0.07f, 0.4f, 0.142f), new Vector3(0.07f, 0.3f, 0.012f), Mats.Solid(look.top * 0.7f, 0.2f));
                    Box(torso, "Lapel R", new Vector3(0.07f, 0.4f, 0.142f), new Vector3(0.07f, 0.3f, 0.012f), Mats.Solid(look.top * 0.7f, 0.2f));
                    Box(torso, "Shirt", new Vector3(0f, 0.42f, 0.14f), new Vector3(0.07f, 0.26f, 0.012f), Mats.Solid(Color.white, 0.2f));
                    break;
                case 5: // жилет
                {
                    var vest = Mats.Solid(new Color(1f, 0.55f, 0.08f), 0.2f);
                    Cap(torso, "Vest", new Vector3(0f, 0.3f, 0f), tw + 0.03f, 0.5f, tw * 0.72f + 0.03f, vest);
                    Cyl(torso, "Reflector A", new Vector3(0f, 0.2f, 0f), tw + 0.04f, 0.05f, tw * 0.72f + 0.04f, Mats.Emissive(new Color(0.85f, 0.9f, 0.9f), 0.3f));
                    Cyl(torso, "Reflector B", new Vector3(0f, 0.42f, 0f), tw + 0.04f, 0.05f, tw * 0.72f + 0.04f, Mats.Emissive(new Color(0.85f, 0.9f, 0.9f), 0.3f));
                    break;
                }
                case OutfitGuard:
                    Box(torso, "Zipper", new Vector3(0f, 0.3f, 0.141f), new Vector3(0.03f, 0.6f, 0.012f), Mats.Solid(new Color(0.8f, 0.8f, 0.8f), 0.5f));
                    Box(torso, "Badge", new Vector3(0.1f, 0.42f, 0.145f), new Vector3(0.06f, 0.07f, 0.012f), Mats.Emissive(new Color(1f, 0.82f, 0.2f), 0.6f));
                    Box(torso, "Reflective stripe", new Vector3(0f, 0.18f, 0f), new Vector3(0.42f, 0.04f, 0.3f), Mats.Emissive(new Color(0.8f, 0.9f, 1f), 0.4f));
                    Box(torso, "Radio", new Vector3(-0.17f, 0.5f, 0.1f), new Vector3(0.05f, 0.1f, 0.04f), dark);
                    break;
            }

            // ----- руки -----
            Transform shoulderL = null, shoulderR = null, elbowL = null, elbowR = null, hand = null;
            for (int side = -1; side <= 1; side += 2)
            {
                var sh = Pivot(torso, side < 0 ? "ShoulderL" : "ShoulderR", new Vector3(side * 0.245f, 0.52f, 0f));
                Sph(sh, "Shoulder", Vector3.zero, new Vector3(0.12f, 0.12f, 0.12f), longSleeves ? plainTop : topM);
                Cap(sh, "Upper arm", new Vector3(0f, -0.16f, 0f), 0.105f, 0.34f, 0.105f, longSleeves ? plainTop : topM);
                var el = Pivot(sh, "Elbow", new Vector3(0f, -0.31f, 0f));
                Cap(el, "Forearm", new Vector3(0f, -0.15f, 0f), 0.09f, 0.32f, 0.09f, longSleeves ? plainTop : skin);
                var hd = Sph(el, "Hand", new Vector3(0f, -0.32f, 0f), new Vector3(0.09f, 0.1f, 0.09f), skin);
                if (side < 0)
                {
                    shoulderL = sh; elbowL = el;
                    if (look.glasses == 0 && look.bag != 2) Box(el, "Watch", new Vector3(0f, -0.25f, 0f), new Vector3(0.1f, 0.035f, 0.1f), accentM);
                }
                else { shoulderR = sh; elbowR = el; hand = hd.transform; }
            }

            // ----- голова -----
            var head = Pivot(torso, "Head", new Vector3(0f, 0.6f, 0f));
            Cyl(head, "Neck", new Vector3(0f, 0.01f, 0f), 0.1f, 0.1f, 0.1f, skin);
            Sph(head, "Skull", new Vector3(0f, 0.15f, 0f), new Vector3(0.29f, 0.31f, 0.29f), skin);
            Sph(head, "Ear L", new Vector3(-0.145f, 0.14f, 0f), new Vector3(0.05f, 0.07f, 0.04f), skin);
            Sph(head, "Ear R", new Vector3(0.145f, 0.14f, 0f), new Vector3(0.05f, 0.07f, 0.04f), skin);
            Sph(head, "Nose", new Vector3(0f, 0.125f, 0.145f), new Vector3(0.04f, 0.045f, 0.04f), Mats.Solid(look.skin * 0.93f, 0.2f));
            Sph(head, "Eye L", new Vector3(-0.055f, 0.165f, 0.125f), new Vector3(0.042f, 0.05f, 0.03f), Mats.Solid(Color.white, 0.5f));
            Sph(head, "Eye R", new Vector3(0.055f, 0.165f, 0.125f), new Vector3(0.042f, 0.05f, 0.03f), Mats.Solid(Color.white, 0.5f));
            Sph(head, "Pupil L", new Vector3(-0.055f, 0.165f, 0.142f), new Vector3(0.022f, 0.026f, 0.014f), dark);
            Sph(head, "Pupil R", new Vector3(0.055f, 0.165f, 0.142f), new Vector3(0.022f, 0.026f, 0.014f), dark);
            Box(head, "Brow L", new Vector3(-0.055f, 0.205f, 0.135f), new Vector3(0.06f, 0.012f, 0.012f), hairM);
            Box(head, "Brow R", new Vector3(0.055f, 0.205f, 0.135f), new Vector3(0.06f, 0.012f, 0.012f), hairM);
            Box(head, "Mouth", new Vector3(0f, 0.07f, 0.14f), new Vector3(0.06f, 0.012f, 0.012f), Mats.Solid(new Color(0.6f, 0.2f, 0.2f), 0.3f));
            if (look.female) Box(head, "Lashes", new Vector3(0f, 0.19f, 0.14f), new Vector3(0.16f, 0.008f, 0.008f), dark);

            BuildHair(head, look, hairM, plainTop);
            BuildHat(head, look, plainTop, accentM);

            if (look.glasses > 0)
            {
                var gm = look.glasses == 2 ? Mats.Solid(new Color(0.03f, 0.03f, 0.05f), 0.8f) : Mats.Glass(new Color(0.6f, 0.8f, 0.95f, 0.45f));
                Box(head, "Lens L", new Vector3(-0.058f, 0.165f, 0.147f), new Vector3(0.08f, 0.056f, 0.01f), gm);
                Box(head, "Lens R", new Vector3(0.058f, 0.165f, 0.147f), new Vector3(0.08f, 0.056f, 0.01f), gm);
                Box(head, "Bridge", new Vector3(0f, 0.17f, 0.148f), new Vector3(0.03f, 0.01f, 0.01f), dark);
                Box(head, "Temple L", new Vector3(-0.14f, 0.17f, 0.07f), new Vector3(0.01f, 0.01f, 0.15f), dark);
                Box(head, "Temple R", new Vector3(0.14f, 0.17f, 0.07f), new Vector3(0.01f, 0.01f, 0.15f), dark);
            }
            if (look.beard) Box(head, "Beard", new Vector3(0f, 0.045f, 0.1f), new Vector3(0.2f, 0.09f, 0.1f), hairM);

            // ----- аксессуары -----
            switch (look.neckwear)
            {
                case 1: Cyl(head, "Scarf", new Vector3(0f, 0.005f, 0f), 0.2f, 0.09f, 0.2f, accentM); break;
                case 2:
                    Box(head, "Headphone band", new Vector3(0f, 0.32f, 0f), new Vector3(0.3f, 0.02f, 0.04f), dark);
                    Box(head, "Cup L", new Vector3(-0.16f, 0.15f, 0f), new Vector3(0.05f, 0.1f, 0.1f), accentM);
                    Box(head, "Cup R", new Vector3(0.16f, 0.15f, 0f), new Vector3(0.05f, 0.1f, 0.1f), accentM);
                    break;
                case 3:
                    Box(torso, "Tie", new Vector3(0f, 0.38f, 0.145f), new Vector3(0.05f, 0.3f, 0.014f), accentM);
                    Box(torso, "Tie knot", new Vector3(0f, 0.53f, 0.145f), new Vector3(0.06f, 0.05f, 0.02f), accentM);
                    break;
            }
            if (look.bag == 1)
            {
                Box(torso, "Backpack", new Vector3(0f, 0.3f, -0.24f), new Vector3(0.32f, 0.42f, 0.15f), accentM);
                Box(torso, "Backpack pocket", new Vector3(0f, 0.2f, -0.33f), new Vector3(0.24f, 0.16f, 0.04f), Mats.Solid(look.accent * 0.75f, 0.2f));
                Box(torso, "Strap L", new Vector3(-0.12f, 0.32f, 0.12f), new Vector3(0.04f, 0.44f, 0.02f), dark);
                Box(torso, "Strap R", new Vector3(0.12f, 0.32f, 0.12f), new Vector3(0.04f, 0.44f, 0.02f), dark);
            }
            else if (look.bag == 2)
            {
                Box(torso, "Shoulder bag", new Vector3(0.27f, 0.02f, 0.06f), new Vector3(0.09f, 0.2f, 0.26f), accentM);
                var strap = Box(torso, "Bag strap", new Vector3(0f, 0.3f, 0.12f), new Vector3(0.03f, 0.75f, 0.02f), dark);
                strap.transform.localRotation = Quaternion.Euler(0f, 0f, -24f);
            }

            var rig = root.gameObject.AddComponent<CustomerRig>();
            rig.model = model; rig.torso = torso; rig.head = head;
            rig.shoulderL = shoulderL; rig.shoulderR = shoulderR; rig.elbowL = elbowL; rig.elbowR = elbowR;
            rig.hipL = hipL; rig.hipR = hipR; rig.hand = hand;
            rig.seed = Random.value * 20f;
            return rig;
        }

        static void BuildHair(Transform head, CustomerLook look, Material hairM, Material hoodM)
        {
            if (look.hoodUp)
            {
                Sph(head, "Hood", new Vector3(0f, 0.15f, -0.03f), new Vector3(0.37f, 0.38f, 0.38f), hoodM);
                Box(head, "Hood trim", new Vector3(0f, 0.24f, 0.13f), new Vector3(0.27f, 0.05f, 0.05f), hoodM);
                return;
            }
            switch (look.hairStyle)
            {
                case 0: break; // лысый
                case 1:
                    Sph(head, "Hair", new Vector3(0f, 0.19f, -0.012f), new Vector3(0.31f, 0.27f, 0.32f), hairM);
                    Box(head, "Fringe", new Vector3(0f, 0.265f, 0.1f), new Vector3(0.25f, 0.045f, 0.07f), hairM);
                    break;
                case 2:
                    Sph(head, "Buzz", new Vector3(0f, 0.18f, 0f), new Vector3(0.3f, 0.24f, 0.3f), hairM);
                    break;
                case 3:
                    Sph(head, "Hair", new Vector3(0f, 0.19f, -0.012f), new Vector3(0.32f, 0.27f, 0.33f), hairM);
                    Box(head, "Side L", new Vector3(-0.15f, 0.08f, 0f), new Vector3(0.05f, 0.22f, 0.26f), hairM);
                    Box(head, "Side R", new Vector3(0.15f, 0.08f, 0f), new Vector3(0.05f, 0.22f, 0.26f), hairM);
                    Box(head, "Back", new Vector3(0f, 0.08f, -0.14f), new Vector3(0.3f, 0.22f, 0.06f), hairM);
                    Box(head, "Fringe", new Vector3(0f, 0.27f, 0.1f), new Vector3(0.27f, 0.05f, 0.07f), hairM);
                    break;
                case 4:
                    Sph(head, "Hair", new Vector3(0f, 0.19f, -0.012f), new Vector3(0.32f, 0.27f, 0.33f), hairM);
                    Box(head, "Side L", new Vector3(-0.15f, 0.0f, 0f), new Vector3(0.05f, 0.36f, 0.26f), hairM);
                    Box(head, "Side R", new Vector3(0.15f, 0.0f, 0f), new Vector3(0.05f, 0.36f, 0.26f), hairM);
                    Box(head, "Back", new Vector3(0f, -0.02f, -0.14f), new Vector3(0.31f, 0.4f, 0.07f), hairM);
                    Box(head, "Fringe", new Vector3(0f, 0.27f, 0.1f), new Vector3(0.27f, 0.05f, 0.07f), hairM);
                    break;
                case 5:
                    Sph(head, "Hair", new Vector3(0f, 0.19f, -0.012f), new Vector3(0.31f, 0.27f, 0.32f), hairM);
                    Sph(head, "Tail base", new Vector3(0f, 0.13f, -0.17f), new Vector3(0.1f, 0.1f, 0.1f), hairM);
                    Cyl(head, "Ponytail", new Vector3(0f, 0.0f, -0.2f), 0.07f, 0.26f, 0.07f, hairM);
                    break;
                case 6:
                    Sph(head, "Sides", new Vector3(0f, 0.17f, 0f), new Vector3(0.3f, 0.22f, 0.3f), hairM);
                    Box(head, "Mohawk", new Vector3(0f, 0.31f, -0.01f), new Vector3(0.05f, 0.09f, 0.26f), Mats.Solid(look.accent, 0.3f));
                    break;
                case 7:
                    Sph(head, "Afro", new Vector3(0f, 0.2f, -0.02f), new Vector3(0.42f, 0.4f, 0.42f), hairM);
                    break;
                default:
                    Sph(head, "Hair", new Vector3(0f, 0.19f, -0.012f), new Vector3(0.31f, 0.27f, 0.32f), hairM);
                    Sph(head, "Bun", new Vector3(0f, 0.35f, -0.05f), new Vector3(0.12f, 0.12f, 0.12f), hairM);
                    break;
            }
        }

        static void BuildHat(Transform head, CustomerLook look, Material topM, Material accentM)
        {
            switch (look.hat)
            {
                case 1: // бейсболка
                    Sph(head, "Cap crown", new Vector3(0f, 0.215f, 0f), new Vector3(0.325f, 0.21f, 0.33f), accentM);
                    Box(head, "Cap brim", new Vector3(0f, 0.19f, 0.17f), new Vector3(0.26f, 0.02f, 0.16f), accentM);
                    break;
                case 2: // шапка
                    Sph(head, "Beanie", new Vector3(0f, 0.22f, 0f), new Vector3(0.325f, 0.25f, 0.33f), accentM);
                    Sph(head, "Pompom", new Vector3(0f, 0.36f, 0f), new Vector3(0.08f, 0.08f, 0.08f), Mats.Solid(Color.white, 0.3f));
                    break;
                case 3: // панама
                    Cyl(head, "Bucket", new Vector3(0f, 0.25f, 0f), 0.3f, 0.14f, 0.3f, Mats.Solid(new Color(0.9f, 0.85f, 0.65f), 0.1f));
                    Cyl(head, "Brim", new Vector3(0f, 0.19f, 0f), 0.5f, 0.02f, 0.5f, Mats.Solid(new Color(0.9f, 0.85f, 0.65f), 0.1f));
                    break;
                case 4: // каска
                    Sph(head, "Hardhat", new Vector3(0f, 0.215f, 0f), new Vector3(0.335f, 0.22f, 0.34f), Mats.Solid(new Color(1f, 0.85f, 0.1f), 0.5f));
                    Box(head, "Hardhat ridge", new Vector3(0f, 0.33f, 0f), new Vector3(0.05f, 0.03f, 0.3f), Mats.Solid(new Color(1f, 0.85f, 0.1f), 0.5f));
                    Box(head, "Hardhat brim", new Vector3(0f, 0.19f, 0.15f), new Vector3(0.28f, 0.015f, 0.1f), Mats.Solid(new Color(1f, 0.85f, 0.1f), 0.5f));
                    break;
            }
            if (look.outfit == OutfitGuard)
            {
                var navy = Mats.Solid(new Color(0.08f, 0.11f, 0.2f), 0.3f);
                Sph(head, "Guard cap", new Vector3(0f, 0.215f, 0f), new Vector3(0.325f, 0.2f, 0.33f), navy);
                Box(head, "Guard brim", new Vector3(0f, 0.19f, 0.17f), new Vector3(0.26f, 0.02f, 0.15f), Mats.Solid(new Color(0.03f, 0.04f, 0.08f), 0.6f));
                Box(head, "Cap badge", new Vector3(0f, 0.25f, 0.16f), new Vector3(0.06f, 0.05f, 0.012f), Mats.Emissive(new Color(1f, 0.82f, 0.2f), 0.6f));
            }
        }

        /// <summary>Охранник: тёмно-синяя форма, фуражка, значок, светоотражающая полоса.</summary>
        public static CustomerRig BuildGuard(Transform root)
        {
            var l = new CustomerLook
            {
                skin = Pick(Skins), hair = Hairs[Random.Range(0, 4)], top = new Color(0.1f, 0.14f, 0.26f),
                bottom = new Color(0.07f, 0.09f, 0.16f), shoes = new Color(0.05f, 0.05f, 0.06f),
                accent = new Color(1f, 0.82f, 0.2f), hairStyle = 2, outfit = OutfitGuard, height = 1.07f
            };
            return Build(root, l, false);
        }
    }

    /// <summary>Процедурная анимация: ходьба, бег, ожидание, выбор товара, нетерпение, оплата, уход.</summary>
    public class CustomerRig : MonoBehaviour
    {
        public Transform model, torso, head, shoulderL, shoulderR, elbowL, elbowR, hipL, hipR, hand;
        public float seed;

        float phase;
        Vector3 cTorso, cHead, cShL, cShR, cElL, cElR, cHipL, cHipR;
        float cBob;

        public void Tick(float dt, CustomerPose pose, float speed)
        {
            if (model == null) return;
            float t = Time.time + seed;
            bool run = pose == CustomerPose.Run;
            float walk = Mathf.Clamp01(speed / (run ? 3.2f : 1.3f));
            phase += dt * Mathf.Lerp(0f, run ? 13f : 6.8f, walk);
            float swing = Mathf.Sin(phase) * (run ? 58f : 30f) * walk;
            float bob = Mathf.Abs(Mathf.Sin(phase)) * (run ? 0.05f : 0.022f) * walk;

            Vector3 tTorso = new Vector3(run ? 14f * walk : 0f, Mathf.Sin(phase) * 5f * walk, 0f);
            Vector3 tHead = new Vector3(0f, Mathf.Sin(t * 0.6f) * 16f * (1f - walk), 0f);
            Vector3 tShL = new Vector3(-swing * 0.9f, 0f, 4f);
            Vector3 tShR = new Vector3(swing * 0.9f, 0f, -4f);
            Vector3 tElL = new Vector3(run ? -85f : -12f - Mathf.Max(0f, swing) * 0.3f, 0f, 0f);
            Vector3 tElR = new Vector3(run ? -85f : -12f - Mathf.Max(0f, -swing) * 0.3f, 0f, 0f);
            Vector3 tHipL = new Vector3(swing, 0f, 0f);
            Vector3 tHipR = new Vector3(-swing, 0f, 0f);
            float hop = 0f;
            float idleBreath = Mathf.Sin(t * 2.1f) * 1.2f;
            tHead.x += idleBreath;

            switch (pose)
            {
                case CustomerPose.Idle:
                    if (walk < 0.3f)
                    {
                        // иногда смотрит на часы
                        if (Mathf.Repeat(t * 0.09f, 1f) < 0.14f) { tShL = new Vector3(-55f, 0f, 8f); tElL = new Vector3(-105f, 0f, 0f); tHead = new Vector3(14f, -8f, 0f); }
                        tTorso.z = Mathf.Sin(t * 0.5f) * 1.5f;
                    }
                    break;
                case CustomerPose.Choose:
                    tShR = new Vector3(-100f, 0f, -12f); tElR = new Vector3(-135f, 0f, 0f);
                    tHead = new Vector3(10f, Mathf.Sin(t * 1.1f) * 38f, Mathf.Sin(t * 0.7f) * 5f);
                    tTorso.x = 4f;
                    break;
                case CustomerPose.Impatient:
                    tShL = new Vector3(-40f, 0f, -26f); tShR = new Vector3(-40f, 0f, 26f);
                    tElL = new Vector3(-105f, 0f, 0f); tElR = new Vector3(-105f, 0f, 0f);
                    tHipR.x = -Mathf.Abs(Mathf.Sin(t * 7f)) * 16f;
                    tHead = new Vector3(2f, Mathf.Sin(t * 0.9f) * 12f, Mathf.Sin(t * 1.3f) * 5f);
                    break;
                case CustomerPose.Angry:
                    tShL = new Vector3(-6f, 0f, 14f); tShR = new Vector3(-6f, 0f, -14f);
                    tElL = new Vector3(-50f, 0f, 0f); tElR = new Vector3(-50f, 0f, 0f);
                    tTorso = new Vector3(9f, Mathf.Sin(t * 12f) * 3f, 0f);
                    tHead = new Vector3(4f, Mathf.Sin(t * 9f) * 9f, 0f);
                    tHipL.x = -Mathf.Abs(Mathf.Sin(t * 5f)) * 22f;
                    hop = Mathf.Abs(Mathf.Sin(t * 5f)) * 0.015f;
                    break;
                case CustomerPose.Pay:
                    tShR = new Vector3(-78f, 0f, -6f + Mathf.Sin(t * 3f) * 4f); tElR = new Vector3(-22f, 0f, 0f);
                    tHead = new Vector3(-3f, 0f, 0f);
                    break;
                case CustomerPose.Happy:
                case CustomerPose.Wave:
                    tShR = new Vector3(-165f, 0f, -12f); tElR = new Vector3(-28f + Mathf.Sin(t * 10f) * 28f, 0f, 0f);
                    tHead = new Vector3(-4f, 8f * Mathf.Sin(t * 1.5f), 4f);
                    hop = walk > 0.2f ? Mathf.Abs(Mathf.Sin(phase * 0.5f)) * 0.03f : 0f;
                    break;
                case CustomerPose.Shifty:
                    tHead = new Vector3(12f, Mathf.Sin(t * 5.5f) * 58f, 0f);
                    tTorso = new Vector3(12f, Mathf.Sin(t * 2f) * 6f, 0f);
                    tShL = new Vector3(-12f, 0f, 14f); tShR = new Vector3(-12f, 0f, -14f);
                    tElL = new Vector3(-42f, 0f, 0f); tElR = new Vector3(-42f, 0f, 0f);
                    break;
                case CustomerPose.Run:
                    break;
            }

            float k = 1f - Mathf.Exp(-12f * dt);
            cTorso = Vector3.Lerp(cTorso, tTorso, k); cHead = Vector3.Lerp(cHead, tHead, k);
            cShL = Vector3.Lerp(cShL, tShL, k); cShR = Vector3.Lerp(cShR, tShR, k);
            cElL = Vector3.Lerp(cElL, tElL, k); cElR = Vector3.Lerp(cElR, tElR, k);
            cHipL = Vector3.Lerp(cHipL, tHipL, k); cHipR = Vector3.Lerp(cHipR, tHipR, k);
            cBob = Mathf.Lerp(cBob, bob + hop, k);

            model.localPosition = new Vector3(0f, cBob, 0f);
            torso.localRotation = Quaternion.Euler(cTorso);
            head.localRotation = Quaternion.Euler(cHead);
            shoulderL.localRotation = Quaternion.Euler(cShL); shoulderR.localRotation = Quaternion.Euler(cShR);
            elbowL.localRotation = Quaternion.Euler(cElL); elbowR.localRotation = Quaternion.Euler(cElR);
            hipL.localRotation = Quaternion.Euler(cHipL); hipR.localRotation = Quaternion.Euler(cHipR);
        }
    }
}
