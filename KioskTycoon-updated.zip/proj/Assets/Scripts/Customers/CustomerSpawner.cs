using System;
using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Создаёт покупателей по профилям, ведёт очередь и подбирает заказы по ассортименту.</summary>
    public class CustomerSpawner : MonoBehaviour
    {
        public static CustomerSpawner I;
        public readonly List<Customer> Queue = new List<Customer>();
        const float BaseInterval = 14f;
        const float QueueStep = 0.85f;
        float timer = 3f;
        bool warnedNoStock;

        public Customer Front => Queue.Count > 0 ? Queue[0] : null;

        void Awake() { I = this; }

        public static Vector3 PositionFor(int i) => KioskBuilder.CustomerSpot + new Vector3(0f, 0f, -QueueStep * i);

        public void ClearAll()
        {
            foreach (var c in Queue) if (c != null) Destroy(c.gameObject);
            Queue.Clear();
        }

        public void Remove(Customer c) { Queue.Remove(c); }

        void Update()
        {
            for (int i = 0; i < Queue.Count; i++)
                Queue[i].Target = PositionFor(i) + new Vector3(Queue[i].Jitter, 0f, 0f);

            var e = EconomyManager.I;
            if (e == null || e.phase != Phase.Open) return;
            timer -= Time.deltaTime;
            if (timer > 0f) return;
            Spawn();
            timer = BaseInterval / Mathf.Max(0.3f, e.SpawnMultiplier) * UnityEngine.Random.Range(0.7f, 1.3f);
        }

        void Spawn()
        {
            bool anyStock = false;
            foreach (var p in GameDatabase.Products)
                if (StockManager.I.OnShelves(p) - ReservedCount(p) > 0) { anyStock = true; break; }
            if (!anyStock)
            {
                if (!warnedNoStock) Toast.Warn(Loc.Get("t.nostock"));
                warnedNoStock = true;
                return;
            }
            warnedNoStock = false;

            int lvl = GameSession.Data.Up(UpgradeType.Size);
            int cap = UpgradeCatalog.QueueCap[lvl];
            if (Queue.Count >= cap)
            {
                EconomyManager.I.RecordLost();
                EconomyManager.I.AddRep(-1f);
                Toast.Warn(Loc.Get("t.queuefull"));
                return;
            }

            var prof = PickProfile();
            bool young = UnityEngine.Random.value < prof.youngChance;
            var sec = SecurityManager.I;
            // кражи: шанс растёт с днями, камеры и охрана его снижают; часть честных покупателей ведёт себя нервно
            bool suspect = sec != null && !young && UnityEngine.Random.value < sec.SuspectChance();
            bool nervous = !suspect && sec != null && UnityEngine.Random.value < sec.NervousChance();
            // приходит по тротуару сбоку (как прохожие), встаёт в хвост очереди
            int side = UnityEngine.Random.value < 0.5f ? -1 : 1;
            float laneZ = UnityEngine.Random.Range(-6.7f, -6.2f);
            float tailZ = PositionFor(Queue.Count).z;
            var c = Customer.Create(transform, prof, new Vector3(side * 9f, 0f, laneZ), young, suspect, nervous);
            c.Arrive.Add(new Vector3(side * 1.3f, 0f, laneZ));
            c.Arrive.Add(new Vector3(side * 0.9f, 0f, tailZ));
            c.Wants = BuildOrder(prof, young);
            // терпение у каждого своё: профиль задаёт среднее, ±20%
            float patience = prof.patience * UnityEngine.Random.Range(0.8f, 1.2f);
            c.MaxPatience = patience;
            c.Patience = patience;
            c.Jitter = UnityEngine.Random.Range(-0.2f, 0.2f);
            Queue.Add(c);
            if (suspect && sec != null) sec.OnSuspectSpawned(c);
        }

        CustomerProfile PickProfile()
        {
            var list = GameDatabase.Profiles;
            var w = new List<float>(list.Count);
            foreach (var p in list) w.Add(p.spawnWeight);
            return list[Pick(w)];
        }

        Dictionary<ProductData, int> BuildOrder(CustomerProfile prof, bool young)
        {
            var order = new Dictionary<ProductData, int>();
            int display = GameSession.Data.Up(UpgradeType.Display);
            var pool = new List<ProductData>();
            var weights = new List<float>();
            foreach (var p in GameDatabase.Products)
            {
                int available = Mathf.Max(0, StockManager.I.OnShelves(p) - ReservedCount(p));
                if (p.unlockLevel > display || available <= 0) continue;
                float wt = p.baseDemand * EconomyManager.I.DemandMult(p);
                if (prof.favorites != null && Array.IndexOf(prof.favorites, p.category) >= 0) wt *= prof.favoriteBoost;
                pool.Add(p);
                weights.Add(wt);
            }
            if (pool.Count == 0) return order;

            int kinds = UnityEngine.Random.Range(prof.itemKinds.x, prof.itemKinds.y + 1);
            for (int k = 0; k < kinds && pool.Count > 0; k++)
            {
                int i = Pick(weights);
                int available = Mathf.Max(0, StockManager.I.OnShelves(pool[i]) - ReservedCount(pool[i]));
                order[pool[i]] = Mathf.Min(available, UnityEngine.Random.Range(prof.quantity.x, prof.quantity.y + 1));
                pool.RemoveAt(i);
                weights.RemoveAt(i);
            }

            // молодой покупатель часто просит товар 18+: это проверка возраста
            if (young && UnityEngine.Random.value < 0.7f)
            {
                bool has = false;
                foreach (var k in order.Keys) if (k.AgeRestricted) has = true;
                if (!has)
                {
                    var cand = new List<ProductData>();
                    foreach (var p in GameDatabase.Products)
                        if (p.AgeRestricted && p.unlockLevel <= display && StockManager.I.OnShelves(p) - ReservedCount(p) > 0 && !order.ContainsKey(p)) cand.Add(p);
                    if (cand.Count > 0) order[cand[UnityEngine.Random.Range(0, cand.Count)]] = 1;
                }
            }
            return order;
        }

        int ReservedCount(ProductData product)
        {
            int reserved = 0;
            foreach (var customer in Queue)
                if (customer != null && customer.State != CustState.Leaving && customer.Wants.TryGetValue(product, out int count))
                    reserved += count;
            return reserved;
        }

        static int Pick(List<float> w)
        {
            float total = 0f;
            foreach (var x in w) total += x;
            float r = UnityEngine.Random.value * total;
            for (int i = 0; i < w.Count; i++)
            {
                r -= w[i];
                if (r <= 0f) return i;
            }
            return w.Count - 1;
        }
    }
}
