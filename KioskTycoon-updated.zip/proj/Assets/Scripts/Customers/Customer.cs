using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    public enum CustState { Queued, Ordering, Shopping, Paying, Leaving, Fleeing }
    public enum LeaveMood { Neutral, Happy, Angry }

    /// <summary>
    /// Покупатель: идёт в очередь, делает заказ, ждёт, оплачивает и уходит довольным или недовольным.
    /// Внешность и анимации — CustomerFactory / CustomerRig. «Подозрительный» (Suspect) может схватить
    /// неоплаченные товары с кассы и убежать; «нервный» (Nervous) ведёт себя так же, но честен.
    /// </summary>
    public class Customer : Interactable, IWorldLabel, IFleeing
    {
        public CustomerProfile profile;
        public Dictionary<ProductData, int> Wants = new Dictionary<ProductData, int>();
        public bool Young, Suspect, Nervous;
        public CustState State = CustState.Queued;
        public Vector3 Target;
        public float MaxPatience, Patience, Jitter;
        public CustomerRig Rig { get; private set; }

        const float WalkSpeed = 1.4f, RunSpeed = 3.0f;
        LeaveMood mood = LeaveMood.Neutral;
        float height = 1f;
        float stealTimer = -1f, fleeTime, stepTimer, shiftSeed, orderTime;
        Dictionary<ProductData, int> loot;
        readonly List<Vector3> path = new List<Vector3>();
        /// <summary>Путь по тротуару до очереди: покупатель приходит со стороны улицы, а не появляется у окна.</summary>
        public readonly List<Vector3> Arrive = new List<Vector3>();

        public override float MaxDistance => 3.2f;
        public bool IsFront => CustomerSpawner.I != null && CustomerSpawner.I.Front == this;
        public float PatienceLeft => MaxPatience > 0f ? Patience / MaxPatience : 0f;

        // ---------- IFleeing ----------
        public Vector3 Position => transform.position;
        public bool IsFleeing => State == CustState.Fleeing;

        public static Customer Create(Transform parent, CustomerProfile prof, Vector3 spawn, bool young, bool suspect, bool nervous)
        {
            var go = new GameObject("Customer_" + prof.id + (suspect ? "_suspect" : ""));
            go.transform.SetParent(parent, false);
            go.transform.position = spawn;
            var c = go.AddComponent<Customer>();
            c.profile = prof;
            c.Young = young;
            c.Suspect = suspect;
            c.Nervous = nervous;
            c.Target = spawn;
            c.shiftSeed = Random.value * 10f;

            var look = CustomerFactory.Roll(prof, young, suspect);
            c.height = look.height;
            c.Rig = CustomerFactory.Build(go.transform, look, young);

            var col = go.AddComponent<CapsuleCollider>();
            col.center = new Vector3(0f, 0.9f * c.height, 0f);
            col.radius = 0.3f;
            col.height = 1.8f * c.height;
            return c;
        }

        void Awake() { WorldLabels.Add(this); }

        void OnDestroy()
        {
            WorldLabels.Remove(this);
            if (SecurityManager.I != null) SecurityManager.I.Unregister(this);
        }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f) return;
            Vector3 before = transform.position;

            if (State == CustState.Fleeing)
            {
                fleeTime += dt;
                // короткий разгон: у игрока есть секунда, чтобы заметить и ударить битой
                float sp = RunSpeed * Mathf.Clamp01(0.4f + fleeTime * 0.8f);
                if (FollowPath(dt, sp)) Escape();
            }
            else if (State == CustState.Leaving)
            {
                if (FollowPath(dt, WalkSpeed * 1.15f)) { Destroy(gameObject); return; }
            }
            else
            {
                if (State == CustState.Queued && Arrive.Count > 0)
                {
                    Vector3 wp = new Vector3(Arrive[0].x, transform.position.y, Arrive[0].z);
                    Vector3 to = wp - transform.position;
                    if (to.sqrMagnitude > 0.0004f)
                        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(to.normalized), dt * 9f);
                    transform.position = Vector3.MoveTowards(transform.position, wp, WalkSpeed * dt);
                    if ((wp - transform.position).sqrMagnitude < 0.0064f) Arrive.RemoveAt(0);
                }
                else
                {
                    transform.position = Vector3.MoveTowards(transform.position, Target, WalkSpeed * dt);
                    transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.identity, dt * 8f);
                }

                if (State == CustState.Queued && IsFront && Vector3.Distance(transform.position, Target) < 0.05f)
                {
                    State = CustState.Ordering;
                    orderTime = 0f;
                    AudioManager.Play(Sfx.Bell, 0.3f);
                    AudioManager.PlayAt(Sfx.VoiceHi, transform.position, 0.8f);
                }
                if (State == CustState.Ordering) orderTime += dt;

                if (State != CustState.Paying && Arrive.Count == 0)
                {
                    Patience -= dt;
                    if (Patience <= 0f) { GiveUp(); return; }
                }
                TickSteal(dt);
            }

            float speed = (transform.position - before).magnitude / dt;
            TickSteps(speed, dt);
            if (Rig != null) Rig.Tick(dt, PoseNow(speed), speed);
        }

        // ---------- анимация ----------
        CustomerPose PoseNow(float speed)
        {
            switch (State)
            {
                case CustState.Fleeing: return CustomerPose.Run;
                case CustState.Leaving:
                    return mood == LeaveMood.Happy ? CustomerPose.Happy
                         : mood == LeaveMood.Angry ? CustomerPose.Angry : CustomerPose.Walk;
                case CustState.Paying: return CustomerPose.Pay;
            }
            if (speed > 0.3f) return CustomerPose.Walk;
            // сигналы: подозрительный чаще оглядывается; нервный честный покупатель — тоже, но реже
            float cycle = Mathf.Repeat(Time.time * 0.15f + shiftSeed, 1f);
            if ((Suspect && cycle < 0.55f) || (Nervous && cycle < 0.3f)) return CustomerPose.Shifty;
            float pl = PatienceLeft;
            if (pl < 0.15f) return CustomerPose.Angry;
            if (pl < 0.4f) return CustomerPose.Impatient;
            if (State == CustState.Ordering && orderTime < 1.4f) return CustomerPose.Wave;
            if (State == CustState.Shopping) return CustomerPose.Choose;
            return CustomerPose.Idle;
        }

        void TickSteps(float speed, float dt)
        {
            if (speed < 0.5f) { stepTimer = 0.1f; return; }
            stepTimer -= dt;
            if (stepTimer > 0f) return;
            AudioManager.PlayAt(Sfx.Step, transform.position, 0.45f);
            stepTimer = speed > 2f ? 0.28f : 0.5f;
        }

        bool FollowPath(float dt, float speed)
        {
            if (path.Count == 0) return true;
            Vector3 tgt = new Vector3(path[0].x, transform.position.y, path[0].z);
            Vector3 dir = tgt - transform.position;
            if (dir.sqrMagnitude > 0.0004f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir.normalized), dt * 9f);
            transform.position = Vector3.MoveTowards(transform.position, tgt, speed * dt);
            if ((tgt - transform.position).sqrMagnitude < 0.0064f) path.RemoveAt(0);
            return path.Count == 0;
        }

        void BuildLeavePath()
        {
            // уходит по тротуару: шаг в сторону от очереди, к дорожке и вдоль улицы
            path.Clear();
            int side = Random.value < 0.5f ? -1 : 1;
            Vector3 p = transform.position;
            float laneZ = Random.Range(-6.7f, -6.2f);
            path.Add(new Vector3(side * 1.4f, 0f, p.z));
            path.Add(new Vector3(side * 1.4f, 0f, laneZ));
            path.Add(new Vector3(side * 16f, 0f, laneZ));
        }

        // ---------- кража ----------
        void TickSteal(float dt)
        {
            if (!Suspect || State != CustState.Shopping || !IsFront) return;
            if (stealTimer < 0f) stealTimer = Random.Range(7f, 15f);
            stealTimer -= dt;
            if (stealTimer > 0f) return;

            var reg = CashRegister.I;
            if (reg == null || reg.CounterTotal <= 0) { stealTimer = 2f; return; }   // хватать пока нечего
            var sec = SecurityManager.I;
            if (sec != null && sec.GuardDeters())
            {
                Suspect = false;                                                     // охранник на посту отпугнул
                Toast.Good(Loc.Get("t.guardDeter"));
                return;
            }
            var grabbed = reg.StealCounterGoods();
            if (grabbed.Count == 0) { stealTimer = 2f; return; }
            StartFleeing(grabbed);
        }

        void StartFleeing(Dictionary<ProductData, int> goods)
        {
            loot = goods;
            State = CustState.Fleeing;
            fleeTime = 0f;
            if (CustomerSpawner.I != null) CustomerSpawner.I.Remove(this);
            if (CashRegister.I != null) CashRegister.I.OnCustomerLeave(this);
            int side = Random.value < 0.5f ? -1 : 1;
            Vector3 p = transform.position;
            path.Clear();
            float laneZ = Random.Range(-6.7f, -6.2f);
            path.Add(new Vector3(side * 1.4f, 0f, p.z - 0.5f));
            path.Add(new Vector3(side * 3f, 0f, laneZ));
            path.Add(new Vector3(side * 18f, 0f, laneZ));
            Toast.Warn(Loc.Get("t.thiefGrab"));
            if (SecurityManager.I != null) SecurityManager.I.RegisterFleeing(this);
        }

        void Escape()
        {
            if (SecurityManager.I != null)
            {
                SecurityManager.I.Unregister(this);
                if (loot != null) SecurityManager.I.OnEscaped(loot);
            }
            loot = null;
            Destroy(gameObject);
        }

        /// <summary>Остановлен битой или охраной: украденное возвращается, вор уходит с пустыми руками.</summary>
        public void Catch(bool byGuard)
        {
            if (State != CustState.Fleeing) return;
            if (SecurityManager.I != null)
            {
                SecurityManager.I.Unregister(this);
                if (loot != null) SecurityManager.I.OnRecovered(loot);
            }
            loot = null;
            mood = LeaveMood.Angry;
            State = CustState.Leaving;
            BuildLeavePath();
            AudioManager.Play(byGuard ? Sfx.Whistle : Sfx.BatHit);
            AudioManager.PlayAt(Sfx.VoiceGrumble, transform.position, 0.9f);
        }

        // ---------- обычное поведение ----------
        void GiveUp()
        {
            EconomyManager.I.RecordLost();
            EconomyManager.I.AddRep(-4f);
            Toast.Warn(Loc.Get("t.gaveup"));
            Leave(LeaveMood.Angry);
        }

        public bool HasRestricted()
        {
            foreach (var k in Wants.Keys) if (k.AgeRestricted) return true;
            return false;
        }

        public void Leave(LeaveMood m = LeaveMood.Neutral)
        {
            if (State == CustState.Leaving || State == CustState.Fleeing) return;
            if (CashRegister.I != null) CashRegister.I.OnCustomerLeave(this);
            State = CustState.Leaving;
            mood = m;
            foreach (var c in GetComponentsInChildren<Collider>()) c.enabled = false;
            if (CustomerSpawner.I != null) CustomerSpawner.I.Remove(this);
            BuildLeavePath();
            if (m == LeaveMood.Happy) AudioManager.PlayAt(Sfx.VoiceHappy, transform.position, 0.9f);
            else if (m == LeaveMood.Angry) AudioManager.PlayAt(Sfx.VoiceGrumble, transform.position, 0.9f);
        }

        public override string Prompt(PlayerContext p)
        {
            if (State == CustState.Fleeing) return Loc.Get("p.thief.bat");
            if (!IsFront) return null;
            if (State == CustState.Ordering) return Loc.Get("p.cust.accept");
            if (State == CustState.Shopping) return Loc.Get("p.cust.collect");
            return null;
        }

        public override void Interact(PlayerContext p)
        {
            if (State == CustState.Fleeing) { if (PlayerController.I != null) PlayerController.I.SwingBat(); return; }
            if (!IsFront || State != CustState.Ordering) return;
            State = CustState.Shopping;
            if (CashRegister.I != null) CashRegister.I.BeginOrder(this);
            AudioManager.Play(Sfx.Bell, 0.4f);
            Toast.Push(Loc.Get("t.accepted"));
        }

        // ---------- подпись над головой ----------
        public Vector3 LabelPos => transform.position + Vector3.up * (2.05f * height + 0.1f);
        public float LabelMaxDist => 25f;

        public void DrawLabel(Vector2 sp)
        {
            var t = ThemeManager.Current;
            if (State == CustState.Leaving) return;
            if (State == CustState.Fleeing)
            {
                UIKit.Box(new Rect(sp.x - 70, sp.y - 44, 140, 40), new Color(0.85f, 0.08f, 0.08f, 0.92f));
                UIKit.Label(new Rect(sp.x - 70, sp.y - 44, 140, 40), Loc.Get("hud.thief"), 30, Color.white, TextAnchor.MiddleCenter, true, false);
                return;
            }
            float pct = Mathf.Clamp01(PatienceLeft);
            var col = Color.Lerp(new Color(1f, 0.35f, 0.3f), new Color(0.4f, 0.95f, 0.45f), pct);
            UIKit.Bar(new Rect(sp.x - 40, sp.y, 80, 12), pct, col);

            bool marked = SecurityManager.I != null && SecurityManager.I.IsMarked(this);
            if (marked)
            {
                UIKit.Box(new Rect(sp.x - 90, sp.y - 44, 180, 36), new Color(0.82f, 0.1f, 0.1f, 0.92f));
                UIKit.Label(new Rect(sp.x - 90, sp.y - 44, 180, 36), "! " + Loc.Get("hud.suspect"), 22, Color.white, TextAnchor.MiddleCenter, true, false);
            }
            else if (State == CustState.Ordering)
                UIKit.Label(new Rect(sp.x - 40, sp.y - 44, 80, 40), "?", 36, t.accent, TextAnchor.MiddleCenter, true, false);
            else if (Young && HasRestricted())
                UIKit.Label(new Rect(sp.x - 50, sp.y - 40, 100, 36), Loc.Get("hud.young"), 26, t.accent2, TextAnchor.MiddleCenter, true, false);
        }
    }
}
