using System;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Экран настроек: графика, звук, управление, язык и тема. Используется и в меню, и на паузе.</summary>
    public static class SettingsUI
    {
        static int tab;
        static GameAction? listening;
        static Vector2 scroll;
        static readonly KeyCode[] AllKeys = (KeyCode[])Enum.GetValues(typeof(KeyCode));

        public static void Reset() { tab = 0; listening = null; scroll = Vector2.zero; }

        /// <summary>Вызывать каждый кадр: ловит новую клавишу при переназначении.</summary>
        public static void Update()
        {
            if (listening == null) return;
            if (Input.GetKeyDown(KeyCode.Escape)) { listening = null; return; }
            foreach (var k in AllKeys)
            {
                if (k == KeyCode.Escape || k == KeyCode.Mouse0 || k == KeyCode.Mouse1 || k == KeyCode.None) continue;
                if (!Input.GetKeyDown(k)) continue;
                Binds.Set(listening.Value, k);
                SettingsManager.Save();
                listening = null;
                return;
            }
        }

        public static void Draw(Rect r)
        {
            string[] names = { Loc.Get("s.graphics"), Loc.Get("s.sound"), Loc.Get("s.controls"), Loc.Get("s.lang") };
            tab = UIKit.Tabs(new Rect(r.x, r.y, r.width, 60), names, tab);
            var body = new Rect(r.x, r.y + 80, r.width, r.height - 80);
            bool changed;
            switch (tab)
            {
                case 0: changed = Graphics(body); break;
                case 1: changed = Sound(body); break;
                case 2: changed = Controls(body); break;
                default: changed = Lang(body); break;
            }
            if (changed) SettingsManager.Save();
        }

        static void Row(Rect b, float y, string label, out Rect control)
        {
            UIKit.Plate(new Rect(b.x, y, b.width, 66));
            UIKit.Label(new Rect(b.x + 24, y, b.width * 0.45f, 66), label, 28, ThemeManager.Current.text, TextAnchor.MiddleLeft, false, false);
            control = new Rect(b.xMax - 600, y + 12, 570, 42);
        }

        static bool Graphics(Rect b)
        {
            var d = SettingsManager.Data;
            bool ch = false;
            float y = b.y;
            var names = QualitySettings.names;
            Row(b, y, Loc.Get("s.quality"), out var c);
            int qi = Mathf.Clamp(d.quality, 0, names.Length - 1);
            int dir = UIKit.Cycle(c, names[qi]);
            if (dir != 0) { d.quality = (qi + dir + names.Length) % names.Length; ch = true; SettingsManager.ApplyGraphics(); }
            y += 76;

            var res = SettingsManager.Resolutions;
            int ri = SettingsManager.ResolutionIndex();
            Row(b, y, Loc.Get("s.resolution"), out c);
            dir = UIKit.Cycle(c, res[ri].x + " × " + res[ri].y);
            if (dir != 0)
            {
                int ni = (ri + dir + res.Count) % res.Count;
                d.resW = res[ni].x; d.resH = res[ni].y;
                ch = true;
                SettingsManager.ApplyGraphics();
            }
            y += 76;

            Row(b, y, Loc.Get("s.fullscreen"), out c);
            bool fs = UIKit.Toggle(new Rect(c.x, c.y - 12, c.width, 66), d.fullscreen, "");
            if (fs != d.fullscreen) { d.fullscreen = fs; ch = true; SettingsManager.ApplyGraphics(); }
            y += 76;

            Row(b, y, Loc.Get("s.brightness"), out c);
            float before = d.brightness;
            d.brightness = UIKit.Slider(new Rect(c.x, c.y, c.width - 80, 42), d.brightness, 0.5f, 1.5f);
            UIKit.Label(new Rect(c.xMax - 70, c.y, 70, 42), Mathf.RoundToInt(d.brightness * 100) + "%", 24, ThemeManager.Current.text, TextAnchor.MiddleRight, false, false);
            if (Math.Abs(before - d.brightness) > 0.0001f) ch = true;
            return ch;
        }

        static bool Sound(Rect b)
        {
            var d = SettingsManager.Data;
            bool ch = false;
            float y = b.y;
            ch |= Slider(b, ref y, Loc.Get("s.master"), ref d.master);
            ch |= Slider(b, ref y, Loc.Get("s.music"), ref d.music);
            ch |= Slider(b, ref y, Loc.Get("s.sfx"), ref d.sfx);
            Row(b, y, Loc.Get("s.musicEnabled"), out var toggleRect);
            bool musicEnabled = UIKit.Toggle(toggleRect, d.musicEnabled, "");
            if (musicEnabled != d.musicEnabled) { d.musicEnabled = musicEnabled; ch = true; }
            if (ch) { SettingsManager.ApplyAll(); }
            return ch;
        }

        static bool Slider(Rect b, ref float y, string label, ref float v)
        {
            Row(b, y, label, out var c);
            float before = v;
            v = UIKit.Slider(new Rect(c.x, c.y, c.width - 80, 42), v, 0f, 1f);
            UIKit.Label(new Rect(c.xMax - 70, c.y, 70, 42), Mathf.RoundToInt(v * 100) + "%", 24, ThemeManager.Current.text, TextAnchor.MiddleRight, false, false);
            y += 76;
            return Math.Abs(before - v) > 0.0001f;
        }

        static bool Controls(Rect b)
        {
            var t = ThemeManager.Current;
            var d = SettingsManager.Data;
            bool ch = false;
            var actions = Binds.All;
            float rowH = 62f;
            float contentH = actions.Length * rowH + 8 * 76 + 80;
            var view = new Rect(0, 0, b.width - 24, contentH);
            scroll = GUI.BeginScrollView(b, scroll, view);
            float y = 0f;
            UIKit.Label(new Rect(8, y, view.width, 40), Loc.Get("s.rebindHint"), 22, t.textDim, TextAnchor.MiddleLeft, false, false);
            y += 44;
            foreach (var a in actions)
            {
                var row = new Rect(0, y, view.width, rowH - 8);
                UIKit.Plate(row);
                UIKit.Label(new Rect(row.x + 24, row.y, 500, row.height), Loc.Get("act." + a), 26, t.text, TextAnchor.MiddleLeft, false, false);
                string txt = listening == a ? Loc.Get("s.press") : Binds.Name(a);
                if (UIKit.Button(new Rect(row.xMax - 340, row.y + 6, 320, row.height - 14), txt, true, 24, listening == a ? t.accent2 : t.panel2))
                    listening = a;
                y += rowH;
            }
            y += 10;
            var sr = new Rect(0, y, view.width, 66);
            UIKit.Plate(sr);
            UIKit.Label(new Rect(24, sr.y, 500, 66), Loc.Get("s.sens"), 26, t.text, TextAnchor.MiddleLeft, false, false);
            float before = d.sensitivity;
            d.sensitivity = UIKit.Slider(new Rect(view.width - 520, sr.y + 12, 400, 42), d.sensitivity, 0.5f, 5f);
            if (Math.Abs(before - d.sensitivity) > 0.0001f) ch = true;
            y += 76;
            var ir = new Rect(0, y, view.width, 66);
            UIKit.Plate(ir);
            bool inv = UIKit.Toggle(new Rect(24, ir.y + 12, view.width - 48, 42), d.invertY, Loc.Get("s.invert"));
            if (inv != d.invertY) { d.invertY = inv; ch = true; }
            y += 76;

            Row(view, y, Loc.Get("s.wellbeingInterval"), out var c);
            float beforeSetting = d.wellbeingInterval;
            d.wellbeingInterval = UIKit.Slider(new Rect(c.x, c.y, c.width - 100, 42), d.wellbeingInterval, 15f, 180f);
            UIKit.Label(new Rect(c.xMax - 90, c.y, 90, 42), Mathf.RoundToInt(d.wellbeingInterval) + " s", 24, t.text, TextAnchor.MiddleRight, false, false);
            if (Math.Abs(beforeSetting - d.wellbeingInterval) > 0.01f) ch = true;
            y += 76;

            Row(view, y, Loc.Get("s.puffInterval"), out c);
            beforeSetting = d.puffInterval;
            d.puffInterval = UIKit.Slider(new Rect(c.x, c.y, c.width - 100, 42), d.puffInterval, 1f, 20f);
            UIKit.Label(new Rect(c.xMax - 90, c.y, 90, 42), Mathf.RoundToInt(d.puffInterval) + " s", 24, t.text, TextAnchor.MiddleRight, false, false);
            if (Math.Abs(beforeSetting - d.puffInterval) > 0.01f) ch = true;
            y += 76;

            Row(view, y, Loc.Get("s.inhaleDuration"), out c);
            beforeSetting = d.inhaleDuration;
            d.inhaleDuration = UIKit.Slider(new Rect(c.x, c.y, c.width - 100, 42), d.inhaleDuration, 0.5f, 5f);
            UIKit.Label(new Rect(c.xMax - 90, c.y, 90, 42), d.inhaleDuration.ToString("0.0") + " s", 24, t.text, TextAnchor.MiddleRight, false, false);
            if (Math.Abs(beforeSetting - d.inhaleDuration) > 0.01f) ch = true;
            y += 76;

            Row(view, y, Loc.Get("s.exhaleDuration"), out c);
            beforeSetting = d.exhaleDuration;
            d.exhaleDuration = UIKit.Slider(new Rect(c.x, c.y, c.width - 100, 42), d.exhaleDuration, 0.5f, 5f);
            UIKit.Label(new Rect(c.xMax - 90, c.y, 90, 42), d.exhaleDuration.ToString("0.0") + " s", 24, t.text, TextAnchor.MiddleRight, false, false);
            if (Math.Abs(beforeSetting - d.exhaleDuration) > 0.01f) ch = true;
            y += 76;

            Row(view, y, Loc.Get("s.wellbeingEffect"), out c);
            beforeSetting = d.wellbeingEffect;
            d.wellbeingEffect = UIKit.Slider(new Rect(c.x, c.y, c.width - 100, 42), d.wellbeingEffect, 0f, 1f);
            UIKit.Label(new Rect(c.xMax - 90, c.y, 90, 42), Mathf.RoundToInt(d.wellbeingEffect * 100f) + "%", 24, t.text, TextAnchor.MiddleRight, false, false);
            if (Math.Abs(beforeSetting - d.wellbeingEffect) > 0.001f) ch = true;
            y += 76;
            if (UIKit.Button(new Rect(view.width - 420, y + 6, 400, 56), Loc.Get("s.reset"), true, 26, t.accent2))
            {
                Binds.ResetAll();
                ch = true;
            }
            GUI.EndScrollView();
            return ch;
        }

        static bool Lang(Rect b)
        {
            var t = ThemeManager.Current;
            var d = SettingsManager.Data;
            bool ch = false;
            float y = b.y;

            Row(b, y, Loc.Get("s.language"), out var c);
            int li = Array.IndexOf(Loc.Codes, d.language);
            if (li < 0) li = 0;
            int dir = UIKit.Cycle(c, Loc.Names[li]);
            if (dir != 0)
            {
                d.language = Loc.Codes[(li + dir + Loc.Codes.Length) % Loc.Codes.Length];
                ch = true;
                SettingsManager.ApplyAll();
            }
            y += 76;

            Row(b, y, Loc.Get("s.theme"), out c);
            int ti = Mathf.Clamp(d.theme, 0, ThemeManager.All.Length - 1);
            dir = UIKit.Cycle(c, Loc.Get(ThemeManager.All[ti].nameKey));
            if (dir != 0)
            {
                d.theme = (ti + dir + ThemeManager.All.Length) % ThemeManager.All.Length;
                ch = true;
                ThemeManager.Set(d.theme);
            }
            y += 96;

            // предпросмотр выбранной темы (рисуется её собственными цветами)
            var pt = ThemeManager.All[Mathf.Clamp(d.theme, 0, ThemeManager.All.Length - 1)];
            var pv = new Rect(b.x, y, b.width, 300);
            UIKit.Box(pv, pt.sky);
            UIKit.Box(new Rect(pv.x + 40, pv.y + 40, pv.width - 80, 220), pt.panel);
            UIKit.Box(new Rect(pv.x + 40, pv.y + 40, pv.width - 80, 60), pt.panel2);
            UIKit.Label(new Rect(pv.x + 64, pv.y + 44, 600, 52), Loc.Get("s.preview"), 30, pt.accent, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(pv.x + 64, pv.y + 120, 700, 44), Loc.Get("th.sampleText"), 30, pt.text, TextAnchor.MiddleLeft, false, false);
            UIKit.Box(new Rect(pv.x + 64, pv.y + 190, 360, 56), pt.accent);
            UIKit.Label(new Rect(pv.x + 64, pv.y + 190, 360, 56), Loc.Get("th.sample"), 26, pt.btnText, TextAnchor.MiddleCenter, true, false);
            UIKit.Box(new Rect(pv.x + 450, pv.y + 190, 200, 56), pt.good);
            UIKit.Box(new Rect(pv.x + 670, pv.y + 190, 200, 56), pt.bad);
            return ch;
        }
    }
}
