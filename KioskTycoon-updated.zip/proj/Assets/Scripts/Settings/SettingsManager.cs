using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace KioskTycoon
{
    public enum GameAction { Forward, Back, Left, Right, Run, Interact, Drop, Decline, Inventory, UseDevice, UseBat, CallGuard }

    [Serializable]
    public class SettingsData
    {
        public int quality = -1;
        public int resW, resH;
        public bool fullscreen = true;
        public float brightness = 1f;
        public float master = 0.8f, music = 0.5f, sfx = 0.8f;
        public bool musicEnabled = true;
        public float sensitivity = 2f;
        public bool invertY;
        public string language = "ru";
        public int theme = 0;
        [Range(15f, 180f)] public float wellbeingInterval = 45f;
        [Range(1f, 20f)] public float puffInterval = 4f;
        [Range(0.5f, 5f)] public float inhaleDuration = 1.1f;
        [Range(0.5f, 5f)] public float exhaleDuration = 1.5f;
        [Range(0f, 1f)] public float wellbeingEffect = 0.35f;
        public List<string> bindNames = new List<string>();
        public List<int> bindKeys = new List<int>();
    }

    /// <summary>Переназначаемые клавиши.</summary>
    public static class Binds
    {
        static Dictionary<GameAction, KeyCode> map = new Dictionary<GameAction, KeyCode>();

        static readonly Dictionary<GameAction, KeyCode> Defaults = new Dictionary<GameAction, KeyCode>
        {
            { GameAction.Forward, KeyCode.W }, { GameAction.Back, KeyCode.S },
            { GameAction.Left, KeyCode.A }, { GameAction.Right, KeyCode.D },
            { GameAction.Run, KeyCode.LeftShift }, { GameAction.Interact, KeyCode.E },
            { GameAction.Drop, KeyCode.G }, { GameAction.Decline, KeyCode.F },
            { GameAction.Inventory, KeyCode.Tab }, { GameAction.UseDevice, KeyCode.V },
            { GameAction.UseBat, KeyCode.B }, { GameAction.CallGuard, KeyCode.H },
        };

        public static readonly GameAction[] All = (GameAction[])Enum.GetValues(typeof(GameAction));

        public static void LoadFrom(SettingsData d)
        {
            map = new Dictionary<GameAction, KeyCode>(Defaults);
            for (int i = 0; i < d.bindNames.Count && i < d.bindKeys.Count; i++)
                if (Enum.TryParse(d.bindNames[i], out GameAction a)) map[a] = (KeyCode)d.bindKeys[i];
        }

        public static void SaveTo(SettingsData d)
        {
            d.bindNames.Clear(); d.bindKeys.Clear();
            foreach (var kv in map) { d.bindNames.Add(kv.Key.ToString()); d.bindKeys.Add((int)kv.Value); }
        }

        public static void ResetAll() { map = new Dictionary<GameAction, KeyCode>(Defaults); }

        public static KeyCode Get(GameAction a) => map.TryGetValue(a, out var k) ? k : Defaults[a];
        public static bool Held(GameAction a) => Input.GetKey(Get(a));
        public static bool Down(GameAction a) => Input.GetKeyDown(Get(a));

        public static void Set(GameAction a, KeyCode k)
        {
            var old = Get(a);
            foreach (var other in All)
                if (other != a && Get(other) == k) map[other] = old; // меняем местами при конфликте
            map[a] = k;
        }

        public static string Name(GameAction a) => Name(Get(a));

        public static string Name(KeyCode k)
        {
            switch (k)
            {
                case KeyCode.LeftShift: return "Shift";
                case KeyCode.RightShift: return "R-Shift";
                case KeyCode.Space: return "Space";
                case KeyCode.Mouse0: return "LMB";
                case KeyCode.Mouse1: return "RMB";
                case KeyCode.LeftControl: return "Ctrl";
                case KeyCode.LeftAlt: return "Alt";
                default: return k.ToString();
            }
        }
    }

    public static class SettingsManager
    {
        public static SettingsData Data = new SettingsData();
        public static readonly List<Vector2Int> Resolutions = new List<Vector2Int>();
        static string PathFile => Path.Combine(Application.persistentDataPath, "settings.json");

        public static void Load()
        {
            try
            {
                if (File.Exists(PathFile))
                {
                    var d = JsonUtility.FromJson<SettingsData>(File.ReadAllText(PathFile));
                    if (d != null) Data = d;
                }
            }
            catch (Exception e) { Debug.LogWarning("Settings load failed: " + e.Message); }
            if (Data.quality < 0) Data.quality = Mathf.Min(2, QualitySettings.names.Length - 1);
            Binds.LoadFrom(Data);
            BuildResolutions();
        }

        public static void Save()
        {
            Binds.SaveTo(Data);
            try { File.WriteAllText(PathFile, JsonUtility.ToJson(Data, true)); }
            catch (Exception e) { Debug.LogWarning("Settings save failed: " + e.Message); }
        }

        static void BuildResolutions()
        {
            Resolutions.Clear();
            foreach (var r in Screen.resolutions)
            {
                var v = new Vector2Int(r.width, r.height);
                if (!Resolutions.Contains(v)) Resolutions.Add(v);
            }
            if (Resolutions.Count == 0) Resolutions.Add(new Vector2Int(Screen.width, Screen.height));
        }

        public static int ResolutionIndex()
        {
            for (int i = 0; i < Resolutions.Count; i++)
                if (Resolutions[i].x == Data.resW && Resolutions[i].y == Data.resH) return i;
            for (int i = 0; i < Resolutions.Count; i++)
                if (Resolutions[i].x == Screen.width && Resolutions[i].y == Screen.height) return i;
            return Resolutions.Count - 1;
        }

        public static void ApplyGraphics()
        {
            QualitySettings.SetQualityLevel(Mathf.Clamp(Data.quality, 0, QualitySettings.names.Length - 1), true);
            var mode = Data.fullscreen ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
            if (Data.resW > 0) Screen.SetResolution(Data.resW, Data.resH, mode);
            else Screen.fullScreenMode = mode;
        }

        public static void ApplyAll()
        {
            ApplyGraphics();
            Loc.SetLanguage(Data.language);
            ThemeManager.Set(Data.theme);
            if (AudioManager.I != null) AudioManager.I.ApplyVolumes();
        }
    }
}
