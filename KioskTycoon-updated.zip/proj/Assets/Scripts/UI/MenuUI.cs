using UnityEngine;
using UnityEngine.SceneManagement;

namespace KioskTycoon
{
    /// <summary>Главное меню: продолжить, новая игра, настройки, язык, выход.</summary>
    public class MenuUI : MonoBehaviour
    {
        enum Screen { Main, Settings, Language, Confirm }
        Screen screen = Screen.Main;

        void Start()
        {
            SettingsUI.Reset();
            Time.timeScale = 1f;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        void Update() => SettingsUI.Update();

        void OnGUI()
        {
            UIKit.Begin();
            float vw = UIKit.VW;
            var t = ThemeManager.Current;
            DrawBackdrop(vw, t);

            switch (screen)
            {
                case Screen.Main: DrawMain(vw, t); break;
                case Screen.Settings:
                    DrawPanel(vw, t, Loc.Get("m.settings"), new Rect(vw / 2f - 800, 120, 1600, 840));
                    SettingsUI.Draw(new Rect(vw / 2f - 760, 240, 1520, 620));
                    if (UIKit.Button(new Rect(vw / 2f - 200, 880, 400, 64), Loc.Get("m.back"), true, 30)) screen = Screen.Main;
                    break;
                case Screen.Language: DrawLanguage(vw, t); break;
                case Screen.Confirm: DrawConfirm(vw, t); break;
            }
            UIKit.End();
        }

        void DrawBackdrop(float vw, Theme t)
        {
            UIKit.Box(new Rect(0, 0, vw, 1080), t.sky);
            UIKit.Box(new Rect(0, 640, vw, 440), Color.Lerp(t.sky, t.panel2, 0.5f));
            UIKit.Box(new Rect(0, 900, vw, 180), t.panel2);
            // силуэт киоска справа
            float kx = vw - 560, ky = 900;
            UIKit.Box(new Rect(kx, ky - 420, 420, 420), t.panel);
            UIKit.Box(new Rect(kx - 20, ky - 470, 460, 60), t.accent);
            UIKit.Box(new Rect(kx + 60, ky - 320, 300, 150), t.lamp);
            UIKit.Box(new Rect(kx + 40, ky - 300, 60, 300), t.panel2);
        }

        void DrawPanel(float vw, Theme t, string title, Rect r)
        {
            UIKit.Panel(r, title);
        }

        void DrawMain(float vw, Theme t)
        {
            UIKit.Label(new Rect(80, 120, 1200, 120), Loc.Get("m.title"), 86, t.text, TextAnchor.UpperLeft, true, false);
            UIKit.Label(new Rect(84, 230, 900, 50), Loc.Get("m.sub"), 34, t.textDim, TextAnchor.UpperLeft, false, false);

            float x = 90, y = 360, w = 460, h = 66, gap = 84;
            bool hasSave = SaveSystem.Exists();
            if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("m.continue"), hasSave, 32))
            {
                if (GameSession.Continue()) GameSession.LoadScene(GameSession.GameScene);
            }
            y += gap;
            if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("m.new"), true, 32))
            {
                if (hasSave) screen = Screen.Confirm;
                else { GameSession.NewGame(); GameSession.LoadScene(GameSession.GameScene); }
            }
            y += gap;
            if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("m.settings"), true, 32)) screen = Screen.Settings;
            y += gap;
            if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("m.language"), true, 32)) screen = Screen.Language;
            y += gap;
            if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("m.exit"), true, 32, t.accent2)) Quit();
        }

        void DrawLanguage(float vw, Theme t)
        {
            var r = new Rect(vw / 2f - 400, 300, 800, 560);
            UIKit.Panel(r, Loc.Get("m.language"));
            for (int i = 0; i < Loc.Codes.Length; i++)
            {
                bool sel = Loc.Current == Loc.Codes[i];
                if (UIKit.Button(new Rect(r.x + 120, r.y + 120 + i * 96, 560, 72), Loc.Names[i], true, 34, sel ? t.good : t.accent))
                {
                    SettingsManager.Data.language = Loc.Codes[i];
                    SettingsManager.ApplyAll();
                    SettingsManager.Save();
                }
            }
            if (UIKit.Button(new Rect(vw / 2f - 200, 900, 400, 64), Loc.Get("m.back"), true, 30)) screen = Screen.Main;
        }

        void DrawConfirm(float vw, Theme t)
        {
            var r = new Rect(vw / 2f - 420, 340, 840, 360);
            UIKit.Panel(r);
            UIKit.Label(new Rect(r.x + 40, r.y + 50, r.width - 80, 140), Loc.Get("m.confirm"), 34, t.text, TextAnchor.MiddleCenter, true, true);
            if (UIKit.Button(new Rect(r.x + 90, r.yMax - 110, 280, 70), Loc.Get("m.yes"), true, 32, t.accent2))
            {
                GameSession.NewGame();
                GameSession.LoadScene(GameSession.GameScene);
            }
            if (UIKit.Button(new Rect(r.xMax - 370, r.yMax - 110, 280, 70), Loc.Get("m.no"), true, 32)) screen = Screen.Main;
        }

        static void Quit()
        {
            SettingsManager.Save();
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
    }

    /// <summary>Пауза внутри киоска: продолжить, настройки, сохранить, в меню, выйти.</summary>
    public class PauseMenu : MonoBehaviour
    {
        public static PauseMenu I;
        public bool IsOpen { get; private set; }
        bool settings;

        void Awake() { I = this; }

        void Update() => SettingsUI.Update();

        public void Toggle()
        {
            if (IsOpen) Close(); else Open();
        }

        void Open()
        {
            IsOpen = true;
            settings = false;
            SettingsUI.Reset();
            Time.timeScale = 0f;
        }

        void Close()
        {
            IsOpen = false;
            Time.timeScale = 1f;
            SettingsManager.Save();
        }

        void SaveGame()
        {
            StockManager.SaveNow();
            Toast.Good(Loc.Get("t.saved"));
        }

        void OnGUI()
        {
            if (!IsOpen) return;
            UIKit.Begin();
            float vw = UIKit.VW;
            var t = ThemeManager.Current;
            UIKit.Box(new Rect(0, 0, vw, 1080), new Color(0, 0, 0, 0.55f));

            if (settings)
            {
                var pr = new Rect(vw / 2f - 800, 120, 1600, 840);
                UIKit.Panel(pr, Loc.Get("ps.settings"));
                SettingsUI.Draw(new Rect(pr.x + 40, pr.y + 110, pr.width - 80, pr.height - 200));
                if (UIKit.Button(new Rect(pr.x + pr.width / 2f - 200, pr.yMax - 80, 400, 60), Loc.Get("m.back"), true, 30))
                    settings = false;
            }
            else
            {
                var pr = new Rect(vw / 2f - 340, 200, 680, 680);
                UIKit.Panel(pr, Loc.Get("ps.title"));
                float x = pr.x + 110, w = 460, h = 64, y = pr.y + 110, gap = 80;
                if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("ps.resume"), true, 30, t.good)) Close();
                y += gap;
                if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("ps.settings"), true, 30)) settings = true;
                y += gap;
                if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("ps.save"), true, 30)) SaveGame();
                y += gap;
                if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("ps.menu"), true, 30))
                {
                    SaveGame();
                    Time.timeScale = 1f;
                    GameSession.LoadScene(GameSession.MenuScene);
                }
                y += gap;
                if (UIKit.Button(new Rect(x, y, w, h), Loc.Get("ps.quit"), true, 30, t.accent2))
                {
                    SaveGame();
                    SettingsManager.Save();
                    Time.timeScale = 1f;
#if UNITY_EDITOR
                    UnityEditor.EditorApplication.isPlaying = false;
#else
                    Application.Quit();
#endif
                }
            }
            UIKit.End();
        }
    }
}
