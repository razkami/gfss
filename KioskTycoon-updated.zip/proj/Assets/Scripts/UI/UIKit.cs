using System.Globalization;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Мини-библиотека IMGUI: масштабируется под 1080p, использует цвета текущей темы.</summary>
    public static class UIKit
    {
        public const float VH = 1080f;
        public static float S => Screen.height / VH;
        public static float VW => Screen.width / S;

        static GUIStyle lbl;
        static Matrix4x4 oldM;

        public static void Begin()
        {
            oldM = GUI.matrix;
            GUI.matrix = Matrix4x4.Scale(new Vector3(S, S, 1f));
            if (lbl == null) lbl = new GUIStyle(GUI.skin.label) { richText = true };
        }

        public static void End() { GUI.matrix = oldM; }

        public static string Money(float v) =>
            v.ToString("0.0", CultureInfo.InvariantCulture) + " " + Loc.Get("cur");

        public static void Box(Rect r, Color c)
        {
            var o = GUI.color; GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = o;
        }

        public static void Plate(Rect r) { Box(r, ThemeManager.Current.panel); }

        public static void Panel(Rect r, string title = null)
        {
            var t = ThemeManager.Current;
            Box(new Rect(r.x - 4, r.y - 4, r.width + 8, r.height + 8), t.accent);
            Box(r, t.panel);
            if (!string.IsNullOrEmpty(title))
            {
                Box(new Rect(r.x, r.y, r.width, 60), t.panel2);
                Label(new Rect(r.x + 18, r.y + 4, r.width - 36, 52), title, 36, t.accent, TextAnchor.MiddleLeft, true, false);
            }
        }

        public static void Label(Rect r, string s, int size = 28, Color? col = null,
            TextAnchor a = TextAnchor.UpperLeft, bool bold = false, bool wrap = true)
        {
            if (lbl == null) return;
            var c = col ?? ThemeManager.Current.text;
            lbl.fontSize = size; lbl.alignment = a; lbl.wordWrap = wrap;
            lbl.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
            if (c.r + c.g + c.b > 1.5f) // тень только для светлого текста
            {
                lbl.normal.textColor = new Color(0, 0, 0, 0.5f * c.a);
                GUI.Label(new Rect(r.x + 1.5f, r.y + 1.5f, r.width, r.height), s, lbl);
            }
            lbl.normal.textColor = c;
            GUI.Label(r, s, lbl);
        }

        public static bool Button(Rect r, string text, bool enabled = true, int size = 28, Color? col = null)
        {
            var t = ThemeManager.Current;
            var e = Event.current;
            bool hover = enabled && r.Contains(e.mousePosition);
            Color c = col ?? t.accent;
            if (!enabled) c = Color.Lerp(t.panel2, t.textDim, 0.25f);
            else if (hover) c = Color.Lerp(c, Color.white, 0.25f);
            Box(new Rect(r.x + 3, r.y + 4, r.width, r.height), new Color(0, 0, 0, 0.35f));
            Box(r, c);
            Label(r, text, size, enabled ? t.btnText : t.textDim, TextAnchor.MiddleCenter, true, false);
            if (enabled && e.type == EventType.MouseDown && e.button == 0 && r.Contains(e.mousePosition))
            {
                e.Use();
                AudioManager.Play(Sfx.Click);
                return true;
            }
            return false;
        }

        public static float Slider(Rect r, float v, float min, float max)
        {
            var t = ThemeManager.Current;
            int id = GUIUtility.GetControlID(FocusType.Passive);
            var e = Event.current;
            float Calc() => Mathf.Lerp(min, max, Mathf.Clamp01((e.mousePosition.x - r.x) / r.width));
            switch (e.GetTypeForControl(id))
            {
                case EventType.MouseDown:
                    if (e.button == 0 && r.Contains(e.mousePosition)) { GUIUtility.hotControl = id; v = Calc(); e.Use(); GUI.changed = true; }
                    break;
                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == id) { v = Calc(); e.Use(); GUI.changed = true; }
                    break;
                case EventType.MouseUp:
                    if (GUIUtility.hotControl == id) { GUIUtility.hotControl = 0; e.Use(); }
                    break;
            }
            float k = Mathf.InverseLerp(min, max, v);
            var track = new Rect(r.x, r.center.y - 7, r.width, 14);
            Box(track, t.panel2);
            Box(new Rect(track.x, track.y, track.width * k, track.height), t.accent);
            Box(new Rect(r.x + r.width * k - 12, r.center.y - 18, 24, 36), Color.Lerp(t.accent, Color.white, 0.4f));
            return v;
        }

        public static bool Toggle(Rect r, bool v, string label)
        {
            var t = ThemeManager.Current;
            Label(new Rect(r.x, r.y, r.width - 150, r.height), label, 28, t.text, TextAnchor.MiddleLeft, false, false);
            var b = new Rect(r.xMax - 140, r.y + 4, 140, r.height - 8);
            if (Button(b, Loc.Get(v ? "on" : "off"), true, 26, v ? t.good : t.panel2)) v = !v;
            return v;
        }

        /// <summary>Выбор стрелками. Возвращает -1, 0 или +1.</summary>
        public static int Cycle(Rect r, string text)
        {
            int res = 0;
            var t = ThemeManager.Current;
            if (Button(new Rect(r.x, r.y, 56, r.height), "<", true, 30)) res = -1;
            if (Button(new Rect(r.xMax - 56, r.y, 56, r.height), ">", true, 30)) res = 1;
            Box(new Rect(r.x + 62, r.y, r.width - 124, r.height), t.panel2);
            Label(new Rect(r.x + 62, r.y, r.width - 124, r.height), text, 26, t.text, TextAnchor.MiddleCenter, false, false);
            return res;
        }

        public static void Bar(Rect r, float v, Color c)
        {
            Box(r, new Color(0, 0, 0, 0.55f));
            Box(new Rect(r.x + 2, r.y + 2, (r.width - 4) * Mathf.Clamp01(v), r.height - 4), c);
        }

        public static int Tabs(Rect r, string[] names, int sel)
        {
            var t = ThemeManager.Current;
            float w = r.width / names.Length;
            for (int i = 0; i < names.Length; i++)
                if (Button(new Rect(r.x + i * w + 2, r.y, w - 4, r.height), names[i], true, 28, i == sel ? t.accent : t.panel2)) sel = i;
            return sel;
        }
    }
}
