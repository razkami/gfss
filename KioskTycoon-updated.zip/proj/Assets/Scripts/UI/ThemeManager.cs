using System;
using UnityEngine;

namespace KioskTycoon
{
    public class Theme
    {
        public string nameKey;
        public Color panel, panel2, accent, accent2, text, textDim, btnText, good, bad;
        public Color sky, lamp, neon;
    }

    /// <summary>Темы оформления интерфейса и освещения: уютная, неоновая, ретро.</summary>
    public static class ThemeManager
    {
        public static readonly Theme[] All =
        {
            new Theme
            {
                nameKey = "th.0",
                panel = new Color(0.17f, 0.12f, 0.09f, 0.94f), panel2 = new Color(0.30f, 0.20f, 0.13f, 1f),
                accent = new Color(1f, 0.66f, 0.25f), accent2 = new Color(0.92f, 0.42f, 0.30f),
                text = new Color(1f, 0.96f, 0.88f), textDim = new Color(0.78f, 0.70f, 0.60f),
                btnText = new Color(0.16f, 0.08f, 0.03f), good = new Color(0.55f, 0.92f, 0.5f), bad = new Color(1f, 0.48f, 0.42f),
                sky = new Color(0.96f, 0.78f, 0.55f), lamp = new Color(1f, 0.85f, 0.6f), neon = new Color(1f, 0.6f, 0.2f)
            },
            new Theme
            {
                nameKey = "th.1",
                panel = new Color(0.06f, 0.04f, 0.15f, 0.95f), panel2 = new Color(0.13f, 0.07f, 0.30f, 1f),
                accent = new Color(0f, 0.92f, 1f), accent2 = new Color(1f, 0.2f, 0.62f),
                text = new Color(0.92f, 0.96f, 1f), textDim = new Color(0.62f, 0.66f, 0.85f),
                btnText = new Color(0.02f, 0.02f, 0.10f), good = new Color(0.3f, 1f, 0.7f), bad = new Color(1f, 0.35f, 0.5f),
                sky = new Color(0.30f, 0.14f, 0.55f), lamp = new Color(0.85f, 0.45f, 1f), neon = new Color(0f, 0.95f, 1f)
            },
            new Theme
            {
                nameKey = "th.2",
                panel = new Color(0.96f, 0.91f, 0.79f, 0.97f), panel2 = new Color(0.86f, 0.76f, 0.56f, 1f),
                accent = new Color(0.08f, 0.52f, 0.54f), accent2 = new Color(0.85f, 0.35f, 0.2f),
                text = new Color(0.20f, 0.14f, 0.10f), textDim = new Color(0.45f, 0.38f, 0.30f),
                btnText = new Color(1f, 0.97f, 0.9f), good = new Color(0.1f, 0.5f, 0.2f), bad = new Color(0.75f, 0.15f, 0.1f),
                sky = new Color(0.68f, 0.85f, 0.82f), lamp = new Color(1f, 0.92f, 0.72f), neon = new Color(0.9f, 0.4f, 0.25f)
            },
        };

        public static int Index;
        public static Theme Current = All[0];
        public static event Action Changed;

        public static void Set(int i)
        {
            Index = Mathf.Clamp(i, 0, All.Length - 1);
            Current = All[Index];
            Changed?.Invoke();
        }
    }
}
