using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Загружает ScriptableObject-ассеты из Resources/Data. Если их нет (проект ещё не настроен
    /// через меню Kiosk/Setup), создаёт набор по умолчанию прямо в памяти.
    /// </summary>
    public static class GameDatabase
    {
        public static readonly List<ProductData> Products = new List<ProductData>();
        public static readonly List<CustomerProfile> Profiles = new List<CustomerProfile>();

        public static void Load()
        {
            Products.Clear();
            Profiles.Clear();
            Products.AddRange(Resources.LoadAll<ProductData>("Data/Products"));
            Profiles.AddRange(Resources.LoadAll<CustomerProfile>("Data/Profiles"));
            if (Products.Count == 0) Products.AddRange(CreateDefaultProducts());
            if (Profiles.Count == 0) Profiles.AddRange(CreateDefaultProfiles());
            Products.Sort((a, b) => a.unlockLevel != b.unlockLevel
                ? a.unlockLevel.CompareTo(b.unlockLevel)
                : string.CompareOrdinal(a.id, b.id));
        }

        public static ProductData Find(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            foreach (var p in Products) if (p.id == id) return p;
            return null;
        }

        static Color H(string hex)
        {
            ColorUtility.TryParseHtmlString("#" + hex, out var c);
            return c;
        }

        static ProductData P(string id, string name, ProductCategory cat, float wh, float mk, float dem, int lvl,
            string c1, string c2, Vector3 size, int box)
        {
            var p = ScriptableObject.CreateInstance<ProductData>();
            p.name = id; p.id = id; p.displayName = name; p.category = cat;
            p.wholesalePrice = wh; p.marketPrice = mk; p.baseDemand = dem; p.unlockLevel = lvl;
            p.packColor = H(c1); p.accentColor = H(c2); p.packSize = size; p.unitsPerBox = box;
            return p;
        }

        public static List<ProductData> CreateDefaultProducts()
        {
            var pack = new Vector3(0.06f, 0.09f, 0.025f);
            var bottle = new Vector3(0.06f, 0.17f, 0.06f);
            var flat = new Vector3(0.09f, 0.03f, 0.12f);
            var small = new Vector3(0.07f, 0.06f, 0.05f);
            var bag = new Vector3(0.09f, 0.12f, 0.03f);
            var news = new Vector3(0.1f, 0.14f, 0.015f);
            var C = ProductCategory.Cigarettes; var D = ProductCategory.Devices;
            var S = ProductCategory.Snacks; var Dr = ProductCategory.Drinks;
            var A = ProductCategory.Accessories; var Pr = ProductCategory.Press;
            return new List<ProductData>
            {
                // уровень витрины 0
                P("lumen", "Lumen Blue", C, 3.2f, 4.5f, 1.0f, 0, "2E6BD6", "FFFFFF", pack, 20),
                P("kedr", "Kedr Classic", C, 2.6f, 3.8f, 1.2f, 0, "2E8B57", "F4E04D", pack, 20),
                P("minty", "Minty Pop", S, 0.5f, 0.9f, 1.4f, 0, "42E6C5", "FFFFFF", flat, 30),
                P("aqua", "Aqua Lite", Dr, 0.6f, 1.2f, 1.5f, 0, "7FD6FF", "1D6FA5", bottle, 24),
                P("fizzo", "Fizzo Cola", Dr, 0.8f, 1.6f, 1.4f, 0, "E23B3B", "FFFFFF", bottle, 24),
                // уровень 1
                P("vostok", "Vostok Gold", C, 4.0f, 5.6f, 0.8f, 1, "D9A520", "2B1B0A", pack, 20),
                P("nord", "Nord Silver", C, 3.6f, 5.0f, 0.9f, 1, "B8C4D0", "2C3E50", pack, 20),
                P("dropsy", "Dropsy", S, 0.4f, 0.8f, 1.2f, 1, "FF7FC8", "FFE066", small, 30),
                P("crunchy", "Crunchy Bee", S, 1.1f, 2.0f, 1.1f, 1, "FFC933", "7A4B00", bag, 20),
                P("sparkie", "Sparkie", A, 0.7f, 1.5f, 0.9f, 1, "FF6A3D", "222222", small, 30),
                P("dnevnik", "Дневник", Pr, 0.4f, 0.9f, 0.8f, 1, "EDEDED", "333333", news, 30),
                // уровень 2
                P("vapor", "Vaporia Mini", D, 6.0f, 9.0f, 0.7f, 2, "8E5BFF", "FFFFFF", small, 12),
                P("cloudpod", "Cloud Pod", D, 5.0f, 8.0f, 0.6f, 2, "3DD5F3", "1B1B3A", small, 12),
                P("voltix", "Voltix", Dr, 1.1f, 2.2f, 1.1f, 2, "B6FF3B", "1A1A1A", bottle, 24),
                P("gorizont", "Горизонт", Pr, 1.2f, 2.4f, 0.5f, 2, "4D9DE0", "FFFFFF", news, 20),
                // уровень 3
                P("donalba", "Don Alba", C, 9.0f, 14.0f, 0.4f, 3, "5A2E1B", "D4AF37", pack, 10),
                P("giftset", "Gift Set", A, 7.0f, 12.0f, 0.4f, 3, "C0392B", "F7DC6F", bag, 10),
                P("goldlight", "Aurum Light", A, 4.0f, 8.0f, 0.4f, 3, "D4AF37", "222222", small, 12),
            };
        }

        static CustomerProfile Pf(string id, string name, float patience, int k0, int k1, int q0, int q1, float tol,
            float weight, string col, float young, float tip, params ProductCategory[] fav)
        {
            var c = ScriptableObject.CreateInstance<CustomerProfile>();
            c.name = id; c.id = id; c.displayName = name; c.patience = patience;
            c.itemKinds = new Vector2Int(k0, k1); c.quantity = new Vector2Int(q0, q1);
            c.priceTolerance = tol; c.spawnWeight = weight; c.bodyColor = H(col);
            c.youngChance = young; c.tipFactor = tip; c.favorites = fav;
            return c;
        }

        public static List<CustomerProfile> CreateDefaultProfiles()
        {
            return new List<CustomerProfile>
            {
                Pf("commuter", "Прохожий", 35, 1, 2, 1, 2, 1.25f, 1.5f, "F28C28", 0.05f, 0.04f,
                    ProductCategory.Press, ProductCategory.Snacks, ProductCategory.Drinks),
                Pf("worker", "Рабочий", 50, 1, 3, 1, 2, 1.3f, 1.2f, "3F7CAC", 0f, 0.05f, ProductCategory.Cigarettes),
                Pf("student", "Студент", 40, 1, 3, 1, 2, 1.15f, 1.0f, "9B59B6", 0.3f, 0.03f,
                    ProductCategory.Snacks, ProductCategory.Drinks, ProductCategory.Devices),
                Pf("regular", "Постоянный клиент", 70, 2, 3, 1, 2, 1.5f, 0.7f, "2E8B57", 0f, 0.12f,
                    ProductCategory.Cigarettes, ProductCategory.Accessories),
                Pf("tourist", "Турист", 35, 1, 3, 1, 3, 1.8f, 0.6f, "E84393", 0f, 0.1f,
                    ProductCategory.Accessories, ProductCategory.Drinks, ProductCategory.Press),
            };
        }
    }
}
