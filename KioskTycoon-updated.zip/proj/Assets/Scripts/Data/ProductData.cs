using UnityEngine;

namespace KioskTycoon
{
    public enum ProductCategory { Cigarettes, Devices, Snacks, Drinks, Accessories, Press }

    /// <summary>Данные товара. Вымышленные бренды, без реальных логотипов.</summary>
    [CreateAssetMenu(menuName = "Kiosk/Product", fileName = "Product")]
    public class ProductData : ScriptableObject
    {
        public string id;
        public string displayName;
        public ProductCategory category;
        [Tooltip("Закупочная цена за штуку")] public float wholesalePrice = 2f;
        [Tooltip("Рыночная цена (ориентир для покупателей)")] public float marketPrice = 3f;
        [Tooltip("Базовый вес спроса")] public float baseDemand = 1f;
        [Tooltip("Уровень витрины, на котором товар открывается")] public int unlockLevel;
        public Color packColor = Color.white;
        public Color accentColor = Color.black;
        public Vector3 packSize = new Vector3(0.07f, 0.1f, 0.025f);
        public int unitsPerBox = 20;

        public float DefaultPrice => Mathf.Round(marketPrice * 1.15f * 10f) / 10f;
        public bool AgeRestricted => category == ProductCategory.Cigarettes || category == ProductCategory.Devices;
    }
}
