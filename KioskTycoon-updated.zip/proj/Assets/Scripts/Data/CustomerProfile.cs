using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Параметры типа покупателя: терпение, предпочтения, чувствительность к цене.</summary>
    [CreateAssetMenu(menuName = "Kiosk/Customer Profile", fileName = "Customer")]
    public class CustomerProfile : ScriptableObject
    {
        public string id;
        public string displayName;
        public float patience = 45f;
        public Vector2Int itemKinds = new Vector2Int(1, 3);
        public Vector2Int quantity = new Vector2Int(1, 2);
        [Tooltip("Во сколько раз покупатель готов переплатить относительно рыночной цены")]
        public float priceTolerance = 1.3f;
        public float spawnWeight = 1f;
        public Color bodyColor = Color.gray;
        public ProductCategory[] favorites;
        public float favoriteBoost = 3f;
        [Range(0, 1)] public float youngChance;
        public float tipFactor = 0.05f;
    }
}
