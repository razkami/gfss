using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Закупки, доставка коробок на склад, цены продажи, возврат товаров на полки.</summary>
    public class StockManager : MonoBehaviour
    {
        public static StockManager I;
        public const float DeliverySeconds = 18f;
        public readonly List<DeliveryBox> Boxes = new List<DeliveryBox>();
        readonly List<PhysicalProduct> looseGoods = new List<PhysicalProduct>();
        SaveData D => GameSession.Data;
        bool warnedFull;

        void Awake() { I = this; }

        /// <summary>Вызывается после построения мира: расставляет сохранённые коробки.</summary>
        public void Init()
        {
            foreach (var b in D.boxes) SpawnBox(GameDatabase.Find(b.id), b.qty, b.opened);
        }

        public void InitLooseGoods()
        {
            foreach (var saved in D.looseGoods)
            {
                var product = GameDatabase.Find(saved.id);
                if (product == null) continue;
                var item = PhysicalProduct.Create(product, saved.position, product.packSize, false);
                RegisterLoose(item);
                if (saved.opened) item.RestoreOpenedState();
                if (CashRegister.I != null && CashRegister.I.TryPlaceOnCounter(item)) continue;
                item.Drop();
            }
        }

        public void RegisterLoose(PhysicalProduct item)
        {
            if (item != null && !looseGoods.Contains(item)) looseGoods.Add(item);
        }

        public void RemoveLoose(PhysicalProduct item) { looseGoods.Remove(item); }

        public int LooseCount(ProductData p)
        {
            int count = 0;
            foreach (var item in looseGoods) if (item != null && item.product == p) count++;
            return count;
        }

        public int Capacity => Mathf.Min(UpgradeCatalog.StorageSlots[D.Up(UpgradeType.Storage)], KioskBuilder.I.StoragePoints.Count);

        public int FreeSlot()
        {
            for (int i = 0; i < Capacity; i++)
            {
                bool used = false;
                foreach (var b in Boxes) if (b.slot == i) { used = true; break; }
                if (!used) return i;
            }
            return -1;
        }

        public DeliveryBox SpawnBox(ProductData p, int qty, bool opened = false)
        {
            if (p == null || qty <= 0) return null;
            int s = FreeSlot();
            if (s < 0) return null;
            var b = DeliveryBox.Create(p, qty, opened);
            b.slot = s;
            b.PlaceKinematic(KioskBuilder.I.StoragePoints[s]);
            Boxes.Add(b);
            return b;
        }

        /// <summary>Коробка, отпущенная рядом с поддоном, встаёт на ближайший свободный поддон.</summary>
        public bool TrySnapToStorage(DeliveryBox box)
        {
            if (box == null || KioskBuilder.I == null) return false;
            int best = -1;
            float bestD = 0.6f * 0.6f;
            for (int i = 0; i < Capacity; i++)
            {
                bool used = false;
                foreach (var other in Boxes) if (other != null && other != box && other.slot == i) { used = true; break; }
                if (used) continue;
                Vector3 p = KioskBuilder.I.StoragePoints[i];
                Vector3 d = box.transform.position - p;
                d.y = 0f;
                if (d.sqrMagnitude < bestD) { bestD = d.sqrMagnitude; best = i; }
            }
            if (best < 0) return false;
            box.slot = best;
            box.PlaceKinematic(KioskBuilder.I.StoragePoints[best]);
            AudioManager.Play(Sfx.Place, 0.6f);
            return true;
        }

        public void RemoveBox(DeliveryBox b) { Boxes.Remove(b); if (b != null) Destroy(b.gameObject); }

        public void StoreBox(DeliveryBox b, PlayerContext p)
        {
            int s = FreeSlot();
            if (s < 0) { Toast.Warn(Loc.Get("t.storefull")); return; }
            b.Detach();
            b.slot = s;
            b.PlaceKinematic(KioskBuilder.I.StoragePoints[s]);
            p.heldBox = null;
            AudioManager.Play(Sfx.Box);
        }

        /// <summary>После улучшения мир перестроен — ставим коробки на новые точки.</summary>
        public void RelocateBoxes()
        {
            foreach (var b in Boxes)
                if (b != null && b.slot >= 0 && b.slot < KioskBuilder.I.StoragePoints.Count)
                    b.PlaceKinematic(KioskBuilder.I.StoragePoints[b.slot]);
        }

        // ---------- закупки ----------
        public float BoxCost(ProductData p) => p.unitsPerBox * p.wholesalePrice * EconomyManager.I.WholesaleMult;

        public bool Order(ProductData p, int boxes)
        {
            float cost = BoxCost(p) * boxes;
            if (!EconomyManager.I.Spend(cost)) { Toast.Warn(Loc.Get("t.nomoney")); return false; }
            for (int i = 0; i < boxes; i++)
                D.pending.Add(new BoxEntry { id = p.id, qty = p.unitsPerBox, eta = DeliverySeconds + i * 3f });
            AudioManager.Play(Sfx.Cash);
            Toast.Push(Loc.F("t.ordered", p.displayName, boxes));
            return true;
        }

        void Update()
        {
            // Editor script reloads can clear static session state while a scene stays alive.
            if (GameSession.Data == null) GameSession.EnsureData();
            if (D.pending == null) D.Sanitize();
            for (int i = D.pending.Count - 1; i >= 0; i--)
            {
                var o = D.pending[i];
                o.eta -= Time.deltaTime;
                if (o.eta > 0f) continue;
                var p = GameDatabase.Find(o.id);
                if (p == null) { D.pending.RemoveAt(i); continue; }
                if (SpawnBox(p, o.qty) != null)
                {
                    D.pending.RemoveAt(i);
                    warnedFull = false;
                    AudioManager.Play(Sfx.Bell);
                    Toast.Good(Loc.F("t.delivered", p.displayName, o.qty));
                }
                else if (!warnedFull) { warnedFull = true; Toast.Warn(Loc.Get("t.storefull")); }
            }
        }

        // ---------- цены и остатки ----------
        public float GetPrice(ProductData p)
        {
            foreach (var e in D.prices) if (e.id == p.id) return e.price;
            return p.DefaultPrice;
        }

        public void SetPrice(ProductData p, float price)
        {
            price = Mathf.Clamp(Mathf.Round(price * 10f) / 10f, 0.1f, 999f);
            foreach (var e in D.prices) if (e.id == p.id) { e.price = price; return; }
            D.prices.Add(new PriceEntry { id = p.id, price = price });
        }

        public int OnShelves(ProductData p)
        {
            int n = 0;
            foreach (var e in D.shelves) if (e != null) n += e.CountOf(p.id);
            return n;
        }

        public int InStorage(ProductData p)
        {
            int n = 0;
            foreach (var b in Boxes) if (b.product == p) n += b.qty;
            return n;
        }

        /// <summary>Кладёт товар обратно на полки. Лишнее (если полки полны) появляется на полу у игрока. Возвращает, сколько легло на полки.</summary>
        public int ReturnGoods(ProductData p, int n)
        {
            int placed = RestockToShelves(p, n);
            for (int i = placed; i < n; i++)
            {
                Vector3 pos = ItemPhysics.RecoveryPoint() + new Vector3((i % 4) * 0.12f - 0.18f, 0.1f * (i / 4), 0f);
                var item = PhysicalProduct.Create(p, pos, p.packSize, false);
                RegisterLoose(item);
                item.Drop();
            }
            return placed;
        }

        public int RestockToShelves(ProductData p, int n)
        {
            int placed = 0;
            if (KioskBuilder.I == null) return 0;
            foreach (var s in KioskBuilder.I.Slots)
            {
                if (placed >= n) break;
                int mv = Mathf.Min(s.Capacity - s.Count, n - placed);
                if (mv <= 0) continue;
                s.Entry.GetOrAdd(p.id).count += mv;
                s.Entry.SyncLegacy();
                s.Refresh();
                placed += mv;
            }
            return placed;
        }

        /// <summary>Возвращает товары из рук на полки (где есть место).</summary>
        public void ReturnTray(PlayerContext ctx)
        {
            foreach (var kv in new List<KeyValuePair<ProductData, int>>(ctx.Tray))
            {
                int left = kv.Value;
                foreach (var s in KioskBuilder.I.Slots)
                {
                    if (left <= 0) break;
                    int space = s.Capacity - s.Count;
                    int mv = Mathf.Min(space, left);
                    if (mv > 0) { s.Entry.GetOrAdd(kv.Key.id).count += mv; s.Entry.SyncLegacy(); left -= mv; s.Refresh(); }
                }
            }
            if (ctx.Tray.Count > 0) AudioManager.Play(Sfx.Place);
            ctx.Tray.Clear();
        }

        // ---------- сохранение ----------
        public static void SaveNow()
        {
            if (I != null)
            {
                D_Boxes();
                D_LooseGoods();
            }
            GameSession.Save();
        }

        static void D_Boxes()
        {
            var d = GameSession.Data;
            d.boxes.Clear();
            foreach (var b in I.Boxes) if (b != null && b.qty > 0) d.boxes.Add(new BoxEntry { id = b.product.id, qty = b.qty, opened = b.opened });
        }

        static void D_LooseGoods()
        {
            var d = GameSession.Data;
            d.looseGoods.Clear();
            foreach (var item in I.looseGoods)
                if (item != null && !item.IsUsing)
                    d.looseGoods.Add(new LooseProductEntry { id = item.product.id, position = item.transform.position, opened = item.opened });
        }
    }
}
