using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Картонная коробка с товаром. Закрытую можно переносить (ЛКМ), E — открыть. В открытой коробке
    /// видны упаковки: ЛКМ достаёт по одной штуке в руки, чтобы разложить на полках или отнести на кассу.
    /// Когда коробка опустела, она складывается и исчезает.
    /// </summary>
    public class DeliveryBox : Interactable
    {
        const float W = 0.36f, H = 0.35f, D = 0.30f, Wall = 0.012f;

        public ProductData product;
        public int qty;
        public int slot = -1;
        public bool opened;

        BoxCollider col;
        Rigidbody body;
        Transform flapL, flapR, contents;
        GameObject tape;
        float flapAngle;
        float emptyTimer = -1f;
        int visibleCount;
        int gridX, gridZ, layersMax;

        public static DeliveryBox Create(ProductData p, int qty, bool opened = false)
        {
            var go = new GameObject("Box_" + p.id);
            var b = go.AddComponent<DeliveryBox>();
            b.product = p;
            b.qty = qty;
            b.opened = opened;
            b.BuildModel();

            b.col = go.AddComponent<BoxCollider>();
            b.col.center = new Vector3(0f, H / 2f, 0f);
            b.col.size = new Vector3(W, H, D);
            b.col.sharedMaterial = ItemPhysics.Material;
            b.body = go.AddComponent<Rigidbody>();
            b.body.mass = 0.8f + qty * 0.05f;
            b.body.isKinematic = true;
            b.body.drag = 0.4f;
            b.body.angularDrag = 3f;
            go.AddComponent<ItemBody>();
            b.flapAngle = opened ? 1f : 0f;
            b.ApplyFlaps();
            b.RebuildContents();
            return b;
        }

        void BuildModel()
        {
            var card = Mats.Solid(new Color(0.78f, 0.6f, 0.38f), 0.2f);
            var inner = Mats.Solid(new Color(0.62f, 0.46f, 0.28f), 0.15f);
            Prim.Cube(transform, "Bottom", new Vector3(0f, 0.01f, 0f), new Vector3(W, 0.02f, D), inner, false);
            Prim.Cube(transform, "Wall front", new Vector3(0f, H / 2f, D / 2f - Wall / 2f), new Vector3(W, H, Wall), card, false);
            Prim.Cube(transform, "Wall back", new Vector3(0f, H / 2f, -D / 2f + Wall / 2f), new Vector3(W, H, Wall), card, false);
            Prim.Cube(transform, "Wall left", new Vector3(-W / 2f + Wall / 2f, H / 2f, 0f), new Vector3(Wall, H, D), card, false);
            Prim.Cube(transform, "Wall right", new Vector3(W / 2f - Wall / 2f, H / 2f, 0f), new Vector3(Wall, H, D), card, false);

            flapL = new GameObject("Flap L").transform;
            flapL.SetParent(transform, false);
            flapL.localPosition = new Vector3(-W / 2f, H, 0f);
            Prim.Cube(flapL, "Flap", new Vector3(W / 4f, 0.004f, 0f), new Vector3(W / 2f, 0.008f, D), card, false);
            flapR = new GameObject("Flap R").transform;
            flapR.SetParent(transform, false);
            flapR.localPosition = new Vector3(W / 2f, H, 0f);
            Prim.Cube(flapR, "Flap", new Vector3(-W / 4f, 0.004f, 0f), new Vector3(W / 2f, 0.008f, D), inner, false);

            tape = Prim.Cube(transform, "Packing tape", new Vector3(0f, H + 0.011f, 0f), new Vector3(0.055f, 0.004f, D + 0.002f),
                Mats.Solid(new Color(0.9f, 0.77f, 0.48f), 0.15f), false);
            Prim.Cube(transform, "Label", new Vector3(0f, 0.2f, D / 2f + 0.001f), new Vector3(0.2f, 0.12f, 0.002f), Mats.ProductPack(product), false);
            Prim.Cube(transform, "Fragile mark", new Vector3(0.115f, 0.2f, D / 2f + 0.002f), new Vector3(0.025f, 0.07f, 0.003f),
                Mats.Emissive(product.accentColor, 0.35f), false);
            contents = new GameObject("Contents").transform;
            contents.SetParent(transform, false);
        }

        void ApplyFlaps()
        {
            float a = Mathf.SmoothStep(0f, 1f, flapAngle) * 118f;
            if (flapL != null) flapL.localRotation = Quaternion.Euler(0f, 0f, a);
            if (flapR != null) flapR.localRotation = Quaternion.Euler(0f, 0f, -a);
            if (tape != null) tape.SetActive(flapAngle < 0.05f);
        }

        // ---------- содержимое ----------
        void RebuildContents()
        {
            if (contents == null) return;
            for (int i = contents.childCount - 1; i >= 0; i--) Destroy(contents.GetChild(i).gameObject);
            visibleCount = 0;
            if (!opened || qty <= 0) return;

            var s = product.packSize;
            float innerW = W - 2f * Wall - 0.01f, innerD = D - 2f * Wall - 0.01f;
            gridX = Mathf.Max(1, Mathf.FloorToInt(innerW / (s.x + 0.006f)));
            gridZ = Mathf.Max(1, Mathf.FloorToInt(innerD / (s.z + 0.006f)));
            layersMax = Mathf.Max(1, Mathf.FloorToInt((H - 0.04f) / s.y));
            visibleCount = Mathf.Min(qty, gridX * gridZ * layersMax);
            var mat = Mats.ProductPack(product);
            float cw = innerW / gridX, cd = innerD / gridZ;
            for (int i = 0; i < visibleCount; i++)
            {
                Vector3 lp = PackLocal(i, s, cw, cd, innerW, innerD);
                Prim.Cube(contents, "Pack", lp, s, mat, false);
            }
        }

        Vector3 PackLocal(int i, Vector3 s, float cw, float cd, float innerW, float innerD)
        {
            int per = gridX * gridZ;
            int layer = i / per, idx = i % per;
            int cx = idx % gridX, cz = idx / gridX;
            return new Vector3(-innerW / 2f + (cx + 0.5f) * cw, 0.02f + layer * s.y + s.y / 2f, -innerD / 2f + (cz + 0.5f) * cd);
        }

        /// <summary>Достаёт одну упаковку из открытой коробки; она появляется на месте верхней и сразу берётся в руки.</summary>
        public PhysicalProduct TakeOne()
        {
            if (!opened || qty <= 0 || visibleCount <= 0) return null;
            var s = product.packSize;
            float innerW = W - 2f * Wall - 0.01f, innerD = D - 2f * Wall - 0.01f;
            Vector3 pos = transform.TransformPoint(PackLocal(visibleCount - 1, s, innerW / gridX, innerD / gridZ, innerW, innerD));
            qty--;
            var item = PhysicalProduct.Create(product, pos, s, false);
            if (StockManager.I != null) StockManager.I.RegisterLoose(item);
            RebuildContents();
            if (qty <= 0) emptyTimer = 1.0f;
            return item;
        }

        void Update()
        {
            float target = opened ? 1f : 0f;
            if (!Mathf.Approximately(flapAngle, target))
            {
                flapAngle = Mathf.MoveTowards(flapAngle, target, Time.deltaTime * 4f);
                ApplyFlaps();
            }
            if (emptyTimer >= 0f)
            {
                emptyTimer -= Time.deltaTime;
                transform.localScale = Vector3.one * Mathf.Clamp01(emptyTimer / 0.5f + 0.0001f);
                if (emptyTimer <= 0f && StockManager.I != null) StockManager.I.RemoveBox(this);
            }
        }

        public bool IsHeld => false;     // коробки переносятся ItemGrabber напрямую, без «руки»
        public bool CanTakeItems => opened && qty > 0;

        public override string Prompt(PlayerContext p)
        {
            if (!opened) return Loc.F("p.box.open", product.displayName, qty);
            if (qty <= 0) return null;
            return Loc.F("p.box.take", product.displayName, qty);
        }

        public override void Interact(PlayerContext p)
        {
            if (opened || product == null || qty <= 0) return;
            opened = true;
            RebuildContents();
            AudioManager.Play(Sfx.BoxOpen);
            Toast.Good(Loc.F("t.boxopened", product.displayName, qty));
        }

        // ---------- перенос ----------
        /// <summary>Снимает коробку с руки (старый путь, оставлен для совместимости с ShelfSlot).</summary>
        public void Detach()
        {
            transform.SetParent(StockManager.I.transform, true);
            col.enabled = true;
            if (body != null) body.isKinematic = true;
        }

        public void BeginWorldDrag()
        {
            slot = -1;
            transform.SetParent(null, true);
            if (body == null) body = GetComponent<Rigidbody>();
            if (body != null) body.isKinematic = true;
            if (col != null) col.enabled = true;
            AudioManager.Play(Sfx.Pickup, 0.7f);
        }

        public void EndWorldDrag()
        {
            if (body == null) body = GetComponent<Rigidbody>();
            if (body != null) ItemPhysics.Activate(body);
            AudioManager.Play(Sfx.Place, 0.6f);
        }

        /// <summary>Ставит коробку неподвижно в точку склада (на поддон).</summary>
        public void PlaceKinematic(Vector3 position)
        {
            if (body == null) body = GetComponent<Rigidbody>();
            if (body != null) body.isKinematic = true;
            transform.SetParent(StockManager.I != null ? StockManager.I.transform : null, true);
            transform.position = position;
            transform.rotation = Quaternion.identity;
        }
    }
}
