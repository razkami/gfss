using UnityEngine;

namespace KioskTycoon
{
    /// <summary>A visible, physics-backed stock unit or customer order item.</summary>
    public class PhysicalProduct : Interactable, IWorldLabel
    {
        public ProductData product;
        public ShelfSlot sourceShelf;
        public bool customerOrder;
        public bool inRegisterZone;
        public bool isScanned;
        public bool opened;
        public bool IsUsing { get; private set; }
        public Rigidbody Body { get; private set; }
        public BoxCollider Collider { get; private set; }
        public bool IsHeld { get; private set; }
        GameObject openFlap;
        float useTimer;
        Vector3 useStartPosition;

        public static PhysicalProduct Create(ProductData product, Vector3 position, Vector3 size, bool customerOrder)
        {
            var go = new GameObject(customerOrder ? "OrderItem_" + product.id : "StockItem_" + product.id);
            go.transform.position = position;
            go.transform.localScale = size;
            go.AddComponent<MeshFilter>().sharedMesh = PrimitiveMesh.Cube;
            go.AddComponent<MeshRenderer>().sharedMaterial = Mats.ProductPack(product);
            var item = go.AddComponent<PhysicalProduct>();
            item.product = product;
            item.customerOrder = customerOrder;
            item.Collider = go.AddComponent<BoxCollider>();
            item.Body = go.AddComponent<Rigidbody>();
            ItemPhysics.Prepare(go, item.Collider, item.Body, 0.12f);   // трение, толщина коллайдера, страховка от падения сквозь пол
            ProductModels.Decorate(go, product);
            return item;
        }

        void Awake()
        {
            if (Body == null) Body = GetComponent<Rigidbody>();
            if (Collider == null) Collider = GetComponent<BoxCollider>();
        }

        void OnDestroy()
        {
            WorldLabels.Remove(this);
            if (StockManager.I != null) StockManager.I.RemoveLoose(this);
            if (CashRegister.I != null) CashRegister.I.RemoveFromCounter(this);
        }

        void Update()
        {
            if (!IsUsing) return;
            useTimer += Time.deltaTime;
            float t = Mathf.Clamp01(useTimer / 0.55f);
            var cam = PlayerController.I != null ? PlayerController.I.Cam : null;
            if (cam != null)
            {
                Vector3 target = cam.transform.position + cam.transform.forward * 0.48f + cam.transform.up * -0.16f;
                transform.position = Vector3.Lerp(useStartPosition, target, t);
                transform.rotation = Quaternion.Slerp(transform.rotation, cam.transform.rotation * Quaternion.Euler(20f, 0f, 0f), t);
            }
            transform.localScale = Vector3.one * Mathf.Lerp(1f, 0.08f, t);
            if (useTimer < 0.55f) return;
            Toast.Good(Loc.F("t.productUsed", product.displayName));
            Destroy(gameObject);
        }

        public override string Prompt(PlayerContext context)
        {
            if (IsUsing || product == null) return null;
            string price = UIKit.Money(StockManager.I != null ? StockManager.I.GetPrice(product) : product.marketPrice);
            if (inRegisterZone) return Loc.F(isScanned ? "p.item.scanned" : "p.item.scan", product.displayName, price);
            if (customerOrder) return null;
            return Loc.F(opened ? "p.product.use2" : "p.product.info", product.displayName, price);
        }

        // ---------- ценник над товаром в зоне кассы ----------
        public Vector3 LabelPos => transform.position + Vector3.up * ((Collider != null ? Collider.bounds.extents.y : 0.05f) + 0.07f);
        public float LabelMaxDist => 4f;

        public void DrawLabel(Vector2 sp)
        {
            if (!inRegisterZone || product == null || IsUsing) return;
            var t = ThemeManager.Current;
            string price = UIKit.Money(StockManager.I != null ? StockManager.I.GetPrice(product) : product.marketPrice);
            UIKit.Box(new Rect(sp.x - 95, sp.y - 24, 190, 24), new Color(0f, 0f, 0f, 0.6f));
            UIKit.Label(new Rect(sp.x - 95, sp.y - 24, 190, 24), (isScanned ? "OK  " : "") + product.displayName + "  " + price,
                17, isScanned ? t.good : t.text, TextAnchor.MiddleCenter, true, false);
        }

        public override void Interact(PlayerContext context)
        {
            if (customerOrder || inRegisterZone || IsUsing || product == null) return;
            if (!opened)
            {
                opened = true;
                ShowOpenPackage();
                Toast.Good(Loc.F("t.productOpened", product.displayName));
                AudioManager.Play(Sfx.Box);
                return;
            }

            if (sourceShelf != null) sourceShelf.RemovePhysicalItem(this);
            else CashRegister.I?.RemoveFromCounter(this);
            inRegisterZone = false;
            IsHeld = false;
            transform.SetParent(null, true);
            Body.isKinematic = true;
            useStartPosition = transform.position;
            useTimer = 0f;
            IsUsing = true;
        }

        void ShowOpenPackage()
        {
            if (openFlap != null) return;
            openFlap = Prim.Cube(transform, "Opened wrapper flap", new Vector3(0f, 0.54f, 0.15f),
                new Vector3(0.92f, 0.035f, 0.72f), Mats.Solid(product.accentColor, 0.28f), false);
            openFlap.transform.localRotation = Quaternion.Euler(-58f, 0f, 0f);
            Prim.Cube(transform, "Wrapper inner foil", new Vector3(0f, 0.5f, -0.07f),
                new Vector3(0.78f, 0.018f, 0.52f), Mats.Solid(new Color(0.78f, 0.8f, 0.82f), 0.55f, 0.3f), false);
        }

        public void RestoreOpenedState()
        {
            opened = true;
            ShowOpenPackage();
        }

        public void Grab()
        {
            if (customerOrder || IsHeld) return;
            IsHeld = true;
            inRegisterZone = false;
            WorldLabels.Remove(this);
            CashRegister.I?.RemoveFromCounter(this);
            if (sourceShelf != null) sourceShelf.RemovePhysicalItem(this);
            StockManager.I?.RegisterLoose(this);
            transform.SetParent(null, true);
            Body.isKinematic = true;
            AudioManager.Play(Sfx.Pickup, 0.7f);
        }

        public void Drop()
        {
            IsHeld = false;
            Body.isKinematic = false;
            Body.interpolation = RigidbodyInterpolation.Interpolate;
            Body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            Body.velocity = Vector3.zero;
            Body.angularVelocity = Vector3.zero;
            AudioManager.Play(Sfx.Place, 0.6f);
        }

        public void Consume()
        {
            StockManager.I?.RemoveLoose(this);
            CashRegister.I?.RemoveFromCounter(this);
            Destroy(gameObject);
        }

        public void RestOnCounter(Vector3 position)
        {
            transform.position = position;
            transform.rotation = Quaternion.identity;
            IsHeld = false;
            inRegisterZone = true;
            Body.isKinematic = true;
            WorldLabels.Add(this);
        }

        // Keeps the project independent of primitive GameObjects and their hidden colliders.
        static class PrimitiveMesh
        {
            static Mesh cube;
            public static Mesh Cube
            {
                get
                {
                    if (cube != null) return cube;
                    var temp = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    cube = temp.GetComponent<MeshFilter>().sharedMesh;
                    UnityEngine.Object.Destroy(temp);
                    return cube;
                }
            }
        }
    }
}
