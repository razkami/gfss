using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Формы товаров: у всех один кубический коллайдер (устойчиво лежат и ставятся), но на вид это
    /// бутылки, пачки, пакетики, гаджеты и газеты. Размеры детей заданы в долях размера упаковки.
    /// </summary>
    public static class ProductModels
    {
        public static void Decorate(GameObject go, ProductData p)
        {
            if (go == null || p == null) return;
            var t = go.transform;
            var accent = Mats.Solid(p.accentColor, 0.45f);
            var dark = Mats.Solid(Color.Lerp(p.packColor, Color.black, 0.65f), 0.4f);
            switch (p.category)
            {
                case ProductCategory.Drinks:
                {
                    var mr = go.GetComponent<MeshRenderer>();
                    if (mr != null) mr.enabled = false;           // вместо куба — бутылка
                    var body = Mats.ProductPack(p);
                    Prim.Shape(PrimitiveType.Cylinder, t, "Bottle", new Vector3(0f, -0.1f, 0f), new Vector3(1f, 0.4f, 1f), body);
                    Prim.Shape(PrimitiveType.Cylinder, t, "Neck", new Vector3(0f, 0.37f, 0f), new Vector3(0.45f, 0.07f, 0.45f), body);
                    Prim.Shape(PrimitiveType.Cylinder, t, "Cap", new Vector3(0f, 0.47f, 0f), new Vector3(0.52f, 0.03f, 0.52f), accent);
                    break;
                }
                case ProductCategory.Snacks:
                    Prim.Shape(PrimitiveType.Cube, t, "Crimp top", new Vector3(0f, 0.46f, 0f), new Vector3(1.02f, 0.08f, 1.15f), accent);
                    Prim.Shape(PrimitiveType.Cube, t, "Crimp bottom", new Vector3(0f, -0.46f, 0f), new Vector3(1.02f, 0.08f, 1.15f), accent);
                    break;
                case ProductCategory.Cigarettes:
                    Prim.Shape(PrimitiveType.Cube, t, "Lid line", new Vector3(0f, 0.22f, 0f), new Vector3(1.01f, 0.025f, 1.04f), dark);
                    Prim.Shape(PrimitiveType.Cube, t, "Foil strip", new Vector3(0f, 0.5f, 0f), new Vector3(0.9f, 0.02f, 0.8f), Mats.Metal(new Color(0.85f, 0.85f, 0.88f)));
                    break;
                case ProductCategory.Devices:
                    Prim.Shape(PrimitiveType.Cube, t, "Glow screen", new Vector3(0f, 0.15f, 0.505f), new Vector3(0.45f, 0.25f, 0.02f), Mats.Emissive(p.accentColor, 1.2f));
                    Prim.Shape(PrimitiveType.Cube, t, "Cap", new Vector3(0f, 0.5f, 0f), new Vector3(0.6f, 0.06f, 0.7f), dark);
                    break;
                case ProductCategory.Press:
                    Prim.Shape(PrimitiveType.Cube, t, "Fold", new Vector3(0f, 0f, 0f), new Vector3(1.02f, 0.02f, 1.02f), dark);
                    break;
                default:
                    Prim.Shape(PrimitiveType.Cube, t, "Ribbon", new Vector3(0f, 0f, 0f), new Vector3(1.02f, 0.14f, 1.1f), accent);
                    break;
            }
        }
    }
}
