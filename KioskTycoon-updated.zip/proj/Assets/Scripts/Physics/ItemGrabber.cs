using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Перенос предметов мышью. Зажать ЛКМ на товаре или коробке — взять, держать — перемещать,
    /// колёсико — расстояние, отпустить — поставить. Предмет не проходит сквозь стены и оборудование.
    /// Короткий клик по товару в зоне кассы — сканирование, удержание — забрать товар с кассы обратно.
    /// </summary>
    public class ItemGrabber : MonoBehaviour
    {
        public const float ReachDistance = 3.2f;
        const float MinHoldDistance = 0.75f, MaxHoldDistance = 2.8f, HoldToPickTime = 0.28f;
        static readonly Collider[] overlap = new Collider[24];

        Camera cam;
        float heldDistance = 1.6f;
        Vector3 lastValid;
        Vector3 extents;
        PhysicalProduct pendingItem;
        float pendingTime, pendingDistance;

        public PhysicalProduct HeldProduct { get; private set; }
        public DeliveryBox HeldBox { get; private set; }
        public bool IsCarrying => HeldProduct != null || HeldBox != null;

        public void Init(Camera c) { cam = c; }

        public void Tick(bool blocked)
        {
            if (cam == null) return;
            if (blocked)
            {
                pendingItem = null;
                if (IsCarrying) Release();
                return;
            }

            if (HeldProduct != null && HeldProduct.IsUsing)
            {
                // предмет уже «используется» (анимация к камере) — просто отпускаем ссылку
                if (!Input.GetMouseButton(0)) HeldProduct = null;
                return;
            }

            if (Input.GetMouseButtonDown(0) && !IsCarrying) TryBegin();

            if (pendingItem != null)
            {
                if (!Input.GetMouseButton(0))
                {
                    CashRegister.I?.ScanItem(pendingItem);
                    pendingItem = null;
                }
                else if (Time.time - pendingTime > HoldToPickTime)
                {
                    var item = pendingItem;
                    pendingItem = null;
                    BeginProduct(item, pendingDistance, true);
                }
            }

            if (!IsCarrying) return;
            Drag();
            if (!Input.GetMouseButton(0)) Release();
        }

        void TryBegin()
        {
            var ray = cam.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
            var hits = Physics.RaycastAll(ray, ReachDistance);
            System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
            PhysicalProduct item = null;
            DeliveryBox box = null;
            float distance = ReachDistance;
            foreach (var candidate in hits)
            {
                var p = candidate.collider.GetComponentInParent<PhysicalProduct>();
                var b = candidate.collider.GetComponentInParent<DeliveryBox>();
                if (p != null || b != null)
                {
                    item = p; box = b; distance = candidate.distance;
                    break;
                }
                if (!candidate.collider.isTrigger && candidate.collider.GetComponentInParent<ShelfSlot>() == null) break;
            }
            if (item == null && box == null) return;

            if (item != null)
            {
                if (item.customerOrder || item.inRegisterZone)
                {
                    pendingItem = item;           // клик — скан, удержание — забрать
                    pendingTime = Time.time;
                    pendingDistance = distance;
                }
                else BeginProduct(item, distance, false);
                return;
            }

            if (box != null && !box.IsHeld)
            {
                // открытая коробка: ЛКМ достаёт одну упаковку (Shift+ЛКМ — перенести всю коробку)
                if (box.CanTakeItems && !Binds.Held(GameAction.Run))
                {
                    var taken = box.TakeOne();
                    if (taken != null) BeginProduct(taken, Mathf.Max(distance, 0.9f), false);
                    return;
                }
                heldDistance = Mathf.Clamp(distance, MinHoldDistance, MaxHoldDistance);
                box.BeginWorldDrag();
                HeldBox = box;
                var col = box.GetComponent<Collider>();
                extents = col != null ? col.bounds.extents : Vector3.one * 0.15f;
                lastValid = box.transform.position;
            }
        }

        void BeginProduct(PhysicalProduct item, float distance, bool fromCounter)
        {
            if (item == null) return;
            if (fromCounter) CashRegister.I?.ReleaseFromCounter(item);
            heldDistance = Mathf.Clamp(distance, MinHoldDistance, MaxHoldDistance);
            item.Grab();
            HeldProduct = item;
            extents = item.Collider != null ? item.Collider.bounds.extents : Vector3.one * 0.05f;
            lastValid = item.transform.position;
        }

        void Drag()
        {
            Transform moving = HeldProduct != null ? HeldProduct.transform : HeldBox != null ? HeldBox.transform : null;
            if (moving == null) return;
            Collider own = HeldProduct != null ? (Collider)HeldProduct.Collider : HeldBox.GetComponent<Collider>();

            heldDistance = Mathf.Clamp(heldDistance + Input.GetAxis("Mouse ScrollWheel") * 1.5f, MinHoldDistance, MaxHoldDistance);
            Vector3 from = moving.position;
            Vector3 desired = cam.transform.position + cam.transform.forward * heldDistance;
            Vector3 delta = desired - from;

            if (delta.sqrMagnitude > 0.0001f)
            {
                float radius = Mathf.Clamp(Mathf.Max(extents.x, extents.y, extents.z), 0.05f, 0.18f);
                var hits = Physics.SphereCastAll(from, radius, delta.normalized, delta.magnitude, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore);
                System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
                foreach (var hit in hits)
                {
                    if (hit.collider == own || hit.collider.transform.IsChildOf(moving)) continue;
                    if (hit.collider.GetComponentInParent<CharacterController>() != null) continue;
                    if (hit.distance < 0.025f) continue;    // первый кадр: выбираемся с поверхности, на которой лежал предмет
                    desired = from + delta.normalized * Mathf.Max(0f, hit.distance - radius - 0.035f);
                    break;
                }
            }

            float speed = Mathf.Max(5f, (desired - from).magnitude * 14f);
            Vector3 next = Vector3.MoveTowards(from, desired, speed * Time.deltaTime);

            // страховка: не входим в стены и оборудование, даже если игрок резко повернулся
            Quaternion rot = moving.rotation;
            Vector3 half = extents * 0.9f;
            Vector3 centerOffset = own != null ? own.bounds.center - moving.position : Vector3.zero;
            bool nextBlocked = ItemPhysics.IsBlocked(next + centerOffset, half, rot, moving);
            if (nextBlocked && !ItemPhysics.IsBlocked(from + centerOffset, half, rot, moving)) next = lastValid;
            else if (!nextBlocked) lastValid = next;
            moving.position = next;

            // предмет остаётся ровным и повёрнут лицом к игроку
            float yaw = transform.eulerAngles.y + 180f;
            moving.rotation = Quaternion.Slerp(moving.rotation, Quaternion.Euler(0f, yaw, 0f), Time.deltaTime * 12f);
        }

        void Release()
        {
            if (HeldProduct != null)
            {
                var placed = HeldProduct;
                HeldProduct = null;
                if (!placed.IsUsing)
                {
                    if (CashRegister.I != null && CashRegister.I.TryPlaceOnCounter(placed)) { }
                    else
                    {
                        var slot = FindNearbyShelf(placed.transform.position, placed.product);
                        if (slot != null && slot.PlacePhysicalItem(placed)) { }
                        else
                        {
                            ItemPhysics.SnapToSurface(placed.transform, placed.Collider);
                            placed.Drop();
                        }
                    }
                }
            }
            if (HeldBox != null)
            {
                var box = HeldBox;
                HeldBox = null;
                if (!StockManager.I.TrySnapToStorage(box))
                {
                    ItemPhysics.SnapToSurface(box.transform, box.GetComponent<Collider>());
                    box.EndWorldDrag();
                }
            }
        }

        static ShelfSlot FindNearbyShelf(Vector3 position, ProductData product)
        {
            ShelfSlot best = null;
            float bestDistance = float.MaxValue;
            int n = Physics.OverlapSphereNonAlloc(position, 0.5f, overlap);
            for (int i = 0; i < n; i++)
            {
                var slot = overlap[i].GetComponentInParent<ShelfSlot>();
                if (slot == null || !slot.CanAccept(product)) continue;
                float distance = (slot.transform.position - position).sqrMagnitude;
                if (distance < bestDistance) { best = slot; bestDistance = distance; }
            }
            return best;
        }
    }
}
