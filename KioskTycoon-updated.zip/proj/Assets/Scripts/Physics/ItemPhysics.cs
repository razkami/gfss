using UnityEngine;

namespace KioskTycoon
{
    /// <summary>
    /// Общие настройки физики предметов: материал (трение, без отскока), параметры тела,
    /// посадка предмета на поверхность и страховка от падения сквозь пол.
    /// </summary>
    public static class ItemPhysics
    {
        const float MinColliderThickness = 0.035f;
        static PhysicMaterial material;
        static readonly Collider[] overlapBuffer = new Collider[24];

        public static PhysicMaterial Material
        {
            get
            {
                if (material == null)
                {
                    material = new PhysicMaterial("KioskItem")
                    {
                        dynamicFriction = 0.75f,
                        staticFriction = 0.9f,
                        bounciness = 0.02f,
                        frictionCombine = PhysicMaterialCombine.Maximum,
                        bounceCombine = PhysicMaterialCombine.Minimum
                    };
                }
                return material;
            }
        }

        /// <summary>Настраивает тело и коллайдер нового предмета. Тонкие упаковки получают минимальную толщину коллайдера.</summary>
        public static void Prepare(GameObject go, BoxCollider col, Rigidbody body, float mass)
        {
            body.mass = mass;
            body.drag = 0.35f;
            body.angularDrag = 3f;
            body.sleepThreshold = 0.02f;
            body.maxDepenetrationVelocity = 2f;
            body.isKinematic = true;
            col.sharedMaterial = Material;
            Vector3 s = go.transform.localScale;
            if (s.x > 0.0001f && s.y > 0.0001f && s.z > 0.0001f)
            {
                var min = new Vector3(MinColliderThickness / s.x, MinColliderThickness / s.y, MinColliderThickness / s.z);
                col.size = Vector3.Max(col.size, min);
            }
            if (go.GetComponent<ItemBody>() == null) go.AddComponent<ItemBody>();
        }

        /// <summary>Включает полноценную физику после того, как предмет поставили.</summary>
        public static void Activate(Rigidbody body)
        {
            body.isKinematic = false;
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.velocity = Vector3.zero;
            body.angularVelocity = Vector3.zero;
            body.WakeUp();
        }

        /// <summary>
        /// Выравнивает предмет по вертикали и опускает на ближайшую поверхность под ним
        /// (полка, стол, пол). Так предмет не зависает в воздухе и не врезается в доску.
        /// </summary>
        public static void SnapToSurface(Transform t, Collider col, float maxDrop = 1.4f)
        {
            if (t == null || col == null) return;
            t.rotation = Quaternion.Euler(0f, t.eulerAngles.y, 0f);
            Physics.SyncTransforms();
            Bounds b = col.bounds;
            float half = b.extents.y;
            var hits = Physics.RaycastAll(new Ray(b.center, Vector3.down), half + maxDrop, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore);
            float best = float.MaxValue;
            Vector3 point = Vector3.zero;
            foreach (var h in hits)
            {
                if (h.collider == col || h.collider.transform.IsChildOf(t)) continue;
                if (h.collider.GetComponentInParent<CharacterController>() != null) continue;
                if (h.distance < best) { best = h.distance; point = h.point; }
            }
            if (best == float.MaxValue) return;
            // pivot смещается на ту же величину, на которую центр коллайдера должен оказаться над поверхностью
            float dy = (point.y + half + 0.002f) - b.center.y;
            t.position = new Vector3(t.position.x, t.position.y + dy, t.position.z);
        }

        /// <summary>Есть ли в точке препятствие для коробки заданного размера (игнорируя свой объект, игрока и триггеры).</summary>
        public static bool IsBlocked(Vector3 center, Vector3 halfExtents, Quaternion rot, Transform ignore)
        {
            int n = Physics.OverlapBoxNonAlloc(center, halfExtents, overlapBuffer, rot, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore);
            for (int i = 0; i < n; i++)
            {
                var c = overlapBuffer[i];
                if (c == null) continue;
                if (ignore != null && c.transform.IsChildOf(ignore)) continue;
                if (c.GetComponentInParent<CharacterController>() != null) continue;
                return true;
            }
            return false;
        }

        /// <summary>Безопасная точка возврата потерянного предмета: перед игроком, либо над стойкой.</summary>
        public static Vector3 RecoveryPoint()
        {
            var pc = PlayerController.I;
            if (pc != null) return pc.transform.position + pc.transform.forward * 0.8f + Vector3.up * 1.05f;
            return new Vector3(0f, 1.2f, 1.0f);
        }
    }

    /// <summary>
    /// Вешается на каждый физический предмет: звук при ударе и страховка от вылета за пределы мира.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class ItemBody : MonoBehaviour
    {
        Rigidbody rb;
        Vector3 lastSafe;
        bool hasSafe;
        float nextSound;

        void Awake() { rb = GetComponent<Rigidbody>(); lastSafe = transform.position; }

        void Update()
        {
            if (rb == null) return;
            Vector3 p = transform.position;
            bool lost = p.y < -1.5f || Mathf.Abs(p.x) > 60f || p.z < -60f || p.z > 40f
                        || float.IsNaN(p.x) || float.IsNaN(p.y) || float.IsNaN(p.z);
            if (lost) { Recover(); return; }
            if (p.y > -0.2f && (rb.isKinematic || rb.velocity.sqrMagnitude < 0.01f))
            {
                lastSafe = p;
                hasSafe = true;
            }
        }

        void Recover()
        {
            Vector3 target = hasSafe ? lastSafe + Vector3.up * 0.15f : ItemPhysics.RecoveryPoint();
            if (hasSafe && target.y < 0.05f) target = ItemPhysics.RecoveryPoint();
            transform.position = target;
            if (!rb.isKinematic)
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
        }

        void OnCollisionEnter(Collision c)
        {
            float v = c.relativeVelocity.magnitude;
            if (v < 1.2f || Time.time < nextSound) return;
            nextSound = Time.time + 0.15f;
            AudioManager.Play(Sfx.Place, Mathf.Clamp01(v / 5f) * 0.5f);
        }
    }
}
