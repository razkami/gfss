#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace KioskTycoon.EditorTools
{
    /// <summary>
    /// Меню Kiosk/Setup Project: создаёт ScriptableObject-ассеты товаров и покупателей,
    /// сцены MainMenu и Kiosk, и добавляет их в Build Settings.
    /// </summary>
    public static class KioskSetup
    {
        const string ProductsDir = "Assets/Resources/Data/Products";
        const string ProfilesDir = "Assets/Resources/Data/Profiles";
        const string ScenesDir = "Assets/Scenes";
        const string MenuPath = ScenesDir + "/MainMenu.unity";
        const string KioskPath = ScenesDir + "/Kiosk.unity";

        [MenuItem("Kiosk/Setup Project")]
        public static void SetupAll()
        {
            Directory.CreateDirectory(ProductsDir);
            Directory.CreateDirectory(ProfilesDir);
            Directory.CreateDirectory(ScenesDir);

            foreach (var p in GameDatabase.CreateDefaultProducts())
            {
                var path = ProductsDir + "/" + p.id + ".asset";
                if (!File.Exists(path)) AssetDatabase.CreateAsset(p, path);
            }
            foreach (var c in GameDatabase.CreateDefaultProfiles())
            {
                var path = ProfilesDir + "/" + c.id + ".asset";
                if (!File.Exists(path)) AssetDatabase.CreateAsset(c, path);
            }

            CreateMenuScene();
            CreateKioskScene();

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(MenuPath, true),
                new EditorBuildSettingsScene(KioskPath, true),
            };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("Kiosk: проект настроен. Откройте Assets/Scenes/MainMenu и нажмите Play.");
        }

        static void CreateMenuScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            var cam = Camera.main;
            if (cam != null)
            {
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = new Color(0.96f, 0.78f, 0.55f);
            }
            new GameObject("MenuUI").AddComponent<MenuUI>();
            EditorSceneManager.SaveScene(scene, MenuPath);
        }

        static void CreateKioskScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            new GameObject("GameBootstrap").AddComponent<GameBootstrap>();
            EditorSceneManager.SaveScene(scene, KioskPath);
        }
    }
}
#endif
