Shader "Kiosk/Atmospheric Glass"
{
    Properties
    {
        _Color ("Tint", Color) = (0.75,0.9,1,0.18)
        _Glossiness ("Smoothness", Range(0,1)) = 0.94
        _Metallic ("Metallic", Range(0,1)) = 0
        _FresnelStrength ("Edge Reflection", Range(0,0.6)) = 0.22
    }

    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" }
        LOD 250
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off
        Cull Off

        CGPROGRAM
        #pragma surface surf Standard alpha:fade fullforwardshadows
        #pragma target 3.0

        fixed4 _Color;
        half _Glossiness;
        half _Metallic;
        half _FresnelStrength;

        struct Input
        {
            float3 worldNormal;
            float3 viewDir;
        };

        void surf(Input IN, inout SurfaceOutputStandard o)
        {
            half facing = saturate(dot(normalize(IN.worldNormal), normalize(IN.viewDir)));
            half edge = pow(1.0 - facing, 4.0);
            o.Albedo = _Color.rgb * (0.92 + edge * 0.12);
            o.Metallic = _Metallic;
            o.Smoothness = _Glossiness;
            o.Alpha = saturate(_Color.a + edge * _FresnelStrength);
        }
        ENDCG
    }

    FallBack "Transparent/Diffuse"
}
