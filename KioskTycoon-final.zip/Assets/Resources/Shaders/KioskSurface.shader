Shader "Kiosk/Studio PBR"
{
    Properties
    {
        _Color ("Tint", Color) = (1,1,1,1)
        _MainTex ("Albedo", 2D) = "white" {}
        _Metallic ("Metallic", Range(0,1)) = 0
        _Glossiness ("Smoothness", Range(0,1)) = 0.35
        _BumpMap ("Normal Map", 2D) = "bump" {}
        _BumpScale ("Normal Strength", Range(0,2)) = 0.7
        _DetailScale ("Surface Detail Scale", Range(0.1,30)) = 5
        _DetailStrength ("Surface Detail", Range(0,0.2)) = 0.035
        _EmissionMap ("Emission Map", 2D) = "white" {}
        _EmissionColor ("Emission", Color) = (0,0,0,0)
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        LOD 300

        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows addshadow
        #pragma target 3.0
        #pragma shader_feature_local _NORMALMAP
        #pragma shader_feature_local _EMISSION

        #include "UnityCG.cginc"

        sampler2D _MainTex;
        sampler2D _BumpMap;
        sampler2D _EmissionMap;
        fixed4 _Color;
        half _Metallic;
        half _Glossiness;
        half _BumpScale;
        half _DetailScale;
        half _DetailStrength;
        fixed4 _EmissionColor;

        struct Input
        {
            float2 uv_MainTex;
            float2 uv_BumpMap;
            float2 uv_EmissionMap;
            float3 worldPos;
        };

        void surf(Input IN, inout SurfaceOutputStandard o)
        {
            fixed4 baseColor = tex2D(_MainTex, IN.uv_MainTex) * _Color;
            float3 p = IN.worldPos * max(_DetailScale, 0.1);
            float grain = sin(p.x * 2.1 + sin(p.z * 1.7 + p.y * 2.3)) *
                          cos(p.y * 1.9 + sin(p.x * 1.4 - p.z * 2.0));
            float detail = grain * _DetailStrength;

            o.Albedo = baseColor.rgb * (1.0 + detail);
            o.Metallic = _Metallic;
            o.Smoothness = saturate(_Glossiness + detail * 0.6);
            o.Occlusion = saturate(1.0 - abs(detail) * 0.55);
            o.Alpha = baseColor.a;

            #ifdef _NORMALMAP
                o.Normal = UnpackScaleNormal(tex2D(_BumpMap, IN.uv_BumpMap), _BumpScale);
            #endif

            #ifdef _EMISSION
                o.Emission = tex2D(_EmissionMap, IN.uv_EmissionMap).rgb * _EmissionColor.rgb;
            #endif
        }
        ENDCG
    }

    FallBack "Standard"
}
