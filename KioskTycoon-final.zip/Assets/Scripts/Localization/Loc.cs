using System;
using System.Collections.Generic;

namespace KioskTycoon
{
    /// <summary>Локализация. Чтобы добавить язык: добавьте код в Codes/Names и перевод в каждую строку A(...).</summary>
    public static class Loc
    {
        public static readonly string[] Codes = { "ru", "en" };
        public static readonly string[] Names = { "Русский", "English" };
        public static string Current = "ru";
        public static event Action Changed;

        static readonly Dictionary<string, string[]> T = new Dictionary<string, string[]>();
        static int idx;

        static void A(string key, string ru, string en) { T[key] = new[] { ru, en }; }

        public static void SetLanguage(string code)
        {
            int i = Array.IndexOf(Codes, code);
            if (i < 0) i = 0;
            Current = Codes[i]; idx = i;
            Changed?.Invoke();
        }

        public static string Get(string key)
        {
            if (T.TryGetValue(key, out var v)) return v[idx];
            return key;
        }

        public static string F(string key, params object[] a)
        {
            try { return string.Format(Get(key), a); } catch { return Get(key); }
        }

        static Loc()
        {
            A("cur", "₸", "$");
            A("shop.name", "Киоск «Луна»", "Kiosk “Luna”");
            A("sign.open", "ОТКРЫТО", "OPEN");
            A("sign.closed", "ЗАКРЫТО", "CLOSED");

            // HUD
            A("hud.day", "День {0}", "Day {0}");
            string[] wdRu = { "Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс" };
            string[] wdEn = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
            for (int i = 0; i < 7; i++) A("wd." + i, wdRu[i], wdEn[i]);
            A("phase.closed", "Закрыто. Нажмите E на табличке у окна", "Closed. Press E on the sign by the window");
            A("phase.open", "Открыто", "Open");
            A("phase.closing", "Закрываемся...", "Closing...");
            A("hud.rep", "Репутация", "Reputation");
            A("hud.hints", "{0} — инвентарь   {1} — отказать   {2} — вызвать охрану   {3} — бита   Esc — меню", "{0} — inventory   {1} — decline   {2} — call guard   {3} — bat   Esc — menu");
            A("hud.order", "Заказ покупателя", "Customer order");
            A("hud.tray", "В руках", "In hands");
            A("hud.box", "Коробка: {0} ×{1}", "Box: {0} ×{1}");
            A("hud.scan", "Пробиваем...", "Scanning...");
            A("hud.event", "Сегодня: {0}", "Today: {0}");
            A("hud.queue", "Очередь {0}/{1}", "Queue {0}/{1}");
            A("hud.young", "18?", "18?");
            A("hud.waiting", "...", "...");
            A("hud.wellbeing", "Самочувствие (игровой эффект)", "Wellbeing (game effect)");
            A("hud.dragHint", "ЛКМ (держать): перенести · колесо: дистанция · отпустить: поставить · открытая коробка: ЛКМ достаёт товар · Shift+ЛКМ: нести коробку", "LMB (hold): move · wheel: distance · release: place · open box: LMB takes an item · Shift+LMB: carry the box");
            A("hud.sell", "Продать", "Sell");
            A("hud.scanList", "Пробито", "Scanned");
            A("hud.saleTotal", "Сумма", "Total");
            A("hud.sellNeed", "Пробейте все товары покупателя", "Scan every item before selling");
            A("hud.wrongScan", "Этот товар не входит в заказ или уже набрано нужное количество", "This item is not in the order or enough are already scanned");
            A("hud.alreadyScanned", "Этот товар уже просканирован", "This item is already scanned");
            A("hud.deviceHint", "{0} — вдох · ещё раз {0} — выдох", "{0} — inhale · press {0} again — exhale");
            A("hud.batHint", "{0} — замах битой: наведите прицел на вора", "{0} — swing the bat while aiming at a thief");
            A("hud.puffWait", "Нужно немного подождать перед следующей затяжкой", "Wait a little before the next puff");

            A("inv.title", "Инвентарь", "Inventory");
            A("inv.product", "Товар", "Product");
            A("inv.shelf", "Полки", "Shelves");
            A("inv.storage", "Склад", "Storage");
            A("inv.world", "В киоске", "In shop");
            A("inv.price", "Цена", "Price");

            // События дня
            A("ev.normal", "Обычный день", "Ordinary day");
            A("ev.rain", "Дождь: меньше людей", "Rain: fewer people");
            A("ev.holiday", "Праздник: сладости нарасхват", "Holiday: sweets sell fast");
            A("ev.payday", "День зарплаты: растёт спрос на сигареты", "Payday: cigarettes in demand");
            A("ev.heat", "Жара: все хотят пить", "Heat wave: everyone is thirsty");
            A("ev.prices", "Поставщики подняли цены", "Suppliers raised prices");
            A("ev.news", "Громкие новости: пресса в цене", "Big news: press sells fast");

            // Категории
            A("cat.0", "Сигареты", "Cigarettes");
            A("cat.1", "Электронные устройства", "Devices");
            A("cat.2", "Сладости", "Snacks");
            A("cat.3", "Напитки", "Drinks");
            A("cat.4", "Аксессуары", "Accessories");
            A("cat.5", "Пресса", "Press");

            // Уведомления
            A("t.dayopen", "День {0}: киоск открыт!", "Day {0}: we are open!");
            A("t.closing", "Закрываемся — обслужите оставшихся", "Closing — serve the remaining customers");
            A("t.nomoney", "Не хватает денег", "Not enough money");
            A("t.bought", "Куплено: {0}", "Bought: {0}");
            A("t.delivered", "Доставка: {0} ×{1}", "Delivered: {0} ×{1}");
            A("t.storefull", "Склад полон! Освободите место", "Storage is full! Free some space");
            A("t.ordered", "Заказано: {0} ×{1}", "Ordered: {0} ×{1}");
            A("t.queuefull", "Очередь полная — покупатель ушёл", "Queue is full — customer left");
            A("t.gaveup", "Покупатель потерял терпение", "A customer lost patience");
            A("t.sale", "Продажа: +{0}", "Sale: +{0}");
            A("t.tip", "Чаевые: +{0}", "Tip: +{0}");
            A("t.fine", "Штраф {0}! Нельзя продавать молодым покупателям", "Fine {0}! Never sell to young customers");
            A("t.refuseok", "Верно: отказ в продаже. Репутация растёт", "Correct refusal. Reputation up");
            A("t.refusebad", "Покупатель недоволен отказом", "Customer is unhappy about the refusal");
            A("t.missing", "Не хватило товара: {0}", "Missing item: {0}");
            A("t.wrong", "Лишний товар: {0}", "Wrong item: {0}");
            A("t.expensive", "«{0}» слишком дорого для покупателя", "“{0}” is too expensive for this customer");
            A("t.saved", "Игра сохранена", "Game saved");
            A("t.accepted", "Заказ принят", "Order accepted");
            A("t.scanned", "Пробито: {0} — {1}", "Scanned: {0} — {1}");
            A("t.nothing", "Ничего не продано", "Nothing sold");
            A("t.relocated", "Коробки перенесены", "Boxes moved");
            A("t.nostock", "На полках нет товара. Закажите поставку у компьютера", "No shelf stock. Order a delivery at the computer");
            A("t.boxopened", "Открыта коробка «{0}»: товары выложены ({1})", "Opened {0} box: {1} products unpacked");
            A("t.productOpened", "Открыта упаковка «{0}»", "Opened {0}");
            A("t.productUsed", "Использован игровой товар: «{0}»", "Used in-game product: {0}");
            A("t.thiefSeen", "Вор подошёл к окну! Ударьте его битой, пока не схватил товар", "A thief is at the window! Hit them with the bat before they grab anything");
            A("t.thiefTook", "Вор схватил товар: {0}", "The thief grabbed: {0}");
            A("t.thiefRecovered", "Вор выронил добычу — товар возвращён", "The thief dropped the loot; the goods are back");
            A("t.thiefScared", "Удар битой! Вор бросил затею и убегает ни с чем", "Bat hit! The thief gave up and ran off empty-handed");
            A("t.thiefStopped", "Вор испугался и убегает", "The thief was scared off and is running away");
            A("t.thiefEscaped", "Вор унёс товар: {0} · репутация снизилась", "The thief escaped with {0}; reputation decreased");

            // Подсказки при наведении
            A("p.shelf.take", "Взять: {0} — {1} (осталось {2})", "Take: {0} — {1} ({2} left)");
            A("p.shelf.drag", "Зажмите ЛКМ и перенесите {0} (на полке: {1})", "Hold LMB to move {0} ({1} on shelf)");
            A("p.shelf.put", "Выложить: {0} ({1}/{2})", "Stock: {0} ({1}/{2})");
            A("p.shelf.mixed", "Полка: {0}/{1} мест · можно разместить разные товары", "Shelf: {0}/{1} slots · mixed products fit here");
            A("p.shelf.other", "Полка занята другим товаром", "Shelf holds another product");
            A("p.shelf.full", "Полка заполнена", "Shelf is full");
            A("p.shelf.empty", "Пустая полка. Выложите коробку", "Empty shelf. Stock a box here");
            A("p.shelf.none", "{0}: пусто. Нужна коробка", "{0}: empty. Needs a box");
            A("p.tray.full", "Руки заняты: больше не унести", "Hands full: cannot carry more");
            A("p.box.take", "Взять коробку: {0} ×{1}", "Pick up box: {0} ×{1}");
            A("p.box.open", "Открыть коробку: {0} ×{1}", "Open box: {0} ×{1}");
            A("p.thief.bat", "Замахнитесь битой, чтобы прогнать вора", "Swing the bat to scare off the thief");
            A("p.product.open", "Открыть товар «{0}»", "Open {0}");
            A("p.product.use", "Использовать товар «{0}»", "Use {0}");
            A("p.box.busy", "Руки заняты", "Hands are busy");
            A("p.door.open", "Открыть киоск", "Open the kiosk");
            A("p.door.close", "Закрыть дверь", "Close door");
            A("p.sign.open", "Открыть киоск", "Open the kiosk");
            A("p.sign.early", "Закрыть досрочно", "Close early");
            A("p.sign.closing", "Киоск закрывается", "Closing time");
            A("p.sign.next", "Подведите итоги дня", "See the day summary");
            A("p.pc", "Компьютер: закупки и улучшения", "Computer: orders and upgrades");
            A("p.reg.nocust", "Нет покупателя у окна", "No customer at the window");
            A("p.reg.notray", "Сначала соберите товары с полок", "Collect items from shelves first");
            A("p.reg.checkout", "Пробить и принять оплату", "Scan and take payment");
            A("p.reg.placed", "Товар размещён в зоне кассы — сканирование автоматически", "Product placed in checkout zone — scanning automatically");
            A("p.reg.full", "Зона выкладки заполнена", "Checkout area is full");
            A("p.cust.accept", "Принять заказ", "Take the order");
            A("p.cust.checkout", "Пробить товары", "Scan items");
            A("p.cust.collect", "Найдите заказанные товары на полках, перенесите их в зону кассы и просканируйте ЛКМ", "Find the requested products on shelves, place them in checkout, then scan with LMB");
            A("p.reg.order", "Сначала примите заказ у покупателя", "Take the customer's order first");
            A("t.noroom", "Сначала расширьте помещение", "Expand the shop first");
            A("pc.money", "Деньги: {0}", "Money: {0}");
            A("pc.wholesale", "закупка {0}", "cost {0}");

            // Компьютер
            A("pc.title", "Компьютер киоска", "Kiosk computer");
            A("pc.orders", "Закупки", "Orders");
            A("pc.prices", "Цены", "Prices");
            A("pc.upgrades", "Улучшения", "Upgrades");
            A("pc.stats", "Статистика", "Stats");
            A("pc.close", "Закрыть", "Close");
            A("pc.box", "коробка {0} шт.", "box of {0}");
            A("pc.buy1", "+1 коробка", "+1 box");
            A("pc.buy5", "+5 коробок", "+5 boxes");
            A("pc.shelf", "Полки: {0}", "Shelves: {0}");
            A("pc.store", "Склад: {0}", "Storage: {0}");
            A("pc.pending", "В пути", "On the way");
            A("pc.eta", "{0} ×{1} — через {2} с", "{0} ×{1} — in {2} s");
            A("pc.none", "Ничего не заказано", "Nothing ordered");
            A("pc.market", "рынок {0}", "market {0}");
            A("pc.expensive", "Дорого: часть покупателей откажется", "Pricey: some customers will refuse");
            A("pc.cheap", "Дёшево: мала прибыль", "Cheap: low profit");
            A("pc.ok", "Нормальная цена", "Fair price");
            A("pc.cost", "Цена: {0}", "Cost: {0}");
            A("pc.max", "Максимум", "Maxed out");
            A("pc.buy", "Купить", "Buy");
            A("pc.now", "Сейчас", "Now");
            A("pc.next", "После покупки", "After purchase");
            A("pc.level", "Уровень {0}/{1}", "Level {0}/{1}");
            A("pc.priceHint", "Цена продажи влияет на выручку и на то, купят ли у вас вообще.", "Sell price affects profit and whether customers buy at all.");

            // Статистика / итоги
            A("st.day", "День", "Day");
            A("st.revenue", "Выручка сегодня", "Revenue today");
            A("st.expenses", "Расходы сегодня", "Expenses today");
            A("st.profit", "Прибыль сегодня", "Profit today");
            A("st.rep", "Репутация", "Reputation");
            A("st.served", "Обслужено всего", "Customers served");
            A("st.lost", "Потеряно покупателей", "Customers lost");
            A("st.total", "Заработано за всё время", "Total earned");
            A("sum.title", "Итоги дня {0}", "Day {0} summary");
            A("sum.revenue", "Выручка", "Revenue");
            A("sum.expenses", "Закупки и улучшения", "Orders and upgrades");
            A("sum.rent", "Аренда", "Rent");
            A("sum.profit", "Итого за день", "Day total");
            A("sum.rep", "Репутация", "Reputation");
            A("sum.served", "Обслужено", "Served");
            A("sum.lost", "Потеряно", "Lost");
            A("sum.next", "Следующий день", "Next day");

            // Улучшения
            A("up.Size.name", "Размер помещения", "Floor space");
            A("up.Size.0", "Тесный киоск, очередь до 4", "Tiny kiosk, queue up to 4");
            A("up.Size.1", "Малый магазин с залом, очередь до 5, больше покупателей", "Small shop with a hall, queue up to 5, more traffic");
            A("up.Size.2", "Магазин: большой зал, очередь до 7, ещё больше покупателей", "Full shop: big hall, queue up to 7, even more traffic");
            A("up.Shelves.name", "Полки", "Shelves");
            A("up.Shelves.0", "4 полки по 10 шт.", "4 shelves, 10 pcs each");
            A("up.Shelves.1", "6 полок по 14 шт.", "6 shelves, 14 pcs each");
            A("up.Shelves.2", "8 полок по 18 шт.", "8 shelves, 18 pcs each");
            A("up.Shelves.3", "10 полок по 22 шт.", "10 shelves, 22 pcs each");
            A("up.Storage.name", "Склад", "Storage");
            A("up.Storage.0", "Место под 3 коробки", "Room for 3 boxes");
            A("up.Storage.1", "Место под 6 коробок", "Room for 6 boxes");
            A("up.Storage.2", "Место под 9 коробок", "Room for 9 boxes");
            A("up.Storage.3", "Место под 12 коробок", "Room for 12 boxes");
            A("up.Register.name", "Касса", "Register");
            A("up.Register.0", "Старая касса: 1.6 с на товар", "Old register: 1.6 s per item");
            A("up.Register.1", "Быстрая касса: 1.1 с на товар", "Fast register: 1.1 s per item");
            A("up.Register.2", "Сканер: 0.7 с на товар", "Scanner: 0.7 s per item");
            A("up.Register.3", "Терминал: 0.35 с, больше чаевых", "Terminal: 0.35 s, bigger tips");
            A("up.Display.name", "Витрина и ассортимент", "Display and range");
            A("up.Display.0", "Сигареты, напитки, жвачка", "Cigarettes, drinks, gum");
            A("up.Display.1", "+ сладости, аксессуары, пресса", "+ snacks, accessories, press");
            A("up.Display.2", "+ электронные устройства, энергетики", "+ devices, energy drinks");
            A("up.Display.3", "+ премиум и подарочные наборы", "+ premium goods and gift sets");
            A("up.Decor.name", "Оформление", "Decor");
            A("up.Decor.0", "Простой бежевый интерьер", "Plain beige interior");
            A("up.Decor.1", "Мятные стены, цветы, постер", "Mint walls, plants, poster");
            A("up.Decor.2", "Тёплый закат, ковёр, лампы", "Sunset tones, rug, lamps");
            A("up.Decor.3", "Неоновое оформление и вывеска", "Neon style and sign");

            // Безопасность, кража, итоги
            A("up.Cameras.name", "Камеры наблюдения", "CCTV cameras");
            A("up.Cameras.0", "Камер нет", "No cameras");
            A("up.Cameras.1", "Камера над входом: подозрительных видно в очереди, меньше краж", "Door camera: suspects are marked in the queue, fewer thefts");
            A("up.Cameras.2", "Две камеры и монитор в киоске, ещё меньше краж", "Two cameras and a monitor in the kiosk, even fewer thefts");
            A("up.Cameras.3", "Три камеры, купольная; страховка возвращает часть украденного", "Three cameras plus a dome; insurance refunds part of the loss");
            A("up.Guard.name", "Охранник", "Security guard");
            A("up.Guard.0", "Охраны нет", "No guard");
            A("up.Guard.1", "Охранник по вызову (клавиша вызова): приходит и ловит вора, шанс 55%", "Guard on call (call key): comes and chases the thief, 55% catch chance");
            A("up.Guard.2", "Охранник на посту: сам ловит воров (90%), отпугивает, зарплата за день", "Guard on post: chases thieves himself (90%), deters theft, daily salary");
            A("up.Size.world", "Мир: киоск расширяется — появляется зал и больше места для очереди", "In the world: the kiosk grows into a hall with more queue room");
            A("up.Shelves.world", "Мир: на стенах появляются новые полки", "In the world: new shelves appear on the walls");
            A("up.Storage.world", "Мир: на складе открываются новые поддоны", "In the world: new pallets open up in storage");
            A("up.Register.world", "Мир: меняется касса — сканер, терминал", "In the world: the register changes — scanner, terminal");
            A("up.Display.world", "Мир: витрина получает новые отделения, растёт ассортимент", "In the world: the showcase gets new sections and range");
            A("up.Decor.world", "Мир: меняются цвета стен, свет, вывеска", "In the world: wall colors, lighting and the sign change");
            A("up.Cameras.world", "Мир: на стенах появляются камеры, монитор показывает запись", "In the world: cameras appear, the monitor shows live feed");
            A("up.Guard.world", "Мир: у окна стоит охранник в форме", "In the world: a uniformed guard stands by the window");
            A("pc.upkeep", "Содержание в день: сейчас {0}, после улучшения {1}", "Upkeep per day: now {0}, after upgrade {1}");
            A("act.CallGuard", "Вызвать охрану", "Call guard");
            A("hud.thiefAlert", "ВОР! {0} — позвать охрану, {1} — ударить битой", "THIEF! {0} — call the guard, {1} — swing the bat");
            A("hud.suspect", "Подозрительный", "Suspicious");
            A("hud.thief", "ВОР!", "THIEF!");
            A("hud.guard", "Охрана", "Guard");
            A("hud.repShort", "Реп", "Rep");
            A("hud.wellShort", "Сам", "Me");
            A("hud.zone", "КАССА: положите сюда товары", "REGISTER: place items here");
            A("hud.zoneActive", "На кассе: {0} · пробито: {1} из {2}", "On counter: {0} · scanned: {1} of {2}");
            A("st.night", "Ночь", "Night");
            A("hud.closing", "Закрываемся: обслужите последних покупателей", "Closing: serve the last customers");
            A("hud.night.lock", "Выйдите, заприте дверь киоска снаружи ({0}) и идите домой — иначе его ограбят!", "Step outside, lock the kiosk door from outside ({0}) and go home, or it will be robbed!");
            A("hud.night.home", "Киоск заперт. Идите домой и ложитесь спать", "The kiosk is locked. Go home and get some sleep");
            A("hud.home", "ДОМ", "HOME");
            A("p.door.lock", "Запереть киоск на ночь", "Lock the kiosk for the night");
            A("p.door.unlock", "Отпереть киоск", "Unlock the kiosk");
            A("p.sign.night", "Закрыто. Заприте дверь и идите домой", "Closed. Lock the door and go home");
            A("p.home.day", "Ваш дом (вернётесь сюда вечером)", "Your home (come back here in the evening)");
            A("p.home.wait", "Дом: сначала закройте киоск", "Home: close the kiosk first");
            A("p.home.sleep", "Войти домой и лечь спать", "Go home and sleep");
            A("p.home.sleepOpen", "Лечь спать (киоск НЕ заперт!)", "Go to sleep (kiosk NOT locked!)");
            A("p.home.sleepSure", "Нажмите ещё раз: спать, оставив киоск открытым", "Press again: sleep and leave the kiosk unlocked");
            A("t.nightFalls", "Киоск закрыт для покупателей. Заприте дверь снаружи и идите домой", "The kiosk is closed to customers. Lock the door from outside and go home");
            A("t.nightHint", "Заприте дверь киоска снаружи и идите домой", "Lock the kiosk door from outside and go home");
            A("t.lockOutside", "Выйдите наружу и заприте дверь снаружи", "Step outside and lock the door from outside");
            A("t.locked", "Киоск заперт. Идите домой", "The kiosk is locked. Go home");
            A("t.unlocked", "Киоск отперт", "The kiosk is unlocked");
            A("t.homeUnlocked", "Вы не заперли киоск — ночью его могут ограбить! Нажмите ещё раз, чтобы всё равно лечь спать", "You didn't lock the kiosk, it may be robbed tonight! Press again to sleep anyway");
            A("t.homeEarly", "Рано домой: сначала закройте смену", "Too early to go home: finish the shift first");
            A("t.passedOut", "Вы заснули от усталости", "You fell asleep from exhaustion");
            A("t.morning", "Новое утро. Дойдите до киоска и откройте его", "A new morning. Walk to the kiosk and open it");
            A("t.cashStolen", "Из кассы украдено: {0}", "Stolen from the register: {0}");
            A("sleep.text", "Zzz...  Спокойной ночи", "Zzz...  Good night");
            A("sum.cash", "Украдено из кассы", "Stolen from register");
            A("sum.night", "Ночь", "Night");
            A("sum.night.bad", "Киоск ограблен!", "Kiosk was robbed!");
            A("sum.night.ok", "Спокойная", "Quiet");
            A("st.closed", "Закрыто", "Closed");
            A("st.open", "Открыто", "Open");
            A("st.summary", "Итоги", "Summary");
            A("sum.guard", "Охрана", "Guard");
            A("sum.thefts", "Попыток краж", "Theft attempts");
            A("sum.caught", "поймано", "caught");
            A("sum.stolen", "Украдено", "Stolen");
            A("sum.recovered", "Возвращено", "Recovered");
            A("sum.refund", "Страховка камер", "Camera insurance");
            A("t.noguard", "Охранника нет — купите улучшение на компьютере", "No guard — buy the upgrade on the computer");
            A("t.nothreat", "Сейчас никто не убегает", "Nobody is running away right now");
            A("t.guardBusy", "Охранник уже занят погоней", "The guard is already chasing");
            A("t.guardCalled", "Охранник вызван (−{0})", "Guard called (−{0})");
            A("t.guardGo", "Охранник бросился в погоню", "The guard is chasing the thief");
            A("t.guardCaught", "Охранник поймал вора, товар возвращён", "The guard caught the thief, goods returned");
            A("t.guardMissed", "Вор ускользнул от охранника", "The thief slipped past the guard");
            A("t.guardDeter", "Заметив охранника, вор передумал", "Seeing the guard, the thief changed his mind");
            A("t.suspectCam", "Камера: в очереди подозрительный тип", "Camera: a suspicious person in the queue");
            A("t.camDoor", "Камера у окна зафиксировала вора", "The window camera recorded the thief");
            A("t.stolen", "Украдено: {0} шт. на {1}", "Stolen: {0} items worth {1}");
            A("t.refund", "Страховка камер вернула {0}", "Camera insurance refunded {0}");
            A("t.thiefGrab", "Покупатель схватил товар и убегает!", "A customer grabbed goods and is running!");
            A("p.item.scan", "{0} — {1} (ожидает сканирования)", "{0} — {1} (waiting to scan)");
            A("p.item.scanned", "{0} — {1} (пробито)", "{0} — {1} (scanned)");
            A("p.product.info", "{0} — {1}. E: открыть", "{0} — {1}. E: open");
            A("p.product.use2", "{0} — {1}. E: использовать", "{0} — {1}. E: use");

            // Обучение
            A("tut.0", "Осмотритесь: двигайте мышью", "Look around: move the mouse");
            A("tut.1", "Осмотритесь и пройдитесь по киоску: WASD", "Look around and walk through the kiosk: WASD");
            A("tut.2", "Осмотритесь и пройдитесь по киоску: WASD", "Look around and walk through the kiosk: WASD");
            A("tut.3", "Зажмите ЛКМ на товаре и перенесите его мышью", "Hold LMB on an item and move it with the mouse");
            A("tut.4", "Положите товар на свободное место полки или в подсвеченную зону кассы", "Place the item on a free shelf or in the highlighted checkout zone");
            A("tut.5", "Нажмите {0} на компьютере: закупки и улучшения", "Press {0} on the computer: orders and upgrades");
            A("tut.6", "Нажмите {0} на табличке у окна, чтобы открыть киоск", "Press {0} on the sign by the window to open");
            A("tut.7", "Примите заказ, перенесите нужные товары к кассе, просканируйте их и нажмите «Продать»", "Accept the order, carry requested products to checkout, scan them, then press Sell");
            A("tut.8", "Отлично! Копите деньги и улучшайте киоск на компьютере", "Great! Save money and upgrade the kiosk on the computer");
            A("tut.skip", "{0} — пропустить обучение", "{0} — skip tutorial");

            // Меню
            A("m.title", "ТАБАЧНЫЙ КИОСК", "TOBACCO KIOSK");
            A("m.sub", "Симулятор продавца", "Shopkeeper simulator");
            A("m.continue", "Продолжить", "Continue");
            A("m.new", "Новая игра", "New game");
            A("m.settings", "Настройки", "Settings");
            A("m.language", "Выбор языка", "Language");
            A("m.exit", "Выход", "Exit");
            A("m.confirm", "Начать заново? Сохранённый прогресс будет стёрт.", "Start over? Saved progress will be erased.");
            A("m.yes", "Да", "Yes");
            A("m.no", "Нет", "No");
            A("m.back", "Назад", "Back");
            A("ps.title", "Пауза", "Paused");
            A("ps.resume", "Продолжить", "Resume");
            A("ps.settings", "Настройки", "Settings");
            A("ps.save", "Сохранить игру", "Save game");
            A("ps.menu", "В главное меню", "Main menu");
            A("ps.quit", "Выйти из игры", "Quit game");

            // Настройки
            A("s.title", "Настройки", "Settings");
            A("s.graphics", "Графика", "Graphics");
            A("s.sound", "Звук", "Sound");
            A("s.controls", "Управление", "Controls");
            A("s.lang", "Язык и тема", "Language & theme");
            A("s.quality", "Качество", "Quality");
            A("s.resolution", "Разрешение", "Resolution");
            A("s.fullscreen", "Полный экран", "Fullscreen");
            A("s.brightness", "Яркость", "Brightness");
            A("s.master", "Общая громкость", "Master volume");
            A("s.music", "Музыка", "Music");
            A("s.musicEnabled", "Фоновая музыка", "Background music");
            A("s.sfx", "Эффекты", "Effects");
            A("s.sens", "Чувствительность мыши", "Mouse sensitivity");
            A("s.invert", "Инвертировать ось Y", "Invert Y axis");
            A("s.reset", "Сбросить клавиши", "Reset keys");
            A("s.press", "Нажмите клавишу...", "Press a key...");
            A("s.theme", "Тема оформления", "Visual theme");
            A("s.language", "Язык интерфейса", "Interface language");
            A("s.preview", "Предпросмотр", "Preview");
            A("s.rebindHint", "Нажмите на клавишу, чтобы изменить", "Click a key to change it");
            A("s.wellbeingInterval", "Интервал снижения самочувствия", "Wellbeing decrease interval");
            A("s.puffInterval", "Интервал между затяжками", "Interval between puffs");
            A("s.inhaleDuration", "Длительность вдоха", "Inhale animation duration");
            A("s.exhaleDuration", "Длительность выдоха", "Exhale animation duration");
            A("s.wellbeingEffect", "Сила экранного эффекта", "Screen effect strength");
            A("on", "Вкл", "On");
            A("off", "Выкл", "Off");
            A("th.0", "Уютная", "Cozy");
            A("th.1", "Неоновая", "Neon");
            A("th.2", "Ретро", "Retro");
            A("th.sample", "Пример кнопки", "Sample button");
            A("th.sampleText", "Баланс: 123.5", "Balance: 123.5");

            A("act.Forward", "Вперёд", "Forward");
            A("act.Back", "Назад", "Back");
            A("act.Left", "Влево", "Left");
            A("act.Right", "Вправо", "Right");
            A("act.Run", "Бег", "Run");
            A("act.Interact", "Действие", "Interact");
            A("act.Drop", "Положить / убрать", "Put away");
            A("act.Decline", "Отказать покупателю", "Decline customer");
            A("act.Inventory", "Инвентарь", "Inventory");
            A("act.UseDevice", "Действие с устройством", "Use device");
            A("act.UseBat", "Замах битой", "Swing bat");

            A("cust.commuter", "Прохожий", "Passer-by");
            A("cust.worker", "Рабочий", "Worker");
            A("cust.student", "Студент", "Student");
            A("cust.regular", "Постоянный клиент", "Regular");
            A("cust.tourist", "Турист", "Tourist");
        }
    }
}
