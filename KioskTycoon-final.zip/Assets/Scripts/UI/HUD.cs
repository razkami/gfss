using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Игровой интерфейс: компактные показатели, подсказки, заказ, инвентарь, итоги дня.</summary>
    public class HUD : MonoBehaviour
    {
        public static HUD I;
        bool showInventory;
        Vector2 invScroll;
        readonly Tutorial tut = new Tutorial();

        void Awake() { I = this; }

        public void ToggleInventory() { showInventory = !showInventory; }

        void Update()
        {
            for (int i = Toast.Items.Count - 1; i >= 0; i--)
            {
                var it = Toast.Items[i];
                it.t += Time.deltaTime;
                if (it.t > 4.5f) Toast.Items.RemoveAt(i);
            }
            tut.Update();
            if (Input.GetKeyDown(KeyCode.Backspace)) tut.Skip();
        }

        void OnGUI()
        {
            var e = EconomyManager.I;
            if (e == null || GameSession.Data == null || PlayerController.I == null) return;
            UIKit.Begin();
            WorldLabels.DrawAll(PlayerController.I.Cam);

            float vw = UIKit.VW;
            var t = ThemeManager.Current;
            var D = GameSession.Data;
            DrawWellbeingVignette(vw);

            // ---- компактная строка: день, время, баланс (левый верхний угол)
            var top = new Rect(24, 24, 760, 60);
            UIKit.Panel(top);
            UIKit.Label(new Rect(top.x + 20, top.y + 6, 430, 48),
                Loc.F("hud.day", D.day) + " " + Loc.Get("wd." + e.Weekday) + "  ·  " + e.ClockText(), 30, t.accent, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(top.x + 440, top.y + 6, 300, 48), UIKit.Money(D.money), 34, t.good, TextAnchor.MiddleRight, true, false);

            // ---- статус киоска: смена, репутация, самочувствие, камеры/охрана, очередь
            DrawStatusRow(new Rect(24, 96, 760, 44), t, e, D);

            // ---- подсказка, пока киоск закрыт
            if (e.phase == Phase.Closed)
            {
                var banner = new Rect(vw / 2f - 380, 24, 760, 54);
                UIKit.Plate(banner);
                UIKit.Label(banner, Loc.Get("phase.closed"), 28, t.text, TextAnchor.MiddleCenter, true, false);
            }
            if (e.phase == Phase.Closing || e.phase == Phase.Night)
            {
                var banner = new Rect(vw / 2f - 480, 24, 960, 54);
                UIKit.Plate(banner);
                string msg = e.phase == Phase.Closing ? Loc.Get("hud.closing")
                    : KioskDoor.IsLocked ? Loc.Get("hud.night.home") : Loc.F("hud.night.lock", Binds.Name(GameAction.Interact));
                var col = e.phase == Phase.Night && !KioskDoor.IsLocked ? t.bad : t.text;
                UIKit.Label(banner, msg, 26, col, TextAnchor.MiddleCenter, true, false);
            }
            DrawThiefAlert(vw, t);

            // ---- заказ у окна (правый верх)
            var spawner = CustomerSpawner.I;
            var front = spawner != null ? spawner.Front : null;
            if (front != null && front.State != CustState.Queued && front.State != CustState.Leaving)
                DrawOrder(front, new Rect(vw - 24 - 420, 24, 420, 0), spawner, t);
            if (CashRegister.I != null && CashRegister.I.HasActiveOrder) DrawSalePanel(vw, t, CashRegister.I);

            // ---- руки (левый нижний угол)
            DrawHands(t);

            // ---- прицел и подсказка
            UIKit.Box(new Rect(vw / 2f - 5, 535, 10, 10), new Color(1, 1, 1, 0.8f));
            string prompt = PlayerController.I.Prompt;
            if (!string.IsNullOrEmpty(prompt) && !GameUI.Blocked)
            {
                var pr = new Rect(vw / 2f - 360, 590, 720, 56);
                UIKit.Plate(pr);
                var action = PlayerController.I.Target is IFleeing ? GameAction.UseBat : GameAction.Interact;
                UIKit.Label(pr, "[" + Binds.Name(action) + "]  " + prompt, 28, t.text, TextAnchor.MiddleCenter, true, false);
            }

            // ---- обучение
            string tt = tut.Text();
            if (tt != null)
            {
                var tr = new Rect(24, 300, 560, 70);
                UIKit.Panel(tr);
                UIKit.Label(new Rect(tr.x + 20, tr.y + 8, tr.width - 40, tr.height - 16), tt, 26, t.text, TextAnchor.MiddleLeft, true, true);
            }

            // ---- подсказки управления (внизу)
            UIKit.Label(new Rect(0, 1080 - 52, vw, 36),
                Loc.F("hud.hints", Binds.Name(GameAction.Inventory), Binds.Name(GameAction.Decline), Binds.Name(GameAction.CallGuard),
                    Binds.Name(GameAction.UseBat), Binds.Name(GameAction.UseDevice)),
                22, t.textDim, TextAnchor.MiddleCenter, false, false);
            UIKit.Label(new Rect(24, 1080 - 88, vw - 48, 30), Loc.Get("hud.dragHint"), 18, t.textDim, TextAnchor.MiddleCenter, false, false);

            DrawToasts(vw, t);
            if (showInventory && !GameUI.Blocked) DrawInventory(vw, t);
            if (e.phase == Phase.Summary) DrawSummary(vw, t, e, D);
            UIKit.End();
        }

        void DrawWellbeingVignette(float vw)
        {
            float effect = (1f - PlayerController.I.Wellbeing / 100f) * SettingsManager.Data.wellbeingEffect;
            float a = Mathf.Clamp01(effect * 0.22f);
            if (a <= 0.001f) return;
            Color edge = new Color(0f, 0f, 0f, a);
            UIKit.Box(new Rect(0, 0, vw, 34), edge);
            UIKit.Box(new Rect(0, 1046, vw, 34), edge);
            UIKit.Box(new Rect(0, 0, 30, 1080), edge);
            UIKit.Box(new Rect(vw - 30, 0, 30, 1080), edge);
        }

        void DrawStatusRow(Rect r, Theme t, EconomyManager e, SaveData D)
        {
            UIKit.Plate(r);
            string phase = e.phase == Phase.Closed ? Loc.Get("st.closed")
                : e.phase == Phase.Open ? Loc.Get("st.open") : e.phase == Phase.Closing ? Loc.Get("phase.closing")
                : e.phase == Phase.Night ? Loc.Get("st.night") : Loc.Get("st.summary");
            var pc = e.phase == Phase.Open ? t.good : e.phase == Phase.Closed ? t.bad : t.accent;
            UIKit.Label(new Rect(r.x + 14, r.y, 170, r.height), phase, 24, pc, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(r.x + 186, r.y, 44, r.height), Loc.Get("hud.repShort"), 20, t.textDim, TextAnchor.MiddleLeft, false, false);
            UIKit.Bar(new Rect(r.x + 232, r.y + 13, 110, 18), D.reputation / 100f, t.accent);
            var player = PlayerController.I;
            UIKit.Label(new Rect(r.x + 354, r.y, 40, r.height), Loc.Get("hud.wellShort"), 20, t.textDim, TextAnchor.MiddleLeft, false, false);
            UIKit.Bar(new Rect(r.x + 396, r.y + 13, 90, 18), player.Wellbeing / 100f, Color.Lerp(t.bad, t.good, player.Wellbeing / 100f));
            var sec = SecurityManager.I;
            if (sec != null && sec.CamLevel > 0)
                UIKit.Label(new Rect(r.x + 498, r.y, 120, r.height), "● CAM " + sec.CamLevel, 20, t.bad, TextAnchor.MiddleLeft, true, false);
            if (sec != null && sec.GuardLevel > 0)
                UIKit.Label(new Rect(r.x + 600, r.y, 150, r.height), (sec.GuardOnPost ? "■ " : "□ ") + Loc.Get("hud.guard"), 20, t.accent2, TextAnchor.MiddleLeft, true, false);
        }

        void DrawThiefAlert(float vw, Theme t)
        {
            var sec = SecurityManager.I;
            if (sec == null || sec.AlertTime <= 0f) return;
            float blink = 0.75f + 0.25f * Mathf.Sin(Time.unscaledTime * 10f);
            var r = new Rect(vw / 2f - 450, 150, 900, 60);
            UIKit.Box(new Rect(r.x - 4, r.y - 4, r.width + 8, r.height + 8), new Color(1f, 1f, 1f, 0.9f * blink));
            UIKit.Box(r, new Color(0.8f, 0.07f, 0.07f, 0.95f * blink));
            UIKit.Label(r, sec.AlertText, 28, Color.white, TextAnchor.MiddleCenter, true, false);
        }

        void DrawSalePanel(float vw, Theme t, CashRegister register)
        {
            var r = new Rect(vw - 444, 320, 420, 470);
            UIKit.Panel(r, Loc.Get("hud.scanList") + "  " + register.ScannedCount + " / " + register.OrderCount);
            float y = r.y + 72;
            var quantities = new Dictionary<ProductData, int>();
            foreach (var item in register.ScannedProducts)
            {
                if (item == null) continue;
                quantities.TryGetValue(item.product, out int count);
                quantities[item.product] = count + 1;
            }
            foreach (var kv in quantities)
            {
                string line = kv.Key.displayName + " ×" + kv.Value;
                float sum = StockManager.I.GetPrice(kv.Key) * kv.Value;
                UIKit.Label(new Rect(r.x + 18, y, 260, 32), line, 21, t.text, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(r.x + 280, y, 120, 32), UIKit.Money(sum), 20, t.text, TextAnchor.MiddleRight, true, false);
                y += 34;
            }
            UIKit.Box(new Rect(r.x + 16, r.yMax - 118, r.width - 32, 2), t.panel2);
            UIKit.Label(new Rect(r.x + 18, r.yMax - 108, 180, 36), Loc.Get("hud.saleTotal"), 25, t.textDim, TextAnchor.MiddleLeft, false, false);
            UIKit.Label(new Rect(r.x + 190, r.yMax - 108, 210, 36), UIKit.Money(register.SaleTotal), 26, t.good, TextAnchor.MiddleRight, true, false);
            if (!register.CanSell)
                UIKit.Label(new Rect(r.x + 18, r.yMax - 70, r.width - 36, 30), Loc.Get("hud.sellNeed"), 18, t.textDim, TextAnchor.MiddleCenter, false, false);
            else if (UIKit.Button(new Rect(r.x + 30, r.yMax - 62, r.width - 60, 50), Loc.Get("hud.sell"), true, 27, t.good))
                register.SellScanned();
        }

        void DrawOrder(Customer f, Rect r, CustomerSpawner spawner, Theme t)
        {
            var D = GameSession.Data;
            int rows = f.Wants.Count;
            int cap = UpgradeCatalog.QueueCap[D.Up(UpgradeType.Size)];
            r.height = 120 + rows * 44 + (f.Young && f.HasRestricted() ? 40 : 0);
            UIKit.Panel(r, Loc.Get("hud.order"));
            float y = r.y + 76;
            var tray = PlayerController.I.Ctx;
            foreach (var kv in f.Wants)
            {
                int have = CashRegister.I != null && CashRegister.I.HasActiveOrder
                    ? CashRegister.I.CounterCount(kv.Key) : tray.Get(kv.Key);
                var col = have >= kv.Value ? t.good : t.text;
                UIKit.Label(new Rect(r.x + 20, y, r.width - 120, 40), kv.Key.displayName, 26, col, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(r.xMax - 110, y, 90, 40), have + " / " + kv.Value, 26, col, TextAnchor.MiddleRight, true, false);
                y += 44;
            }
            if (f.Young && f.HasRestricted())
                UIKit.Label(new Rect(r.x + 20, y + 4, r.width - 40, 36), Loc.Get("hud.young") + "  ·  " + Loc.Get("p.reg.checkout"), 22, t.accent2, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(r.x + 20, r.yMax - 40, r.width - 40, 34),
                Loc.F("hud.queue", spawner.Queue.Count, cap), 22, t.textDim, TextAnchor.MiddleLeft, false, false);
        }

        void DrawHands(Theme t)
        {
            var ctx = PlayerController.I.Ctx;
            if (ctx.TrayCount == 0 && ctx.heldBox == null) return;
            var r = new Rect(24, 1080 - 150 - 60, 420, 110);
            UIKit.Panel(r);
            UIKit.Label(new Rect(r.x + 18, r.y + 10, r.width - 36, 36),
                Loc.Get("hud.tray") + ": " + ctx.TrayCount + " / " + PlayerContext.TrayMax, 26, t.accent, TextAnchor.MiddleLeft, true, false);
            string line = "";
            int shown = 0;
            foreach (var kv in ctx.Tray)
            {
                if (shown++ >= 3) break;
                line += kv.Key.displayName + " ×" + kv.Value + "   ";
            }
            UIKit.Label(new Rect(r.x + 18, r.y + 50, r.width - 36, 30), line, 22, t.text, TextAnchor.MiddleLeft, false, false);
            if (ctx.heldBox != null)
                UIKit.Label(new Rect(r.x + 18, r.y + 78, r.width - 36, 28),
                    Loc.F("hud.box", ctx.heldBox.product.displayName, ctx.heldBox.qty), 22, t.accent2, TextAnchor.MiddleLeft, false, false);
        }

        void DrawToasts(float vw, Theme t)
        {
            float y = 1080 - 230;
            for (int i = Toast.Items.Count - 1; i >= 0; i--)
            {
                var it = Toast.Items[i];
                float a = Mathf.Clamp01(1f - (it.t - 3.5f));
                var col = it.kind == ToastKind.Good ? t.good : it.kind == ToastKind.Warn ? t.bad : t.text;
                col.a = a;
                UIKit.Plate(new Rect(vw / 2f - 420, y, 840, 46));
                UIKit.Label(new Rect(vw / 2f - 400, y + 4, 800, 38), it.text, 26, col, TextAnchor.MiddleCenter, true, false);
                y -= 54;
            }
        }

        void DrawInventory(float vw, Theme t)
        {
            var panel = new Rect(vw / 2f - 640, 90, 1280, 900);
            UIKit.Panel(panel, Loc.Get("inv.title"));
            var hdr = new Rect(panel.x + 30, panel.y + 80, panel.width - 60, 40);
            UIKit.Label(new Rect(hdr.x, hdr.y, 420, 36), Loc.Get("inv.product"), 24, t.textDim, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(hdr.x + 440, hdr.y, 200, 36), Loc.Get("inv.shelf"), 24, t.textDim, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(hdr.x + 640, hdr.y, 200, 36), Loc.Get("inv.storage"), 24, t.textDim, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(hdr.x + 840, hdr.y, 200, 36), Loc.Get("inv.world"), 24, t.textDim, TextAnchor.MiddleLeft, true, false);
            UIKit.Label(new Rect(hdr.x + 1040, hdr.y, 200, 36), Loc.Get("inv.price"), 24, t.textDim, TextAnchor.MiddleLeft, true, false);

            var view = new Rect(panel.x + 30, panel.y + 130, panel.width - 60, panel.height - 200);
            int display = GameSession.Data.Up(UpgradeType.Display);
            var list = new List<ProductData>();
            foreach (var p in GameDatabase.Products) if (p.unlockLevel <= display) list.Add(p);
            var content = new Rect(0, 0, view.width - 20, list.Count * 46);
            invScroll = GUI.BeginScrollView(view, invScroll, content);
            float y = 0;
            foreach (var p in list)
            {
                UIKit.Plate(new Rect(0, y, content.width, 40));
                UIKit.Label(new Rect(16, y, 420, 40), p.displayName, 26, t.text, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(456, y, 200, 40), StockManager.I.OnShelves(p).ToString(), 26, t.text, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(656, y, 200, 40), StockManager.I.InStorage(p).ToString(), 26, t.text, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(856, y, 200, 40), StockManager.I.LooseCount(p).ToString(), 26, t.text, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(1056, y, 200, 40), UIKit.Money(StockManager.I.GetPrice(p)), 26, t.text, TextAnchor.MiddleLeft, false, false);
                y += 46;
            }
            GUI.EndScrollView();
        }

        void DrawSummary(float vw, Theme t, EconomyManager e, SaveData D)
        {
            UIKit.Box(new Rect(0, 0, vw, 1080), new Color(0, 0, 0, 0.5f));
            var panel = new Rect(vw / 2f - 400, 110, 800, 860);
            UIKit.Panel(panel, Loc.F("sum.title", D.day));
            float y = panel.y + 84;
            float profit = e.todayRevenue - e.todayExpenses;
            float ordersCost = e.todayExpenses - e.summaryRent - e.todayGuardCost - e.todayStolenCash;
            string repSign = (e.repDelta >= 0 ? "+" : "") + e.repDelta.ToString("0.0");
            string[][] rows =
            {
                new[] { Loc.Get("sum.revenue"), UIKit.Money(e.todayRevenue - e.todayRefund) },
                new[] { Loc.Get("sum.expenses"), UIKit.Money(ordersCost) },
                new[] { Loc.Get("sum.rent"), UIKit.Money(e.summaryRent) },
                new[] { Loc.Get("sum.guard"), UIKit.Money(e.todayGuardCost) },
                new[] { Loc.Get("sum.thefts"), e.todayThieves + "  ·  " + Loc.Get("sum.caught") + " " + e.todayCaught },
                new[] { Loc.Get("sum.stolen"), "-" + UIKit.Money(e.todayStolenValue) + "  (" + e.todayStolenItems + ")" },
                new[] { Loc.Get("sum.recovered"), UIKit.Money(e.todayRecoveredValue) },
                new[] { Loc.Get("sum.refund"), UIKit.Money(e.todayRefund) },
                new[] { Loc.Get("sum.cash"), "-" + UIKit.Money(e.todayStolenCash) },
                new[] { Loc.Get("sum.night"), Loc.Get(e.nightRobbed ? "sum.night.bad" : "sum.night.ok") },
                new[] { Loc.Get("sum.profit"), UIKit.Money(profit) },
                new[] { Loc.Get("sum.rep"), repSign },
                new[] { Loc.Get("sum.served"), e.todayServed + "  /  " + Loc.Get("sum.lost") + " " + e.todayLost },
            };
            foreach (var row in rows)
            {
                UIKit.Label(new Rect(panel.x + 40, y, 400, 40), row[0], 27, t.textDim, TextAnchor.MiddleLeft, false, false);
                UIKit.Label(new Rect(panel.x + 420, y, 340, 40), row[1], 27, t.text, TextAnchor.MiddleRight, true, false);
                y += 47;
            }
            if (UIKit.Button(new Rect(panel.x + panel.width / 2f - 200, panel.yMax - 100, 400, 64), Loc.Get("sum.next"), true, 30))
                e.NextDay();
        }

        // ====================== обучение ======================
        class Tutorial
        {
            int step;
            float look, doneTimer = -1f;
            Vector3 walkStart;

            public string Text()
            {
                if (GameSession.Data == null || GameSession.Data.tutorialDone) return null;
                if (doneTimer >= 0f) return Loc.Get("tut.8");
                switch (step)
                {
                    case 0: return Loc.Get("tut.0");
                    case 1: return Loc.Get("tut.1");
                    case 2: return Loc.Get("tut.2");
                    case 3: return Loc.Get("tut.3");
                    case 4: return Loc.Get("tut.4");
                    case 5: return Loc.F("tut.5", Binds.Name(GameAction.Interact));
                    case 6: return Loc.F("tut.6", Binds.Name(GameAction.Interact));
                    default: return Loc.Get("tut.7");
                }
            }

            public void Skip()
            {
                if (GameSession.Data == null) return;
                GameSession.Data.tutorialDone = true;
                GameSession.Save();
            }

            public void Update()
            {
                if (GameSession.Data == null || GameSession.Data.tutorialDone || PlayerController.I == null) return;
                var pc = PlayerController.I;
                if (doneTimer >= 0f)
                {
                    doneTimer += Time.deltaTime;
                    if (doneTimer > 6f) Skip();
                    return;
                }
                switch (step)
                {
                    case 0:
                        look += Mathf.Abs(Input.GetAxis("Mouse X")) + Mathf.Abs(Input.GetAxis("Mouse Y"));
                        if (look > 60f) step = 1;
                        break;
                    case 1:
                        step = 2; walkStart = pc.transform.position;
                        break;
                    case 2:
                        if (Vector3.Distance(pc.transform.position, walkStart) > 1.2f) step = 3;
                        break;
                    case 3:
                        if (pc.Ctx.TrayCount > 0 || pc.Ctx.heldBox != null || pc.CarryingPhysicalItem) step = 4;
                        break;
                    case 4:
                        if (pc.Ctx.heldBox == null && !pc.CarryingPhysicalItem) step = 5;
                        break;
                    case 5:
                        if (ComputerUI.I != null && ComputerUI.I.IsOpen) step = 6;
                        break;
                    case 6:
                        if (EconomyManager.I.phase != Phase.Closed) step = 7;
                        break;
                    default:
                        if (GameSession.Data.totalServed > 0) doneTimer = 0f;
                        break;
                }
            }
        }
    }
}
