using System.Collections.Generic;
using UnityEngine;

namespace KioskTycoon
{
    /// <summary>Касса: пробивает товары из рук и принимает оплату у покупателя у окна.</summary>
    public class CashRegister : Interactable, IWorldLabel
    {
        public static CashRegister I;
        public const float FineAmount = 15f;
        static readonly Collider[] zoneHits = new Collider[64];

        public bool Busy { get; private set; }
        float scanTimer;
        Customer scanning;
        PlayerContext scanCtx;
        Customer activeOrder;
        readonly HashSet<PhysicalProduct> scannedItems = new HashSet<PhysicalProduct>();
        readonly List<PhysicalProduct> counterItems = new List<PhysicalProduct>();
        Transform counterZone;
        BoxCollider zoneCollider;
        float nextZoneCheck;

        public override float MaxDistance => 3f;

        void Awake() { I = this; WorldLabels.Add(this); }
        void OnDestroy() { WorldLabels.Remove(this); }

        public static CashRegister Create(Transform parent, Vector3 pos)
        {
            var go = new GameObject("CashRegister");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            Prim.Cube(go.transform, "Body", new Vector3(0f, 0.11f, 0f), new Vector3(0.4f, 0.22f, 0.3f),
                Mats.Solid(new Color(0.25f, 0.27f, 0.32f), 0.5f, 0.3f), false);
            var screen = Prim.Cube(go.transform, "Screen", new Vector3(0f, 0.3f, -0.06f), new Vector3(0.26f, 0.14f, 0.02f),
                Mats.Emissive(new Color(0.4f, 0.9f, 0.95f), 1.4f), false);
            screen.transform.localRotation = Quaternion.Euler(-25f, 0f, 0f);
            Prim.Cube(go.transform, "Drawer", new Vector3(0f, 0.13f, 0.151f), new Vector3(0.3f, 0.05f, 0.01f),
                Mats.Solid(new Color(0.85f, 0.7f, 0.2f), 0.4f), false);
            var bc = go.AddComponent<BoxCollider>();
            bc.center = new Vector3(0f, 0.12f, 0f);
            bc.size = new Vector3(0.42f, 0.26f, 0.32f);
            var register = go.AddComponent<CashRegister>();
            register.CreateCounterZone(parent);
            return register;
        }

        void CreateCounterZone(Transform parent)
        {
            counterZone = new GameObject("CheckoutZone").transform;
            counterZone.SetParent(parent, false);
            counterZone.localPosition = new Vector3(-0.02f, 1.045f, 0.28f);
            zoneCollider = counterZone.gameObject.AddComponent<BoxCollider>();
            zoneCollider.isTrigger = true;
            zoneCollider.center = new Vector3(0f, 0.16f, 0f);
            zoneCollider.size = new Vector3(0.76f, 0.5f, 0.43f);
            var amber = Mats.Emissive(new Color(0.2f, 0.95f, 0.85f), 1.2f);
            Prim.Cube(counterZone, "Checkout surface", new Vector3(0f, -0.012f, 0f), new Vector3(0.72f, 0.012f, 0.4f), Mats.Solid(new Color(0.12f, 0.35f, 0.34f), 0.25f), false);
            Prim.Cube(counterZone, "Zone front", new Vector3(0f, 0f, -0.21f), new Vector3(0.76f, 0.018f, 0.018f), amber, false);
            Prim.Cube(counterZone, "Zone back", new Vector3(0f, 0f, 0.21f), new Vector3(0.76f, 0.018f, 0.018f), amber, false);
            Prim.Cube(counterZone, "Zone left", new Vector3(-0.37f, 0f, 0f), new Vector3(0.018f, 0.018f, 0.42f), amber, false);
            Prim.Cube(counterZone, "Zone right", new Vector3(0.37f, 0f, 0f), new Vector3(0.018f, 0.018f, 0.42f), amber, false);
        }

        void Update()
        {
            // Recover products placed on the visible checkout pad through physics or save loading,
            // even if they did not pass through ItemGrabber.Release().
            if (Time.time >= nextZoneCheck)
            {
                nextZoneCheck = Time.time + 0.1f;
                RegisterProductsInZone();
            }

            if (!Busy) return;
            scanTimer -= Time.deltaTime;
            if (scanTimer <= 0f) Finish();
        }

        Customer Front => CustomerSpawner.I != null ? CustomerSpawner.I.Front : null;

        public bool HasActiveOrder => activeOrder != null && activeOrder.State != CustState.Leaving;
        public int OrderCount
        {
            get { if (!HasActiveOrder) return 0; int n = 0; foreach (var kv in activeOrder.Wants) n += kv.Value; return n; }
        }
        public int ScannedCount => scannedItems.Count;
        public IEnumerable<PhysicalProduct> ScannedProducts => scannedItems;
        public int CounterCount(ProductData product)
        {
            int count = 0;
            foreach (var item in counterItems) if (item != null && item.inRegisterZone && item.product == product) count++;
            return count;
        }
        public bool CanSell
        {
            get
            {
                if (!HasActiveOrder || OrderCount <= 0 || scannedItems.Count != OrderCount) return false;
                foreach (var want in activeOrder.Wants)
                {
                    int count = 0;
                    foreach (var item in scannedItems) if (item != null && item.product == want.Key) count++;
                    if (count != want.Value) return false;
                }
                return true;
            }
        }
        public float SaleTotal
        {
            get
            {
                float total = 0f;
                if (StockManager.I == null) return 0f;
                foreach (var item in scannedItems) if (item != null) total += StockManager.I.GetPrice(item.product);
                return total;
            }
        }

        public void BeginOrder(Customer customer)
        {
            ClearOrder();
            activeOrder = customer;
            // If products were already sitting on the pad when the customer ordered, scan them now.
            foreach (var item in new List<PhysicalProduct>(counterItems))
                if (item != null && item.inRegisterZone) ScanItem(item);
        }

        void RegisterProductsInZone()
        {
            if (zoneCollider == null) return;
            int hitCount = Physics.OverlapBoxNonAlloc(zoneCollider.bounds.center, zoneCollider.bounds.extents,
                zoneHits, counterZone.rotation, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore);
            for (int i = 0; i < hitCount; i++)
            {
                var item = zoneHits[i] != null ? zoneHits[i].GetComponentInParent<PhysicalProduct>() : null;
                zoneHits[i] = null;
                if (item == null || item.customerOrder || item.IsHeld || item.IsUsing || item.inRegisterZone) continue;
                TryPlaceOnCounter(item);
            }
        }

        public bool TryPlaceOnCounter(PhysicalProduct item)
        {
            if (item == null || counterZone == null || zoneCollider == null) return false;
            Bounds zoneBounds = zoneCollider.bounds;
            if (item.Collider == null || !zoneBounds.Intersects(item.Collider.bounds)) return false;
            for (int i = 0; i < 12; i++)
            {
                int col = i % 4, row = i / 4;
                Vector3 pos = counterZone.TransformPoint(new Vector3(-0.24f + col * 0.16f, 0.07f, -0.12f + row * 0.17f));
                bool occupied = false;
                foreach (var other in counterItems)
                    if (other != null && other != item && Vector3.Distance(other.transform.position, pos) < 0.12f) { occupied = true; break; }
                if (occupied) continue;
                item.RestOnCounter(pos);
                if (!counterItems.Contains(item)) counterItems.Add(item);
                AudioManager.Play(Sfx.Place);
                Toast.Push(Loc.Get("p.reg.placed"));
                // Placing stock in the highlighted checkout zone scans it automatically.
                // ScanItem already guards against duplicate scans and products outside the order.
                ScanItem(item);
                return true;
            }
            Toast.Warn(Loc.Get("p.reg.full"));
            return false;
        }

        public void RemoveFromCounter(PhysicalProduct item) { counterItems.Remove(item); }

        /// <summary>Игрок забрал товар с кассы обратно: он больше не в зоне и не пробит.</summary>
        public void ReleaseFromCounter(PhysicalProduct item)
        {
            if (item == null) return;
            counterItems.Remove(item);
            scannedItems.Remove(item);
            item.isScanned = false;
            item.inRegisterZone = false;
            if (HasActiveOrder && activeOrder.State == CustState.Paying) activeOrder.State = CustState.Shopping;
        }

        /// <summary>Сколько товаров сейчас лежит в зоне кассы.</summary>
        public int CounterTotal
        {
            get { int n = 0; foreach (var i in counterItems) if (i != null && i.inRegisterZone) n++; return n; }
        }

        /// <summary>Кража: всё из зоны кассы исчезает (запасы уменьшаются), возвращается список украденного.</summary>
        public Dictionary<ProductData, int> StealCounterGoods()
        {
            var loot = new Dictionary<ProductData, int>();
            foreach (var item in new List<PhysicalProduct>(counterItems))
            {
                if (item == null || !item.inRegisterZone) continue;
                loot.TryGetValue(item.product, out int n);
                loot[item.product] = n + 1;
                item.Consume();
            }
            scannedItems.Clear();
            counterItems.RemoveAll(i => i == null);
            return loot;
        }

        // ---------- подпись зоны кассы ----------
        public Vector3 LabelPos => counterZone != null ? counterZone.position + Vector3.up * 0.32f : transform.position;
        public float LabelMaxDist => 5f;

        public void DrawLabel(Vector2 sp)
        {
            var t = ThemeManager.Current;
            string text = HasActiveOrder
                ? Loc.F("hud.zoneActive", counterItems.Count, ScannedCount, OrderCount)
                : Loc.Get("hud.zone");
            UIKit.Box(new Rect(sp.x - 150, sp.y - 16, 300, 32), new Color(0f, 0f, 0f, 0.55f));
            UIKit.Label(new Rect(sp.x - 150, sp.y - 16, 300, 32), text, 20,
                CanSell ? t.good : t.text, TextAnchor.MiddleCenter, true, false);
        }

        void ScanFlash(PhysicalProduct item)
        {
            var beam = Prim.Cube(null, "Scan beam", item.transform.position, new Vector3(0.7f, 0.004f, 0.01f),
                Mats.Emissive(new Color(1f, 0.1f, 0.1f), 3f), false);
            Destroy(beam, 0.18f);
        }

        public void ScanItem(PhysicalProduct item)
        {
            if (!HasActiveOrder || item == null || item.customerOrder || !item.inRegisterZone) return;
            if (scannedItems.Contains(item)) { Toast.Push(Loc.Get("hud.alreadyScanned")); return; }
            int wanted = activeOrder.Wants.TryGetValue(item.product, out int count) ? count : 0;
            int already = 0;
            foreach (var scanned in scannedItems) if (scanned != null && scanned.product == item.product) already++;
            if (wanted == 0 || already >= wanted)
            {
                AudioManager.Play(Sfx.Click, 0.7f);
                Toast.Warn(Loc.Get("hud.wrongScan"));
                return;
            }
            scannedItems.Add(item);
            item.isScanned = true;
            ScanFlash(item);
            AudioManager.Play(Sfx.Scan);
            Toast.Good(Loc.F("t.scanned", item.product.displayName, UIKit.Money(StockManager.I.GetPrice(item.product))));
            if (CanSell) activeOrder.State = CustState.Paying;
        }

        public void SellScanned()
        {
            if (!CanSell) { Toast.Warn(Loc.Get("hud.sellNeed")); return; }
            var customer = activeOrder;
            var ctx = PlayerController.I.Ctx;
            var soldPhysical = new List<PhysicalProduct>();
            ctx.Tray.Clear();
            foreach (var item in scannedItems)
                if (item != null) { ctx.AddTray(item.product, 1); soldPhysical.Add(item); }
            Settle(customer, ctx);
            foreach (var item in soldPhysical)
            {
                if (item == null) continue;
                if (ctx.Get(item.product) > 0)
                {
                    ctx.RemoveTray(item.product, 1);
                    item.isScanned = false;
                }
                else
                {
                    counterItems.Remove(item);
                    item.Consume();
                }
            }
            ctx.Tray.Clear();
        }

        public void OnCustomerLeave(Customer customer)
        {
            if (activeOrder == customer) ClearOrder();
        }

        void ClearOrder()
        {
            foreach (var item in scannedItems) if (item != null) item.isScanned = false;
            scannedItems.Clear();
            counterItems.RemoveAll(item => item == null);
            activeOrder = null;
        }

        public override string Prompt(PlayerContext p)
        {
            if (Busy) return Loc.Get("hud.scan");
            if (HasActiveOrder) return CanSell ? Loc.Get("hud.sell") : Loc.Get("hud.sellNeed");
            var c = Front;
            if (c == null || c.State == CustState.Queued || c.State == CustState.Leaving) return Loc.Get("p.reg.nocust");
            if (c.State == CustState.Ordering) return Loc.Get("p.reg.order");
            if (p.TrayCount == 0) return Loc.Get("p.reg.notray");
            return Loc.Get("p.reg.checkout");
        }

        public override void Interact(PlayerContext p)
        {
            if (HasActiveOrder) { if (CanSell) SellScanned(); else Toast.Warn(Loc.Get("hud.sellNeed")); return; }
            var c = Front;
            if (Busy || c == null || c.State != CustState.Shopping || p.TrayCount == 0) return;
            Busy = true;
            scanning = c;
            scanCtx = p;
            c.State = CustState.Paying;
            int lvl = GameSession.Data.Up(UpgradeType.Register);
            scanTimer = UpgradeCatalog.ScanTime[lvl] * Mathf.Max(1, p.TrayCount);
            AudioManager.Play(Sfx.Beep);
        }

        /// <summary>F: отказать покупателю у окна (проверка возраста или просто отказ).</summary>
        public void Decline()
        {
            var c = Front;
            var e = EconomyManager.I;
            if (Busy || c == null || (c.State != CustState.Ordering && c.State != CustState.Shopping)) return;
            bool right = c.Young && c.HasRestricted();
            if (right) { e.AddRep(3f); Toast.Good(Loc.Get("t.refuseok")); }
            else { e.AddRep(-3f); Toast.Warn(Loc.Get("t.refusebad")); }
            e.RecordLost();
            c.Leave(right ? LeaveMood.Neutral : LeaveMood.Angry);
        }

        void Finish()
        {
            Busy = false;
            var c = scanning;
            var p = scanCtx;
            scanning = null;
            scanCtx = null;
            if (c == null || p == null || c.State != CustState.Paying) return;
            Settle(c, p);
        }

        static bool TrayHasRestricted(PlayerContext p)
        {
            foreach (var k in p.Tray.Keys) if (k.AgeRestricted) return true;
            return false;
        }

        void Settle(Customer c, PlayerContext p)
        {
            var e = EconomyManager.I;
            var stock = StockManager.I;

            // проверка возраста: молодому нельзя продавать товар 18+
            if (c.Young && TrayHasRestricted(p))
            {
                e.Spend(FineAmount, true);
                e.AddRep(-8f);
                Toast.Warn(Loc.F("t.fine", UIKit.Money(FineAmount)));
                AudioManager.Play(Sfx.Angry);
                c.Leave(LeaveMood.Angry);
                return;
            }

            int wanted = 0;
            foreach (var kv in c.Wants) wanted += kv.Value;

            var sold = new Dictionary<ProductData, int>();
            int got = 0;
            float total = 0f;
            bool extra = false, expensive = false;
            string expName = null;

            foreach (var kv in new Dictionary<ProductData, int>(p.Tray))
            {
                var prod = kv.Key;
                if (!c.Wants.TryGetValue(prod, out int need)) { extra = true; continue; }
                float price = stock.GetPrice(prod);
                if (price > prod.marketPrice * c.profile.priceTolerance)
                {
                    expensive = true;
                    expName = prod.displayName;
                    continue;
                }
                int n = Mathf.Min(kv.Value, need);
                if (n <= 0) continue;
                p.RemoveTray(prod, n);
                sold[prod] = n;
                total += price * n;
                got += n;
            }

            if (total > 0f) e.Earn(total);

            int missing = wanted - got;
            string missName = null;
            foreach (var kv in c.Wants)
            {
                sold.TryGetValue(kv.Key, out int s);
                if (s < kv.Value) { missName = kv.Key.displayName; break; }
            }

            float tip = 0f;
            if (got > 0 && missing == 0 && !extra && !expensive)
            {
                int reg = GameSession.Data.Up(UpgradeType.Register);
                tip = total * c.profile.tipFactor * (reg == 3 ? 1.5f : 1f);
                if (tip > 0.05f) { e.Earn(tip); Toast.Good(Loc.F("t.tip", UIKit.Money(tip))); }
            }

            float frac = wanted > 0 ? (float)got / wanted : 0f;
            float dRep = (frac - 0.5f) * 4f;
            if (got > 0 && missing == 0 && !extra && !expensive) dRep += 1f;
            if (extra) dRep -= 1f;
            if (expensive) dRep -= 1f;
            e.AddRep(dRep);

            if (got > 0)
            {
                e.RecordServed();
                AudioManager.Play(Sfx.Drawer);
                AudioManager.Play(Sfx.Cash);
                Toast.Good(Loc.F("t.sale", UIKit.Money(total)));
            }
            else
            {
                e.RecordLost();
                AudioManager.Play(Sfx.Angry);
                Toast.Warn(Loc.Get("t.nothing"));
            }
            if (missName != null) Toast.Warn(Loc.F("t.missing", missName));
            if (extra) Toast.Warn(Loc.Get("t.wrong"));
            if (expensive) Toast.Warn(Loc.F("t.expensive", expName));

            c.Leave(got > 0 && missing == 0 && !extra && !expensive ? LeaveMood.Happy
                : got > 0 ? LeaveMood.Neutral : LeaveMood.Angry);
        }
    }
}
